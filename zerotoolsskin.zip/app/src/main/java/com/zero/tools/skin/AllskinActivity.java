package com.zero.tools.skin;

import LEGENDARY.STREAMER.YT.UTIL.*;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.extensions.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.service.*;
import com.AndroidSketchwareMaster.*;
import com.android.volley.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import com.kaopiz.kprogresshud.*;
import com.stx.xhb.androidx.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import java.io.*;
import java.util.zip.*;
import android.database.*;
import androidx.core.widget.NestedScrollView;

import java.util.concurrent.TimeUnit;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import android.provider.Settings;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.net.NetworkInterface;
import java.util.Collections;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.Process;
import com.zero.tools.skin.security.JsonManager;

public class AllskinActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> map = new HashMap<>();
	private double r = 0;
	private HashMap<String, Object> maps = new HashMap<>();
	private double n1 = 0;
	private HashMap<String, Object> cacheMap = new HashMap<>();
	private double count1 = 0;
	private String save = "";
	private String value = "";
	private double number = 0;
	private double length = 0;
	
	private ArrayList<HashMap<String, Object>> lp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> cache = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> breh = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear1;
	private GridView gridview1;
	private ImageView imageview1;
	private LinearLayout linear6;
	private ImageView imageview3;
	private ImageView imageview2;
	private EditText edittext2;
	
	private SharedPreferences sp;
	private TimerTask tmr;
	private TimerTask t;
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private RequestNetwork v;
	private RequestNetwork.RequestListener _v_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.allskin);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		linear1 = findViewById(R.id.linear1);
		gridview1 = findViewById(R.id.gridview1);
		imageview1 = findViewById(R.id.imageview1);
		linear6 = findViewById(R.id.linear6);
		imageview3 = findViewById(R.id.imageview3);
		imageview2 = findViewById(R.id.imageview2);
		edittext2 = findViewById(R.id.edittext2);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		d = new AlertDialog.Builder(this);
		v = new RequestNetwork(this);
		
		edittext2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				ArrayList<HashMap<String, Object>> breh;
				
				// ===============================
				// 1. AMANKAN DATA DARI KOMPONEN
				// ===============================
				if (save == null || save.trim().isEmpty()) {
					breh = new ArrayList<HashMap<String, Object>>();
				} else {
					try {
						breh = new Gson().fromJson(
						save,
						new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
						);
						if (breh == null) {
							breh = new ArrayList<HashMap<String, Object>>();
						}
					} catch (Exception e) {
						breh = new ArrayList<HashMap<String, Object>>();
					}
				}
				
				// ===============================
				// 2. FILTER PENCARIAN REAL-TIME
				// ===============================
				// _charSeq diambil langsung dari argumen onTextChanged Sketchware
				if (_charSeq != null && _charSeq.length() > 0) {
					for (int i = breh.size() - 1; i >= 0; i--) {
						// Antisipasi jika ada data map yang null atau key "her" hilang
						if (breh.get(i) == null || breh.get(i).get("her") == null) {
							breh.remove(i);
							continue;
						}
						
						String value = breh.get(i).get("her").toString();
						if (!value.toLowerCase().contains(_charSeq.toString().toLowerCase())) {
							breh.remove(i);
						}
					}
				}
				
				// ===============================
				// 3. SEGERAKAN UPDATE GRIDVIEW
				// ===============================
				if (gridview1 != null) {
					gridview1.setAdapter(new Gridview1Adapter(breh));
					if (gridview1.getAdapter() != null) {
						((BaseAdapter) gridview1.getAdapter()).notifyDataSetChanged();
					}
				}
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_v_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				// Ambil SharedPreferences
				SharedPreferences cache = getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
				String oldJson = cache.getString("hero", "");
				
				// ===== SIMPAN CACHE HANYA JIKA BERUBAH =====
				if (!_response.equals(oldJson)) {
					cache.edit().putString("hero", _response).apply();
				}
				
				// ===== PARSE JSON =====
				breh = new Gson().fromJson(
				_response,
				new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
				);
				
				if (breh == null || breh.size() == 0) return;
				
				// ===== FILTER / SORT =====
				_AnehGamingOfficial(breh, "her");
				
				// ===== TAMPILKAN =====
				gridview1.setAdapter(new Gridview1Adapter(breh));
				gridview1.setAlpha(1f);
				
				// ===== RESTORE SCROLL =====
				SharedPreferences scrollSp = getSharedPreferences("SCROLL", MODE_PRIVATE);
				int pos = scrollSp.getInt("grid_pos_hero", 0);
				gridview1.setSelection(pos);
				
				// ===== SIMPAN COPY UNTUK SEARCH =====
				save = new Gson().toJson(breh);
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		DialogUtil.applySecureEdgeToEdge(this);
		
		SharedPreferences cache = getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
		String json = cache.getString("hero", null);
		
		if (json != null) {
			// ===== PARSE DARI CACHE =====
			breh = new Gson().fromJson(
			json,
			new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
			);
			
			if (breh != null && breh.size() > 0) {
				// Sort/filter sesuai logika
				_AnehGamingOfficial(breh, "her");
				
				// Tampilkan di GridView
				gridview1.setAdapter(new Gridview1Adapter(breh));
				gridview1.setAlpha(1f);
				
				// Restore scroll
				SharedPreferences scrollSp = getSharedPreferences("SCROLL", MODE_PRIVATE);
				int pos = scrollSp.getInt("grid_pos_hero", 0);
				gridview1.setSelection(pos);
				
				// Simpan copy untuk pencarian
				save = new Gson().toJson(breh);
			}
		}
		
		// ===== REQUEST NETWORK SELALU UNTUK UPDATE =====
		// 🔑 URL diambil dari JsonManager
		String url = JsonManager.getJsonUrl("hero");
		
		v.startRequestNetwork(
		RequestNetworkController.GET,
		url,
		"AnehGamingSuperOfficial", // ⛔ TAG TIDAK DIUBAH
		_v_request_listener
		);
		
		linear6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)2, 0xFF6A1B9A, 0xFFFFFFFF));
		edittext2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 1);
		imageview1.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					v.animate().scaleX(0.7f).scaleY(0.7f).setDuration(100).start();
					break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					break;
				}
				return false;
			}
		});
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish(); // 🔥 INI KUNCINYA
			}
		});
		
		// imageview3 (touch + custom drawer-style dialog 1 tombol)
		// ---------------------
		imageview3.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					v.animate().scaleX(0.7f).scaleY(0.7f).setDuration(100).start();
					break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					break;
				}
				return false;
			}
		});
		// imageview3 (touch + custom drawer-style dialog 1 tombol)
		// ---------------------
		imageview3.setOnClickListener(v -> {
			WebViewHelper.show(
			AllskinActivity.this,
			"https://updateterbaru7.blogspot.com"
			);
		});
	}
	
	
	@Override
	public void onResume() {
		super.onResume();
		SharedPreferences scrollSp =
		getSharedPreferences("SCROLL", MODE_PRIVATE);
		
		final int pos = scrollSp.getInt("grid_pos", 0);
		
		gridview1.post(new Runnable() {
			@Override
			public void run() {
				gridview1.setSelection(pos);
			}
		});
		final SharedPreferences prefs =
		getSharedPreferences("app_prefs", MODE_PRIVATE);
		
		long now = System.currentTimeMillis();
		long lastShown = prefs.getLong("lastAlertTime", 0);
		
		// Cooldown 10 detik
		if (now - lastShown < 10_000) {
			return;
		}
		
		// Tunda lebih lama supaya iklan tidak terganggu
		new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
			@Override
			public void run() {
				
				if (isFinishing() || isDestroyed()) return;
				
				// 🔒 Cek ringan & aman (urutan penting)
				boolean blocked = false;
				
				if (_isBlockedDNS()) {
					blocked = true;
				} else if (_isVPNEnabled()) {
					blocked = true;
				}
				// ❌ _checkAdBlock() sengaja DIHILANGKAN
				// karena berat & sering bikin delay
				
				if (blocked) {
					// ✅ Dialog muncul saat UI sudah stabil
					_showBlockDialog();
					
					prefs.edit()
					.putLong("lastAlertTime", System.currentTimeMillis())
					.apply();
				}
			}
		}, 3000);
	}
	
	@Override
	public void onPause() {
		super.onPause();
		SharedPreferences scrollSp =
		getSharedPreferences("SCROLL", MODE_PRIVATE);
		
		scrollSp.edit()
		.putInt("grid_pos_hero", gridview1.getFirstVisiblePosition())
		.apply();
	}
	public void _setCornerRadius(final View _view, final double _value, final String _color) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_value);
		_view.setBackground(gd);
		_view.setElevation(5);
	}
	
	
	public void _Anehgaminginejvtor(final ImageView _img, final String _file, final String _url) {
		Glide.with(getContext(this)).load(_url).thumbnail(Glide.with(getContext(this)).load(getContext(this).getResources().getIdentifier(_file, "drawable", getContext(this).getPackageName()))).fitCenter().into(_img);
	}
	public Context getContext(Context c) {
		return c;
	}
	public Context getContext(Fragment f) {
		return f.getActivity();
	}
	public Context getContext(DialogFragment df) {
		return df.getActivity();
	}
	{
	}
	
	
	public void _AnehGamingOfficial(final ArrayList<HashMap<String, Object>> _listmap, final String _aneh) {
		Comparator list_sorter = new Comparator<HashMap<String, Object>>(){
			@Override
			public int compare(HashMap<String, Object> map2, HashMap<String, Object> map1){
				
				try {
					Double num1 = Double.parseDouble(map1.get(_aneh).toString());
					Double num2 = Double.parseDouble(map2.get(_aneh).toString());
					return Double.compare(num2, num1);
				} catch (NumberFormatException e){
					return map2.get(_aneh).toString().compareTo(map1.get(_aneh).toString());
				}
				
			}
		};
		
		Collections.sort(_listmap, list_sorter);
	}
	
	
	public boolean _checkAdBlock() {
		if (_isVPNEnabled() || _isBlockedDNS()) {
			return true; // hanya kembalikan nilai
		}
		return false;
	}
	
	
	public boolean _isVPNEnabled() {
		try {
			// ================================
			// 1) VPN RESMI (PALING AMAN)
			// ================================
			ConnectivityManager cm =
			(ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
			
			if (cm != null) {
				Network network = cm.getActiveNetwork();
				NetworkCapabilities caps = cm.getNetworkCapabilities(network);
				
				if (caps != null &&
				caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
					return true;
				}
			}
			
			// ================================
			// 2) INTERFACE CHECK (BACKUP)
			// ================================
			for (NetworkInterface ni :
			java.util.Collections.list(NetworkInterface.getNetworkInterfaces())) {
				
				if (!ni.isUp() || ni.isLoopback()) continue;
				
				String name = ni.getName().toLowerCase(); // pakai getName(), lebih aman
				
				if (name.contains("tun")
				|| name.contains("wg")
				|| name.contains("ppp")) {
					
					return true;
				}
			}
			
			return false;
			
		} catch (Exception e) {
			return false;
		}
		
	}
	
	
	public boolean _isBlockedDNS() {
		try {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
				String mode = Settings.Global.getString(
				getContentResolver(),
				"private_dns_mode"
				);
				
				String host = Settings.Global.getString(
				getContentResolver(),
				"private_dns_specifier"
				);
				
				if ("hostname".equals(mode) && host != null) {
					host = host.toLowerCase();
					return host.contains("adguard")
					|| host.contains("nextdns")
					|| host.contains("blokada");
				}
			}
		} catch (Throwable ignored) {}
		return false;
	}
	
	
	public void _showBlockDialog() {
		if (isFinishing() || isDestroyed()) return;
		
		androidx.appcompat.app.AlertDialog.Builder builder =
		new androidx.appcompat.app.AlertDialog.Builder(this);
		
		builder.setTitle("Koneksi Tidak Stabil • Unstable Connection");
		
		builder.setMessage(
		"Beberapa pengaturan jaringan atau DNS dapat memengaruhi " +
		"kestabilan koneksi aplikasi.\n\n" +
		"Jika Anda mengalami kendala, silakan nonaktifkan sementara " +
		"pengaturan tersebut lalu coba kembali.\n\n" +
		"Some network or DNS configurations may affect the app’s " +
		"connection stability.\n\n" +
		"If you experience issues, please temporarily disable such " +
		"settings and try again."
		);
		
		// ✅ Biarkan user bisa dismiss
		builder.setCancelable(true);
		
		// 🔁 COBA LAGI / RETRY
		builder.setPositiveButton("Coba Lagi / Retry",
		new android.content.DialogInterface.OnClickListener() {
			@Override
			public void onClick(android.content.DialogInterface dialog, int which) {
				
				dialog.dismiss();
				
				// Cek ulang DNS secara ringan
				if (!_isBlockedDNS()) {
					// lanjutkan aplikasi
					// contoh: loadData(); atau refresh halaman
				}
			}
		});
		
		// ⬅️ KEMBALI / BACK (lebih aman daripada force close)
		builder.setNegativeButton("Kembali / Back",
		new android.content.DialogInterface.OnClickListener() {
			@Override
			public void onClick(android.content.DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		
		builder.show();
		
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.view, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			Glide.with(getApplicationContext())
			.load(_data.get((int)_position).get("URL").toString())
			.placeholder(R.drawable.herokosong)
			.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners(25))
			.into(imageview1);
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 1);
			textview1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10);
			textview1.setText(_data.get((int)_position).get("her").toString());
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)2, 0xFFFFFFFF, 0xFF000000));
			linear1.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
						// Efek tekan (mengecil)
						v.animate().scaleX(0.8f).scaleY(0.8f).setDuration(100).start();
						break;
						
						case MotionEvent.ACTION_UP:
						case MotionEvent.ACTION_CANCEL:
						// Efek lepas (kembali normal)
						v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
						break;
					}
					return false; // tetap biar onClick jalan
				}
			});
			
			linear1.setOnClickListener(new View.OnClickListener() {
				long lastClickTime = 0;
				
				@Override
				public void onClick(View _view) {
					// 🟢 PASTIKAN BARIS "int ledakan = 10 / 0;" SUDAH BERSIH DAN DIHAPUS DARI SINI, CUY!
					
					if (android.os.SystemClock.elapsedRealtime() - this.lastClickTime < 1000){
						return;
					}
					this.lastClickTime = android.os.SystemClock.elapsedRealtime();
					
					if (gridview1 != null) {
						int lastPos = gridview1.getFirstVisiblePosition();
						SharedPreferences scrollSp = getSharedPreferences("SCROLL", MODE_PRIVATE);
						scrollSp.edit().putInt("grid_pos", lastPos).apply();
					}
					
					final android.app.Activity currentActivity = AllskinActivity.this;
					i.setClass(currentActivity, HeroskinActivity.class);
					
					final int currentPos = (int) _position;
					if (_data != null && currentPos >= 0 && currentPos < _data.size()) {
						if (_data.get(currentPos).containsKey("her") && _data.get(currentPos).get("her") != null) {
							sp.edit()
							.putString("her", _data.get(currentPos).get("her").toString())
							.apply();
						}
					}
					
					startActivity(i);
				}
			});
			
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}