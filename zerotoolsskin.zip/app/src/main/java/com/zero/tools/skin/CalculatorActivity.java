package com.zero.tools.skin;

import LEGENDARY.STREAMER.YT.UTIL.*;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.extensions.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.service.*;
import com.AndroidSketchwareMaster.*;
import com.android.volley.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import com.kaopiz.kprogresshud.*;
import com.stx.xhb.androidx.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import android.util.TypedValue;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.app.AlertDialog;

public class CalculatorActivity extends AppCompatActivity {
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ScrollView vscroll1;
	private ImageView imageview1;
	private TextView textview2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview3;
	private LinearLayout resultPanel;
	private TextView resCurrentMatches;
	private TextView resCurrentWinrate;
	private EditText currentMatches;
	private TextView resTargetWinrate;
	private EditText currentWinrate;
	private TextView finalMessage;
	private EditText targetWinrate;
	private Button btnCalculate;
	private Button btnClear;
	private TextView textKesimpulan;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.calculator);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		vscroll1 = findViewById(R.id.vscroll1);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		imageview3 = findViewById(R.id.imageview3);
		resultPanel = findViewById(R.id.resultPanel);
		resCurrentMatches = findViewById(R.id.resCurrentMatches);
		resCurrentWinrate = findViewById(R.id.resCurrentWinrate);
		currentMatches = findViewById(R.id.currentMatches);
		resTargetWinrate = findViewById(R.id.resTargetWinrate);
		currentWinrate = findViewById(R.id.currentWinrate);
		finalMessage = findViewById(R.id.finalMessage);
		targetWinrate = findViewById(R.id.targetWinrate);
		btnCalculate = findViewById(R.id.btnCalculate);
		btnClear = findViewById(R.id.btnClear);
		textKesimpulan = findViewById(R.id.textKesimpulan);
	}
	
	private void initializeLogic() {
		DialogUtil.applySecureEdgeToEdge(this);
		
		textview2.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
		textKesimpulan.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
		resCurrentMatches.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
		resCurrentWinrate.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
		resTargetWinrate.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
		finalMessage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		textKesimpulan.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 1);
		resCurrentMatches.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 1);
		resCurrentWinrate.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		resTargetWinrate.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		finalMessage.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		currentMatches.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)3, 0xFF673AB7, 0xFF000000));
		currentWinrate.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)3, 0xFF673AB7, 0xFF000000));
		targetWinrate.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)3, 0xFF673AB7, 0xFF000000));
		imageview1.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					v.animate().scaleX(0.7f).scaleY(0.7f).setDuration(100).start();
					break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					break;
				}
				return false;
			}
		});
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish(); // 🔥 INI KUNCINYA
			}
		});
		
		// imageview3 (touch + custom drawer-style dialog 1 tombol)
		// ---------------------
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				// Animasi tekan
				v.animate().scaleX(0.8f).scaleY(0.8f).setDuration(100)
				.withEndAction(new Runnable() {
					@Override
					public void run() {
						
						v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
						
						final float density = getResources().getDisplayMetrics().density;
						
						// 🔹 Layout utama
						LinearLayout layout = new LinearLayout(CalculatorActivity.this);
						layout.setOrientation(LinearLayout.VERTICAL);
						layout.setPadding(40, 40, 40, 30);
						
						// 🔹 ScrollView
						ScrollView scrollView = new ScrollView(CalculatorActivity.this);
						
						// 🔹 Text isi
						TextView message = new TextView(CalculatorActivity.this);
						message.setText(
						"⚠️ PENOLAKAN JAMINAN (DISCLAIMER):\n" +
						"Aplikasi ini merupakan alat bantu dan panduan independen yang dikembangkan oleh penggemar untuk komunitas (Unofficial Fan-made App). Aplikasi ini SAMA SEKALI TIDAK memiliki hubungan kerja sama, afiliasi, otorisasi, atau didukung oleh pengembang resmi game terkait.\n\n" +
						"Semua nama produk, logo, merek dagang, aset gambar, materi status, atau atribut item yang disebutkan di dalam aplikasi ini adalah hak cipta dan milik sepenuhnya dari pemilik sah masing-masing. Informasi di dalam aplikasi ini disediakan 'sebagaimana adanya' dan dapat berubah sewaktu-waktu mengikuti pembaruan versi game asli tanpa pemberitahuan sebelumnya.\n" +
						"----------------------------------------\n" +
						"⚠️ LEGAL DISCLAIMER:\n" +
						"This application is an independent tool and guide developed by fans for the community (Unofficial Fan-made App). This application is NOT in any way affiliated with, associated, authorized, endorsed by, or officially connected with the official game developer.\n\n" +
						"All product names, logos, trademarks, image assets, status materials, or item attributes mentioned within this app are the registered trademarks and copyrights of their respective owners. The information contained herein is provided for educational and informational purposes only and is subject to change at any time following official game updates without prior notice."
						);
						
						
						message.setTextSize(14);
						message.setTextColor(Color.WHITE);
						message.setTypeface(Typeface.DEFAULT_BOLD);
						
						scrollView.addView(message);
						layout.addView(scrollView);
						
						// 🔹 BUTTON OK (CUSTOM FIX)
						Button okButton = new Button(CalculatorActivity.this);
						okButton.setText("OK");
						okButton.setTextSize(14);
						okButton.setTextColor(Color.WHITE);
						okButton.setTypeface(Typeface.DEFAULT_BOLD);
						okButton.setAllCaps(false);
						
						LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.WRAP_CONTENT,
						(int) (40 * density)
						);
						btnParams.gravity = Gravity.END;
						btnParams.topMargin = (int) (20 * density);
						okButton.setLayoutParams(btnParams);
						
						// 🔹 Style tombol
						GradientDrawable btnBg = new GradientDrawable();
						btnBg.setCornerRadius(16 * density);
						btnBg.setColor(Color.parseColor("#4A148C"));
						btnBg.setStroke(3, Color.WHITE);
						
						okButton.setBackground(btnBg);
						
						// 🔹 Animasi tekan tombol
						okButton.setOnTouchListener(new View.OnTouchListener() {
							@Override
							public boolean onTouch(View btn, MotionEvent event) {
								switch (event.getAction()) {
									case MotionEvent.ACTION_DOWN:
									btn.animate().scaleX(0.8f).scaleY(0.8f).setDuration(100).start();
									break;
									case MotionEvent.ACTION_UP:
									case MotionEvent.ACTION_CANCEL:
									btn.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
									break;
								}
								return false;
							}
						});
						
						layout.addView(okButton);
						
						// 🔹 Dialog
						AlertDialog.Builder builder = new AlertDialog.Builder(CalculatorActivity.this);
						builder.setView(layout);
						
						final AlertDialog dialog = builder.create();
						dialog.show();
						
						dialog.setCancelable(true);
						dialog.setCanceledOnTouchOutside(true);
						
						// 🔹 Background dialog (HITAM + STROKE PUTIH)
						GradientDrawable bgDialog = new GradientDrawable();
						bgDialog.setCornerRadius(20 * density);
						bgDialog.setColor(Color.BLACK);
						bgDialog.setStroke(3, Color.WHITE);
						
						if (dialog.getWindow() != null) {
							dialog.getWindow().setBackgroundDrawable(bgDialog);
						}
						
						// 🔹 Klik tombol OK
						okButton.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								dialog.dismiss();
							}
						});
						
					}
				}).start();
			}
		});
		// Inisialisasi View dari calculator.xml ke Java
		final EditText currentMatches = findViewById(R.id.currentMatches);
		final EditText currentWinrate = findViewById(R.id.currentWinrate);
		final EditText targetWinrate = findViewById(R.id.targetWinrate);
		final Button btnCalculate = findViewById(R.id.btnCalculate);
		final Button btnClear = findViewById(R.id.btnClear);
		final LinearLayout resultPanel = findViewById(R.id.resultPanel);
		
		final TextView textKesimpulan = findViewById(R.id.textKesimpulan);
		final TextView resCurrentMatches = findViewById(R.id.resCurrentMatches);
		final TextView resCurrentWinrate = findViewById(R.id.resCurrentWinrate);
		final TextView resTargetWinrate = findViewById(R.id.resTargetWinrate);
		final TextView finalMessage = findViewById(R.id.finalMessage);
		
		// Memaksa sistem hanya menerima angka dan titik desimal murni
		currentMatches.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789"));
		currentWinrate.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789."));
		targetWinrate.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789."));
		
		// ========================================================
		final float density = getResources().getDisplayMetrics().density;
		
		// Bersihkan warna tint bawaan Sketchware agar warna #673AB7 muncul sempurna
		btnCalculate.setBackgroundTintList(null);
		btnClear.setBackgroundTintList(null);
		
		// Style untuk Tombol Calculate (Background Ungu #673AB7 + Stroke Putih)
		GradientDrawable bgCalculate = new GradientDrawable();
		bgCalculate.setColor(Color.parseColor("#4A148C"));       // 🔥 Warna Latar Ungu Kustom
		bgCalculate.setStroke((int)(2 * density), Color.WHITE);   // Stroke Putih ukuran 3dp [1]
		bgCalculate.setCornerRadius(8 * density);                // Sudut melengkung
		
		// Style untuk Tombol Clear (Background Ungu #673AB7 + Stroke Putih)
		GradientDrawable bgClear = new GradientDrawable();
		bgClear.setColor(Color.parseColor("#4A148C"));           // 🔥 Warna Latar Ungu Kustom
		bgClear.setStroke((int)(2 * density), Color.WHITE);       // Stroke Putih ukuran 3dp [1]
		bgClear.setCornerRadius(8 * density);                    // Sudut melengkung
		
		// Terapkan background kustom ke tombol
		btnCalculate.setBackgroundDrawable(bgCalculate);
		btnClear.setBackgroundDrawable(bgClear);
		
		btnCalculate.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					// Efek amblas/mengecil saat ditekan
					v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
					break;
					
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					// Kembali ke ukuran semula saat dilepas
					v.animate().scaleX(1f).scaleY(1f).setDuration(150).start();
					break;
				}
				return false; // Mengembalikan false agar fungsi onClick di bawahnya tetap berjalan!
			}
		});
		
		// 🟢 2. ANIMASI SENTUH UNTUK TOMBOL CLEAR
		btnClear.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					// Efek amblas/mengecil saat ditekan
					v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
					break;
					
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					// Kembali ke ukuran semula saat dilepas
					v.animate().scaleX(1f).scaleY(1f).setDuration(150).start();
					break;
				}
				return false; // Mengembalikan false agar fungsi onClick di bawahnya tetap berjalan!
			}
		});
		// ========================================================
		// 🚀 LOGIKA PEMROGRAMAN KALKULATOR
		// ========================================================
		
		// Logika Tombol Calculate
		// Logika Tombol Calculate (ANTI-CRASH HURUF DAN SIMBOL)
		btnCalculate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String strMatches = currentMatches.getText().toString().trim();
				String strCurrentWr = currentWinrate.getText().toString().trim();
				String strTargetWr = targetWinrate.getText().toString().trim();
				
				// 1. Validasi jika ada kolom yang belum diisi
				if (strMatches.isEmpty() || strCurrentWr.isEmpty() || strTargetWr.isEmpty()) {
					android.widget.Toast.makeText(CalculatorActivity.this, "Silakan isi semua kolom!", android.widget.Toast.LENGTH_SHORT).show();
					return;
				}
				
				// Deklarasi variabel angka awal
				int matches = 0;
				double currentWr = 0.0;
				double targetWr = 0.0;
				
				// 🔥 FIX CRASH ULTRA: Menggunakan blok try-catch untuk menangkap error salah ketik huruf/simbol
				try {
					matches = Integer.parseInt(strMatches);
					currentWr = Double.parseDouble(strCurrentWr);
					targetWr = Double.parseDouble(strTargetWr);
				} catch (NumberFormatException e) {
					// Jika sistem mendeteksi ada huruf atau simbol aneh, kode di bawah ini akan dijalankan secara aman
					android.widget.Toast.makeText(CalculatorActivity.this, "Format input salah! Harap masukkan angka saja.", android.widget.Toast.LENGTH_LONG).show();
					return; // Hentikan kalkulasi agar tidak crash
				}
				
				// 2. Validasi batasan persentase hanya untuk winrate saat ini
				if (currentWr >= 100 || currentWr < 0) {
					android.widget.Toast.makeText(CalculatorActivity.this, "Win rate saat ini harus berada di antara 0-99.9%!", android.widget.Toast.LENGTH_SHORT).show();
					return;
				}
				
				// 3. Validasi logika dasar target
				if (targetWr <= currentWr) {
					android.widget.Toast.makeText(CalculatorActivity.this, "Target WR harus lebih tinggi dari saat ini!", android.widget.Toast.LENGTH_SHORT).show();
					return;
				}
				
				// Rumus Matematika Perhitungan Winrate Beruntun
				double currentWins = Math.round(matches * (currentWr / 100.0));
				double requiredWinsCeil = Math.ceil((targetWr * matches - 100.0 * currentWins) / (100.0 - targetWr));
				int finalRequiredWins = (int) requiredWinsCeil;
				
				// Memperbarui Tampilan UI Hasil
				if (resultPanel != null) {
					resultPanel.setVisibility(View.GONE); 
					resultPanel.setVisibility(View.VISIBLE);
				}
				
				if (resCurrentMatches != null) resCurrentMatches.setText("📊 Current Matches Played: " + matches);
				if (resCurrentWinrate != null) resCurrentWinrate.setText("🏆 Current Win Rate: " + String.format("%.1f", currentWr) + "%");
				if (resTargetWinrate != null) resTargetWinrate.setText("🎯 Target Win Rate: " + String.format("%.1f", targetWr) + "%");
				
				if (finalMessage != null) {
					if (finalRequiredWins > 0) {
						finalMessage.setText("Required consecutive wins: " + finalRequiredWins);
						
						if (textKesimpulan != null) {
							// ATUR BACKGROUND KOTAK HITAM BORDER UNGU #4A148C
							GradientDrawable bgKesimpulan = new GradientDrawable();
							bgKesimpulan.setColor(Color.BLACK);
							bgKesimpulan.setStroke((int)(2 * density), Color.parseColor("#4A148C"));
							bgKesimpulan.setCornerRadius(12 * density);
							
							textKesimpulan.setBackgroundDrawable(bgKesimpulan);
							textKesimpulan.setPadding((int)(16 * density), (int)(16 * density), (int)(16 * density), (int)(16 * density));
							
							textKesimpulan.setText(
							"📌 Kesimpulan Keseluruhan:\n" +
							"Untuk mencapai target winrate " + targetWr + "%, kamu memerlukan " + finalRequiredWins + " kali kemenangan beruntun tanpa kalah satu kali pun. Total match kamu nantinya akan bertambah menjadi " + (matches + finalRequiredWins) + " pertandingan.\n\n" +
							"📌 Overall Conclusion:\n" +
							"To achieve a target winrate of " + targetWr + "%, you need " + finalRequiredWins + " consecutive wins without losing a single match. Your total matches will eventually increase to " + (matches + finalRequiredWins) + " matches."
							);
						}
					} else {
						finalMessage.setText("Target Anda sudah tercapai!");
						if (textKesimpulan != null) {
							GradientDrawable bgKesimpulan = new GradientDrawable();
							bgKesimpulan.setColor(Color.BLACK);
							bgKesimpulan.setStroke((int)(2 * density), Color.parseColor("#4A148C"));
							bgKesimpulan.setCornerRadius(12 * density);
							
							textKesimpulan.setBackgroundDrawable(bgKesimpulan);
							textKesimpulan.setPadding((int)(16 * density), (int)(16 * density), (int)(16 * density), (int)(16 * density));
							
							textKesimpulan.setText(
							"📌 Kesimpulan Keseluruhan:\nTarget winrate kamu sudah terpenuhi.\n\n" +
							"📌 Overall Conclusion:\nYour target winrate has already been achieved."
							);
						}
					}
				}
			}
		});
		
		
		// Logika Tombol Clear (Hanya Mereset Data ke Tampilan Awal)
		btnClear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// 1. Kosongkan semua kolom input teks pengguna
				currentMatches.setText("");
				currentWinrate.setText("");
				targetWinrate.setText("");
				
				// 2. Reset semua teks hasil perhitungan kembali ke tampilan awal (strip)
				if (resCurrentMatches != null) resCurrentMatches.setText("📊 Current Matches Played: -");
				if (resCurrentWinrate != null) resCurrentWinrate.setText("🏆 Current Win Rate: -%");
				if (resTargetWinrate != null) resTargetWinrate.setText("🎯 Target Win Rate: -%");
				if (finalMessage != null) finalMessage.setText("Required consecutive wins: -");
				
				// 🔥 TAMBAHKAN BARIS INI: Agar teks kesimpulan ikut terhapus saat tombol Clear diklik
				if (textKesimpulan != null) {
					textKesimpulan.setText("");
				}
				
				// Masukkan baris ini di dalam btnClear agar kotak ikut bersih saat di-clear
				if (textKesimpulan != null) {
					textKesimpulan.setText("");
					textKesimpulan.setBackgroundDrawable(null); // Menghapus kotak hitam bergaris ungu
				}
				
				// 3. Jaga agar panel hasil tetap muncul di layar (tidak disembunyikan)
				if (resultPanel != null) {
					resultPanel.setVisibility(View.VISIBLE);
				}
			}
		});
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}