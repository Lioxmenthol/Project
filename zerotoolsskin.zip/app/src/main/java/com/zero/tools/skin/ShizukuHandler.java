package com.zero.tools.skin;

import android.app.Activity;
import android.widget.Toast;

import com.AndroidSketchwareMaster.ShizukuMaster;
import com.kaopiz.kprogresshud.KProgressHUD;

import java.io.File;

public class ShizukuHandler {

    private Activity activity;
    private ShizukuMaster shizuku;

    public ShizukuHandler(Activity activity, ShizukuMaster shizuku) {
        this.activity = activity;
        this.shizuku = shizuku;
    }

    // ===============================
    // CHECK FOLDER VIA SHIZUKU
    // ===============================
    private boolean shizukuFolderExists(String path) {
        try {
            // OPTIMASI: Gunakan escape single quote untuk mengamankan path di shell
            String cmd = "sh -c '[ -d \"" + path + "\" ] && echo YES || echo NO'";
            String result = shizuku.execCommand(cmd);
            return result != null && result.contains("YES");
        } catch (Exception e) {
            return false;
        }
    }

    // ===============================
    // AUTO DETECT ML PATH (LENGKAP SELURUH DUNIA)
    // ===============================
    private String getMlAssetsPath() {
        String[] packages = {
            "com.mobile.legends",      // 1. Versi Global (Indonesia, PH, Arab, MY, SG, dll)
            "com.vng.mlbbvn",          // 2. Versi Vietnam (VNG resmi)
            "com.mobile.legends.usa",  // 3. Versi Amerika Serikat / Amerika Utara
            "com.mobilelegends.mi",    // 4. Versi India lama / Xiaomi Store
            "com.mobilelegends.hwag",  // 5. Versi India baru (Moba Legends: 5v5!)
            "com.moonton.dfjs",        // 6. Versi China (决胜巅峰)
            "com.mobile.legends.ft"    // 7. Versi Lite / Regional Afrika
        };

        for (String pkg : packages) {
            String targetPath = "/storage/emulated/0/Android/data/" + pkg + "/files/dragon2017/assets";
            if (shizukuFolderExists(targetPath)) {
                return targetPath;
            }
        }

        // Tidak ditemukan
        return null;
    }

    // ===============================
    // EXTRACT
    // ===============================
    public void extract(
            final String zipPath,
            final String assetsPath,
            final KProgressHUD hud
    ) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String targetPath;

                    if (assetsPath == null || assetsPath.length() == 0) {
                        targetPath = getMlAssetsPath();
                    } else {
                        targetPath = assetsPath;
                    }

                    if (targetPath == null) {
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (hud != null && hud.isShowing()) {
                                    hud.dismiss();
                                }
                                Toast.makeText(
                                        activity,
                                        "Folder Mobile Legends tidak ditemukan!",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        });
                        return;
                    }

                    File zip = new File(zipPath);
                    if (!zip.exists()) {
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (hud != null && hud.isShowing()) {
                                    hud.dismiss();
                                }
                                Toast.makeText(
                                        activity,
                                        "ZIP tidak ditemukan!",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        });
                        return;
                    }

                    // FIX SAFESHELL: Gunakan pembungkus kutip ganda berlapis yang kokoh 
                    // Menjamin perintah ekstraksi "unzip -o" tidak pecah meski nama file mengandung spasi
                    String command = "mkdir -p \"" + targetPath + "\" && unzip -o \"" + zipPath + "\" -d \"" + targetPath + "\"";

                    final String result = shizuku.execCommand(command);

                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (hud != null && hud.isShowing()) {
                                hud.dismiss();
                            }
                            
                            try {
    java.lang.reflect.Field field = ShizukuDownloader.class.getDeclaredField("isDownloading");
    field.setAccessible(true); // Membuka paksa akses private menjadi public
    field.set(null, false);    // Mengubah nilainya menjadi false
} catch (Exception ignored) {}


                            // FIX LOGIKA HASIL: Beberapa versi binary babi unzip mengembalikan teks kosong "" saat sukses
                            // Kita periksa apakah file ZIP-nya berhasil dihapus atau perintah tidak mengembalikan null eror
                            if (result != null) {
                                boolean deleted = new File(zipPath).delete();
                                Toast.makeText(
                                        activity,
                                        deleted
                                                ? "Success✅"
                                                : "Skin terpasang, ZIP gagal dihapus",
                                        Toast.LENGTH_LONG
                                ).show();
                            } else {
                                Toast.makeText(
                                        activity,
                                        "Extract gagal ❌",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                    });

                } catch (final Exception e) {
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (hud != null && hud.isShowing()) {
                                hud.dismiss();
                            }
                            
                            try {
    java.lang.reflect.Field field = ShizukuDownloader.class.getDeclaredField("isDownloading");
    field.setAccessible(true); // Membuka paksa akses private menjadi public
    field.set(null, false);    // Mengubah nilainya menjadi false
} catch (Exception ignored) {}

                            
                            Toast.makeText(
                                    activity,
                                    "ERROR : " + e.getMessage(),
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    });
                }
            }
        }).start();
    }
}
