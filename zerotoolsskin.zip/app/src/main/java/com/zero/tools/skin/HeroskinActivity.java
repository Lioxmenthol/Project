package com.zero.tools.skin;

import LEGENDARY.STREAMER.YT.UTIL.*;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.extensions.*;
import androidx.lifecycle.process.*;
import androidx.lifecycle.service.*;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.AndroidSketchwareMaster.*;
import com.AndroidSketchwareMaster.ShizukuMaster;
import com.AndroidSketchwareMaster.ShizukuShell;
import com.AndroidSketchwareMaster.ShizukuShell.OnProcessCompleteListener;
import com.android.volley.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import com.kaopiz.kprogresshud.*;
import com.stx.xhb.androidx.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import rikka.shizuku.Shizuku;
import java.util.HashMap;
import java.io.*;
import java.util.zip.*;
import android.database.*;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.*;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import com.google.android.material.snackbar.Snackbar;

import androidx.core.widget.NestedScrollView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import androidx.core.content.ContextCompat;
import android.graphics.Typeface;
import android.view.View;
import android.widget.TextView;

import android.provider.Settings;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.net.NetworkInterface;
import java.util.Collections;
import java.lang.Process;

import com.zero.tools.skin.security.JsonManager;

/* ====== TAMBAHAN UNTUK DOWNLOAD ANDROID 10+ ====== */
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.net.Uri;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.view.Gravity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;

public class HeroskinActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String files = "";
	private String Npath1 = "";
	private String Npath = "";
	PermissionManager perm;
	String fileNameGlobal;
	long downloadId;
	ProgressDialog progressDialog;
	private String response_server_1 = "";
	private String response_server_2 = "";
	private String response_server_3 = "";
	private String response_server_4 = "";
	private String response_server_5 = "";
	
	private ArrayList<HashMap<String, Object>> lmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listDetailHero = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private RecyclerView recyclerview1;
	private ImageView imageview1;
	private TextView textview2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview3;
	
	private SharedPreferences sp;
	private Intent i = new Intent();
	private RequestNetwork baby;
	private RequestNetwork.RequestListener _baby_request_listener;
	private TimerTask d;
	private SharedPreferences aneh;
	private SharedPreferences down;
	private TimerTask tomer;
	private AlertDialog.Builder dialog;
	private ShizukuMaster fyy;
	private RequestNetwork networkDetail;
	private RequestNetwork.RequestListener _networkDetail_request_listener;
	private RequestNetwork baby2;
	private RequestNetwork.RequestListener _baby2_request_listener;
	private RequestNetwork baby3;
	private RequestNetwork.RequestListener _baby3_request_listener;
	private RequestNetwork baby4;
	private RequestNetwork.RequestListener _baby4_request_listener;
	private RequestNetwork baby5;
	private RequestNetwork.RequestListener _baby5_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.heroskin);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		recyclerview1 = findViewById(R.id.recyclerview1);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		imageview3 = findViewById(R.id.imageview3);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		baby = new RequestNetwork(this);
		aneh = getSharedPreferences("aneh", Activity.MODE_PRIVATE);
		down = getSharedPreferences("down", Activity.MODE_PRIVATE);
		dialog = new AlertDialog.Builder(this);
		networkDetail = new RequestNetwork(this);
		baby2 = new RequestNetwork(this);
		baby3 = new RequestNetwork(this);
		baby4 = new RequestNetwork(this);
		baby5 = new RequestNetwork(this);
		
		_baby_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				response_server_1 = _response;
				_prosesTampilanSkin();
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_networkDetail_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					// 🚀 1. Simpan teks respon internet ke SharedPreferences sebagai cache offline!
					if (sp != null) {
						sp.edit().putString("cache_detail_hero", _response).apply();
					}
					
					// 2. Ambil data teks response internet detail hero dari GitHub
					listDetailHero = new com.google.gson.Gson().fromJson(
					_response, 
					new com.google.gson.reflect.TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
					);
					
					// 3. REFRESH ADAPTER UNIVERSAL DENGAN PEREKAM KOORDINAT SCROLL
					if (recyclerview1 != null) {
						// FIX: Jika adapter belum ada (misal saat instalasi pertama/cache kosong), pasang adapter baru secara instan
						if (recyclerview1.getAdapter() == null) {
							// Ganti 'Recyclerview1Adapter' dengan nama class adapter herodetail Anda yang sebenarnya jika berbeda
							recyclerview1.setAdapter(new Recyclerview1Adapter(listDetailHero));
						} else {
							androidx.recyclerview.widget.RecyclerView.LayoutManager rawManager = recyclerview1.getLayoutManager();
							
							if (rawManager instanceof androidx.recyclerview.widget.GridLayoutManager) {
								androidx.recyclerview.widget.GridLayoutManager layoutManager_kustom = (androidx.recyclerview.widget.GridLayoutManager) rawManager;
								
								// Rekam posisi koordinat baris dan pixel offset saat ini
								int posisiScrollTerakhir = layoutManager_kustom.findFirstVisibleItemPosition();
								
								if (posisiScrollTerakhir != androidx.recyclerview.widget.RecyclerView.NO_POSITION) {
									View viewTeratas = layoutManager_kustom.findViewByPosition(posisiScrollTerakhir);
									int topOffset = (viewTeratas == null) ? 0 : (viewTeratas.getTop() - recyclerview1.getPaddingTop());
									
									// Eksekusi notify secara langsung
									recyclerview1.getAdapter().notifyDataSetChanged();
									
									// 🚀 KUNCI SAKTI: Kembalikan posisi pandangan user secara instan (Ubah > 0 menjadi >= 0 agar posisi 0 ikut terkunci)
									if (posisiScrollTerakhir >= 0) {
										layoutManager_kustom.scrollToPositionWithOffset(posisiScrollTerakhir, topOffset);
									}
								} else {
									recyclerview1.getAdapter().notifyDataSetChanged();
								}
							} else {
								recyclerview1.getAdapter().notifyDataSetChanged();
							}
						}
					}
					
				} catch (Exception e) {
					e.printStackTrace();
					android.widget.Toast.makeText(getApplicationContext(), "Gagal menyelaraskan data detail!", android.widget.Toast.LENGTH_SHORT).show();
				}
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_baby2_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				response_server_2 = _response;
				_prosesTampilanSkin();
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_baby3_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				response_server_3 = _response;
				_prosesTampilanSkin();
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_baby4_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				response_server_4 = _response;
				_prosesTampilanSkin();
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_baby5_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				response_server_5 = _response;
				_prosesTampilanSkin();
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		DialogUtil.applySecureEdgeToEdge(this);
		
		ZeroAdsManager.loadAd(getApplicationContext());
		
		// ========================================================
		// 🚀 STEP 1: TAMENG OFFLINE SAKTI DI BARIS PALING ATAS
		// ========================================================
		String cacheLokal = sp != null ? sp.getString("cache_detail_hero", "") : "";
		if (cacheLokal != null && !cacheLokal.isEmpty()) {
			try {
				listDetailHero = new com.google.gson.Gson().fromJson(
				cacheLokal, 
				new com.google.gson.reflect.TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
				);
			} catch(Exception e) {}
		}
		
		// ========================================================
		// 🚀 STEP 1.5: PENGUNCI FOKUS SAKTI OTOMATIS (ANTI-MELOMPAT KE ATAS)
		// ========================================================
		try {
			if (recyclerview1 != null) {
				android.view.ViewGroup indukOtomatis = (android.view.ViewGroup) recyclerview1.getParent();
				if (indukOtomatis != null) {
					indukOtomatis.setFocusable(true);
					indukOtomatis.setFocusableInTouchMode(true);
					indukOtomatis.setDescendantFocusability(android.view.ViewGroup.FOCUS_BLOCK_DESCENDANTS);
				}
				recyclerview1.setFocusable(false);
				recyclerview1.setFocusableInTouchMode(false);
			}
		} catch (Exception e) {}
		
		// ========================================================
		// 🚀 STEP 2: PENYELAMAT CRASH & ANTI-KEDIP SCROLL
		// ========================================================
		if (recyclerview1 != null) {
			if (recyclerview1.getItemAnimator() != null) {
				recyclerview1.setItemAnimator(null); 
			}
			
			try {
				android.view.LayoutInflater inflater_kustom = (android.view.LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				if (inflater_kustom != null) {
					final View headerView_kustom = inflater_kustom.inflate(R.layout.herodetail, null);
					recyclerview1.setTag(R.id.imageview2, headerView_kustom);
				}
			} catch (Exception e) {}
			
			androidx.recyclerview.widget.GridLayoutManager layoutManager = new androidx.recyclerview.widget.GridLayoutManager(HeroskinActivity.this, 3);
			layoutManager.setSpanSizeLookup(new androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup() {
				@Override
				public int getSpanSize(int position) {
					return (position == 0) ? 3 : 1;
				}
			});
			recyclerview1.setLayoutManager(layoutManager);
			
			// ========================================================
			// 🚀 STEP 3: EKSEKUSI DATA OFFLINE CACHE (FIXED & AMAN)
			// ========================================================
			if (listDetailHero != null && !listDetailHero.isEmpty() && sp != null) {
				String heroTerpilih_onCreate = sp.getString("her", "");
				
				boolean adaDetail = false;
				if (heroTerpilih_onCreate != null && !heroTerpilih_onCreate.isEmpty()) {
					for (java.util.HashMap<String, Object> temp : listDetailHero) {
						if (temp != null && temp.containsKey("her") && String.valueOf(temp.get("her")).equalsIgnoreCase(heroTerpilih_onCreate)) {
							adaDetail = true;
							break;
						}
					}
				}
				
				// FIX: Set adapter terlebih dahulu agar data cache langsung tampil instan tanpa kedip
				if (adaDetail) {
					// Ganti 'Recyclerview1Adapter' dengan nama class adapter herodetail Anda yang sebenarnya jika berbeda
					recyclerview1.setAdapter(new Recyclerview1Adapter(listDetailHero)); 
					
					int posScroll = layoutManager.findFirstVisibleItemPosition();
					if (posScroll != androidx.recyclerview.widget.RecyclerView.NO_POSITION && posScroll >= 0) {
						View vAtas = layoutManager.findViewByPosition(posScroll);
						int offset = (vAtas == null) ? 0 : (vAtas.getTop() - recyclerview1.getPaddingTop());
						
						if (recyclerview1.getAdapter() != null) {
							recyclerview1.getAdapter().notifyDataSetChanged();
						}
						layoutManager.scrollToPositionWithOffset(posScroll, offset);
					}
				}
			}
		}
		
		// ========================================================
		// 🚀 STEP 4: MENARIK DATA TERBARU DARI GITHUB (ONLINE PENYELARAS)
		// ========================================================
		if (networkDetail != null) {
			String urlDetailHero = "https://lioxmenthol.github.io/Detail-hero/detail_hero.json";
			networkDetail.startRequestNetwork("GET", urlDetailHero, "B", _networkDetail_request_listener);
		}
		
		textview2.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 19);
		if (sp != null) {
			textview2.setText(sp.getString("her", ""));
		}
		
		// ========================================================
		// 🚀 TAMENG SAKTI UTAMA: KUNCI FOKUS LAYOUT OTOMATIS
		// ========================================================
		try {
			if (recyclerview1 != null) {
				android.view.ViewGroup indukOtomatis = (android.view.ViewGroup) recyclerview1.getParent();
				if (indukOtomatis != null) {
					indukOtomatis.setFocusable(true);
					indukOtomatis.setFocusableInTouchMode(true);
					indukOtomatis.setDescendantFocusability(android.view.ViewGroup.FOCUS_BLOCK_DESCENDANTS);
				}
				recyclerview1.setFocusable(false);
				recyclerview1.setFocusableInTouchMode(false);
			}
		} catch (Exception e) {}
		
		// ========================================================
		// 🚀 LOAD CACHE KUSTOM PER HERO (PRE-FILTERED & INSTAN)
		// ========================================================
		String namaHero_onCreate = sp != null ? sp.getString("her", "") : "";
		String cacheSkinKustom = (sp != null && !namaHero_onCreate.isEmpty()) ? sp.getString("cache_skin_" + namaHero_onCreate, "") : "";
		
		if (cacheSkinKustom != null && !cacheSkinKustom.isEmpty()) {
			try {
				ArrayList<HashMap<String, Object>> dataMatangCache = new Gson().fromJson(
				cacheSkinKustom,
				new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
				);
				
				if (dataMatangCache != null && dataMatangCache.size() > 0) {
					if (dataMatangCache.size() > 1) {
						ArrayList<HashMap<String, Object>> oriList = new ArrayList<>();
						ArrayList<HashMap<String, Object>> normalList = new ArrayList<>();
						ArrayList<HashMap<String, Object>> targetList = new ArrayList<>();
						
						HashMap<String, Object> firstItem = dataMatangCache.get(0);
						if (firstItem != null) {
							String firstSkinName = String.valueOf(firstItem.get("skin_name") != null ? firstItem.get("skin_name") : "");
							if (firstSkinName.toLowerCase().contains(" to ")) {
								targetList.add(firstItem);
							} else {
								oriList.add(firstItem);
							}
						}
						
						for (int i = 1; i < dataMatangCache.size(); i++) {
							HashMap<String, Object> item = dataMatangCache.get(i);
							if (item == null) continue;
							
							if ("true".equals(String.valueOf(item.get("is_data_hantu")))) {
								continue;
							}
							
							if (item.containsKey("skin_name") && item.get("skin_name") != null) {
								String skinName = String.valueOf(item.get("skin_name"));
								if (skinName.toLowerCase().contains(" to ")) {
									targetList.add(item);
								} else {
									normalList.add(item);
								}
							} else {
								normalList.add(item);
							}
						}
						
						java.util.Collections.sort(normalList, (o1, o2) -> {
							String name1 = String.valueOf(o1.get("skin_name") != null ? o1.get("skin_name") : "");
							String name2 = String.valueOf(o2.get("skin_name") != null ? o2.get("skin_name") : "");
							return name1.compareToIgnoreCase(name2);
						});
						
						java.util.Collections.sort(targetList, (o1, o2) -> {
							String name1 = String.valueOf(o1.get("skin_name") != null ? o1.get("skin_name") : "");
							String name2 = String.valueOf(o2.get("skin_name") != null ? o2.get("skin_name") : "");
							return name1.compareToIgnoreCase(name2);
						});
						
						dataMatangCache.clear();
						dataMatangCache.addAll(oriList);
						dataMatangCache.addAll(normalList);
						dataMatangCache.addAll(targetList);
					}
					
					if (recyclerview1 != null) {
						recyclerview1.setAlpha(0f);
						recyclerview1.setAdapter(new Recyclerview1Adapter(dataMatangCache));
						recyclerview1.animate().alpha(1f).setDuration(180).start();
					}
				}
			} catch (Exception e) {}
		} else {
			// ========================================================
			// BACKUP SYSTEM LAMA: AMBIL DARI DATABASE JSON_CACHE GLOBAL
			// ========================================================
			SharedPreferences cache = getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
			String json = cache != null ? cache.getString("ml", null) : null;
			
			if (json != null && sp != null) {
				try {
					HashMap<String, HashMap<String, Object>> map = new Gson().fromJson(
					json,
					new TypeToken<HashMap<String, HashMap<String, Object>>>(){}.getType()
					);
					
					if (map != null && map.size() > 0) {
						ArrayList<HashMap<String, Object>> just4 = new ArrayList<>();
						
						for (String key : map.keySet()) {
							HashMap<String, Object> heroData = map.get(key);
							if (heroData != null && heroData.containsKey("hero") && heroData.get("hero").toString().equalsIgnoreCase(sp.getString("her", ""))) {
								HashMap<String, Object> m = new HashMap<>();
								m.put("skin_name", heroData.get("skin_name"));
								m.put("img", heroData.get("img"));
								m.put("img2", heroData.get("img2"));
								m.put("url", heroData.get("url"));
								m.put("sort", heroData.get("sort"));
								just4.add(m);
							}
						}
						
						if (just4.size() > 0) {
							_AnehGamingOfficial(just4, "sort");
							
							if (just4.size() > 1) {
								ArrayList<HashMap<String, Object>> oriList = new ArrayList<>();
								ArrayList<HashMap<String, Object>> normalList = new ArrayList<>();
								ArrayList<HashMap<String, Object>> targetList = new ArrayList<>();
								
								HashMap<String, Object> firstItemBackup = just4.get(0);
								if (firstItemBackup != null) {
									String firstSkinNameBackup = String.valueOf(firstItemBackup.get("skin_name") != null ? firstItemBackup.get("skin_name") : "");
									if (firstSkinNameBackup.toLowerCase().contains(" to ")) {
										targetList.add(firstItemBackup);
									} else {
										oriList.add(firstItemBackup);
									}
								}
								
								for (int i = 1; i < just4.size(); i++) {
									HashMap<String, Object> item = just4.get(i);
									if (item == null) continue;
									
									if (item.containsKey("skin_name") && item.get("skin_name") != null) {
										String skinName = String.valueOf(item.get("skin_name"));
										if (skinName.toLowerCase().contains(" to ")) {
											targetList.add(item);
										} else {
											normalList.add(item);
										}
									} else {
										normalList.add(item);
									}
								}
								
								java.util.Collections.sort(normalList, (o1, o2) -> {
									String name1 = String.valueOf(o1.get("skin_name") != null ? o1.get("skin_name") : "");
									String name2 = String.valueOf(o2.get("skin_name") != null ? o2.get("skin_name") : "");
									return name1.compareToIgnoreCase(name2);
								});
								
								java.util.Collections.sort(targetList, (o1, o2) -> {
									String name1 = String.valueOf(o1.get("skin_name") != null ? o1.get("skin_name") : "");
									String name2 = String.valueOf(o2.get("skin_name") != null ? o2.get("skin_name") : "");
									return name1.compareToIgnoreCase(name2);
								});
								
								just4.clear();
								just4.addAll(oriList);
								just4.addAll(normalList);
								just4.addAll(targetList);
							}
							
							if (recyclerview1 != null) {
								recyclerview1.setAlpha(0f);
								recyclerview1.setAdapter(new Recyclerview1Adapter(just4));
								recyclerview1.animate().alpha(1f).setDuration(180).start();
							}
						}
					}
				} catch (Exception e) {}
			}
		}
		
		// ========================================================
		// 🌐 🚀 REFRESH NETWORK: MENEMBAK 5 REPOSITORI SEKALIGUS
		// ========================================================
		response_server_1 = "";
		response_server_2 = "";
		response_server_3 = "";
		response_server_4 = "";
		response_server_5 = "";
		
		try {
			String urlServer1 = JsonManager.getJsonUrl("ml");
			String urlServer2 = JsonManager.getJsonUrl("ml2");
			String urlServer3 = JsonManager.getJsonUrl("ml3");
			String urlServer4 = JsonManager.getJsonUrl("ml4");
			String urlServer5 = JsonManager.getJsonUrl("ml5");
			
			if (baby != null) baby.startRequestNetwork(RequestNetworkController.GET, urlServer1, "AnehGamingKey", _baby_request_listener);
			if (baby2 != null) baby2.startRequestNetwork(RequestNetworkController.GET, urlServer2, "AnehGamingKey2", _baby2_request_listener);
			if (baby3 != null) baby3.startRequestNetwork(RequestNetworkController.GET, urlServer3, "AnehGamingKey3", _baby3_request_listener);
			if (baby4 != null) baby4.startRequestNetwork(RequestNetworkController.GET, urlServer4, "AnehGamingKey4", _baby4_request_listener);
			if (baby5 != null) baby5.startRequestNetwork(RequestNetworkController.GET, urlServer5, "AnehGamingKey5", _baby5_request_listener);
		} catch (Exception e) {}
		
		// ========================================================
		// 🛡️ SAKLAR KEAMANAN OTOMATIS
		// ========================================================
		try {
			com.zero.tools.skin.security.JsonManager.checkSkinSwitch(this);
		} catch (Exception e) {}
		
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		imageview1.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					v.animate().scaleX(0.7f).scaleY(0.7f).setDuration(100).start();
					break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					break;
				}
				return false;
			}
		});
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish(); // 🔥 INI KUNCINYA
			}
		});
		
		// ---------------------
		imageview3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				// =========================
				// ANIMASI
				// =========================
				v.animate()
				.scaleX(0.8f)
				.scaleY(0.8f)
				.setDuration(100)
				.withEndAction(new Runnable() {
					
					@Override
					public void run() {
						
						v.animate()
						.scaleX(1f)
						.scaleY(1f)
						.setDuration(100)
						.start();
						
						final float density =
						getResources()
						.getDisplayMetrics()
						.density;
						
						// =========================
						// LAYOUT
						// =========================
						LinearLayout layout =
						new LinearLayout(
						HeroskinActivity.this
						);
						
						layout.setOrientation(
						LinearLayout.VERTICAL
						);
						
						layout.setPadding(
						40,
						40,
						40,
						30
						);
						
						ScrollView scrollView =
						new ScrollView(
						HeroskinActivity.this
						);
						
						TextView message =
						new TextView(
						HeroskinActivity.this
						);
						
						message.setText(
						"⚠️ INFORMASI & SANGGAHAN (HERO GUIDE DISCLAIMER):\n" +
						"Halaman ini menyajikan informasi referensi, statistik teoretis, simulasi strategi, dan kalkulasi atribut hero yang bertujuan untuk edukasi komunitas penggemar (Unofficial Fan-made Encyclopedia).\n\n" +
						"Seluruh nama karakter, model visual, gambar ikon, lore cerita, dan hak kekayaan intelektual terkait hero yang ditampilkan adalah hak cipta dan milik sepenuhnya dari pemilik sah merek dagang game asli.\n\n" +
						"Aplikasi ini SAMA SEKALI TIDAK memodifikasi, memanipulasi, atau menginterferensi data game asli dalam bentuk apa pun. Data statistik dapat berubah sewaktu-waktu mengikuti penyesuaian keseimbangan (patch update) pada versi game resmi." +
						"\n----------------------------------------\n" +
						"⚠️ INFORMATION & LEGAL DISCLAIMER (HERO GUIDE):\n" +
						"This page provides reference information, theoretical statistics, strategy simulation, and hero attribute calculations intended for community educational purposes (Unofficial Fan-made Encyclopedia).\n\n" +
						"All character names, visual models, icon images, lore, and related intellectual property of the heroes displayed are the exclusive copyrights and trademarks of their respective owners.\n\n" +
						"This application DOES NOT modify, manipulate, or interfere with official game data in any way. Statistical data is subject to change at any time following balance adjustments (patch updates) in the official game version."
						);
						
						
						message.setTextSize(14);
						
						message.setTextColor(
						Color.WHITE
						);
						
						message.setTypeface(
						Typeface.DEFAULT_BOLD
						);
						
						scrollView.addView(message);
						
						layout.addView(scrollView);
						
						// =========================
						// BUTTON CONTAINER
						// =========================
						LinearLayout buttonLayout =
						new LinearLayout(
						HeroskinActivity.this
						);
						
						buttonLayout.setOrientation(
						LinearLayout.HORIZONTAL
						);
						
						buttonLayout.setGravity(
						Gravity.END
						);
						
						LinearLayout.LayoutParams buttonParams =
						new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.WRAP_CONTENT,
						(int) (40 * density)
						);
						
						buttonParams.topMargin =
						(int) (20 * density);
						
						buttonParams.leftMargin =
						(int) (10 * density);
						
						// =========================
						// RESET BUTTON
						// =========================
						Button resetButton =
						new Button(
						HeroskinActivity.this
						);
						
						resetButton.setText(
						"Reset Permission"
						);
						
						resetButton.setTextSize(14);
						
						resetButton.setTextColor(
						Color.WHITE
						);
						
						resetButton.setTypeface(
						Typeface.DEFAULT_BOLD
						);
						
						resetButton.setAllCaps(false);
						
						resetButton.setLayoutParams(
						buttonParams
						);
						
						GradientDrawable resetBg =
						new GradientDrawable();
						
						resetBg.setCornerRadius(
						16 * density
						);
						
						resetBg.setColor(
						Color.parseColor("#4A148C")
						);
						
						resetBg.setStroke(
						3,
						Color.WHITE
						);
						
						resetButton.setBackground(
						resetBg
						);
						
						// =========================
						// OK BUTTON
						// =========================
						Button okButton =
						new Button(
						HeroskinActivity.this
						);
						
						okButton.setText("OK");
						
						okButton.setTextSize(14);
						
						okButton.setTextColor(
						Color.WHITE
						);
						
						okButton.setTypeface(
						Typeface.DEFAULT_BOLD
						);
						
						okButton.setAllCaps(false);
						
						okButton.setLayoutParams(
						buttonParams
						);
						
						GradientDrawable okBg =
						new GradientDrawable();
						
						okBg.setCornerRadius(
						16 * density
						);
						
						okBg.setColor(
						Color.parseColor("#4A148C")
						);
						
						okBg.setStroke(
						3,
						Color.WHITE
						);
						
						okButton.setBackground(okBg);
						
						// =========================
						// ANIMASI BUTTON
						// =========================
						View.OnTouchListener touchAnim =
						new View.OnTouchListener() {
							
							@Override
							public boolean onTouch(
							View btn,
							MotionEvent event
							) {
								
								switch (event.getAction()) {
									
									case MotionEvent.ACTION_DOWN:
									
									btn.animate()
									.scaleX(0.8f)
									.scaleY(0.8f)
									.setDuration(100)
									.start();
									
									break;
									
									case MotionEvent.ACTION_UP:
									
									case MotionEvent.ACTION_CANCEL:
									
									btn.animate()
									.scaleX(1f)
									.scaleY(1f)
									.setDuration(100)
									.start();
									
									break;
								}
								
								return false;
							}
						};
						
						resetButton.setOnTouchListener(
						touchAnim
						);
						
						okButton.setOnTouchListener(
						touchAnim
						);
						
						// =========================
						// ADD BUTTON
						// =========================
						buttonLayout.addView(
						resetButton
						);
						
						buttonLayout.addView(
						okButton
						);
						
						layout.addView(
						buttonLayout
						);
						
						// =========================
						// DIALOG
						// =========================
						AlertDialog.Builder builder =
						new AlertDialog.Builder(
						HeroskinActivity.this
						);
						
						builder.setView(layout);
						
						final AlertDialog dialog =
						builder.create();
						
						dialog.show();
						
						dialog.setCancelable(true);
						
						dialog.setCanceledOnTouchOutside(
						true
						);
						
						GradientDrawable bgDialog =
						new GradientDrawable();
						
						bgDialog.setCornerRadius(
						20 * density
						);
						
						bgDialog.setColor(
						Color.BLACK
						);
						
						bgDialog.setStroke(
						3,
						Color.WHITE
						);
						
						if (dialog.getWindow() != null) {
							
							dialog.getWindow()
							.setBackgroundDrawable(
							bgDialog
							);
						}
						
						// =========================
						// OK CLICK
						// =========================
						okButton.setOnClickListener(
						new View.OnClickListener() {
							
							@Override
							public void onClick(
							View v
							) {
								
								dialog.dismiss();
							}
						}
						);
						
						// =========================
						// RESET PERMISSION
						// =========================
						resetButton.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								dialog.dismiss();
								
								PermissionManager perm = new PermissionManager(HeroskinActivity.this);
								
								// Menghapus seluruh status izin lama termasuk cache iAdb
								sp.edit()
								.remove("DOWNLOAD_MODE")
								.remove("shizuku_selected")
								.remove("IADB_ALLOWED")
								.apply();
								
								AlertDialog.Builder dialog2 = new AlertDialog.Builder(HeroskinActivity.this);
								
								LinearLayout root = new LinearLayout(HeroskinActivity.this);
								root.setOrientation(LinearLayout.VERTICAL);
								root.setPadding(50, 50, 50, 50);
								root.setGravity(Gravity.CENTER_HORIZONTAL);
								
								// MEMBUAT BACKGROUND DIALOG HITAM DENGAN STROKE PUTIH
								GradientDrawable rootBg = new GradientDrawable();
								rootBg.setColor(0xFF000000); 
								rootBg.setCornerRadius(30);  
								rootBg.setStroke(3, Color.WHITE); 
								root.setBackground(rootBg);
								
								// JUDUL DIALOG RESET
								TextView title = new TextView(HeroskinActivity.this);
								title.setText("Select Permission");
								title.setTextSize(20);
								title.setTypeface(Typeface.DEFAULT_BOLD);
								title.setTextColor(Color.WHITE); 
								title.setPadding(30, 20, 30, 20);
								title.setGravity(Gravity.CENTER);
								
								GradientDrawable titleBg = new GradientDrawable();
								titleBg.setColor(0xFF4A148C);
								titleBg.setStroke(3, Color.WHITE);
								titleBg.setCornerRadius(20);
								title.setBackground(titleBg);
								
								// PENGECEKAN OTOMATIS SDK ANDROID
								String osVersion = android.os.Build.VERSION.RELEASE;
								int sdkVersion = android.os.Build.VERSION.SDK_INT;
								
								TextView deviceCheck = new TextView(HeroskinActivity.this);
								deviceCheck.setText("Android " + osVersion + " (SDK " + sdkVersion + ")");
								deviceCheck.setTextSize(14);
								deviceCheck.setTypeface(Typeface.DEFAULT_BOLD);
								deviceCheck.setTextColor(Color.YELLOW); 
								deviceCheck.setGravity(Gravity.CENTER);
								deviceCheck.setPadding(0, 20, 0, 5);
								
								// PESAN & PETUNJUK UTAMA
								TextView msg = new TextView(HeroskinActivity.this);
								msg.setText("Izin hanya diperlukan sekali saja\n\nAplikasi ini mungkin tidak berfungsi dengan baik tanpa izin yang diminta. Silakan pilih salah satu dari opsi di bawah ini untuk memberikan izin");
								msg.setTextColor(Color.WHITE); 
								msg.setTextSize(14);
								msg.setGravity(Gravity.CENTER);
								msg.setPadding(20, 10, 20, 20);
								
								// TOMBOL-TOMBOL OPSI DIALOG RESET
								Button defaultBtn = new Button(HeroskinActivity.this);
								Button shizukuBtn = new Button(HeroskinActivity.this);
								Button iadbBtn = new Button(HeroskinActivity.this);
								Button tutorialBtn = new Button(HeroskinActivity.this);
								Button laterBtn = new Button(HeroskinActivity.this);
								
								defaultBtn.setText("Default");
								shizukuBtn.setText("Shizuku");
								iadbBtn.setText("iAdb (Coming Soon)"); 
								tutorialBtn.setText("Tutorial");
								laterBtn.setText("Later");
								
								Button[] buttons = {defaultBtn, shizukuBtn, iadbBtn, tutorialBtn, laterBtn};
								
								LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
								LinearLayout.LayoutParams.MATCH_PARENT,
								LinearLayout.LayoutParams.WRAP_CONTENT
								);
								p.setMargins(0, 15, 0, 15);
								
								// PROSES STYLING & ANIMASI TOMBOL RESET
								for (Button b : buttons) {
									GradientDrawable bg = new GradientDrawable();
									bg.setColor(0xFF4A148C);
									bg.setStroke(3, Color.WHITE);
									bg.setCornerRadius(18);
									
									b.setLayoutParams(p);
									b.setBackground(bg);
									b.setBackgroundTintList(null);
									b.setStateListAnimator(null);
									b.setTextColor(Color.WHITE);
									b.setAllCaps(false);
									b.setTypeface(Typeface.DEFAULT_BOLD);
									b.setPadding(20, 20, 20, 20);
									
									b.setOnTouchListener((v1, event) -> {
										switch (event.getAction()) {
											case MotionEvent.ACTION_DOWN:
											v1.animate().scaleX(0.90f).scaleY(0.90f).setDuration(100).start();
											break;
											case MotionEvent.ACTION_UP:
											case MotionEvent.ACTION_CANCEL:
											v1.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
											break;
										}
										return false;
									});
								}
								
								iadbBtn.setAlpha(0.6f); 
								
								// FOOTER TEXTVIEW DENGAN LINK PRIVACY POLICY
								TextView privacyText = new TextView(HeroskinActivity.this);
								privacyText.setGravity(Gravity.CENTER);
								privacyText.setPadding(20, 30, 20, 10);
								privacyText.setTextSize(13);
								privacyText.setTextColor(Color.WHITE); 
								
								String fullText = "Dengan memilih salah satu metode izin di atas, Anda menyetujui Kebijakan Privasi kami.";
								android.text.SpannableString ss = new android.text.SpannableString(fullText);
								
								android.text.style.ClickableSpan clickableSpan = new android.text.style.ClickableSpan() {
									@Override
									public void onClick(View textView) {
										try {
											Intent intentPrivacy = new Intent(Intent.ACTION_VIEW, Uri.parse("https://thecobraa.blogspot.com/p/explore-wallpaper.html"));
											startActivity(intentPrivacy);
										} catch (Exception e) {
											Toast.makeText(HeroskinActivity.this, "Gagal membuka Kebijakan Privasi", Toast.LENGTH_SHORT).show();
										}
									}
									
									@Override
									public void updateDrawState(android.text.TextPaint ds) {
										ds.setColor(Color.CYAN);
										ds.setUnderlineText(true);
										ds.setFakeBoldText(false);
									}
								};
								
								String keyword = "Kebijakan Privasi";
								
								int start = fullText.indexOf(keyword);
								int end = start + keyword.length();
								
								ss.setSpan(
								clickableSpan,
								start,
								end,
								Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
								);
								
								privacyText.setText(ss);
								privacyText.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
								
								// LAYOUT SUSUNAN DIALOG KEDUA
								LinearLayout content = new LinearLayout(HeroskinActivity.this);
								content.setOrientation(LinearLayout.VERTICAL);
								
								content.addView(title);
								content.addView(deviceCheck); 
								content.addView(msg);         
								content.addView(defaultBtn);
								content.addView(shizukuBtn);
								content.addView(iadbBtn);
								content.addView(tutorialBtn);
								content.addView(laterBtn);
								content.addView(privacyText); 
								
								root.addView(content);
								dialog2.setView(root);
								
								final AlertDialog d2 = dialog2.create();
								
								if (d2.getWindow() != null) {
									d2.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
								}
								
								d2.show();
								
								// EVENT KLIK TOMBOL DIALOG RESET
								defaultBtn.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										sp.edit().putString("DOWNLOAD_MODE", "DEFAULT").apply();
										d2.dismiss();
										perm.RequestDataPermission();
									}
								});
								
								shizukuBtn.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										sp.edit().putString("DOWNLOAD_MODE", "SHIZUKU").putBoolean("shizuku_selected", false).apply();
										d2.dismiss();
										
										if (fyy == null || !fyy.isShizukuInstalled()) {
											Toast.makeText(HeroskinActivity.this, "Shizuku belum terinstall / siap", Toast.LENGTH_SHORT).show();
											return;
										}
										fyy.requestPermission();
										Toast.makeText(HeroskinActivity.this, "Shizuku Mode✅Klik Allow jika belum", Toast.LENGTH_SHORT).show();
									}
								});
								
								iadbBtn.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										Toast.makeText(HeroskinActivity.this, "Fitur iAdb segera hadir di pembaruan mendatang! 🚀", Toast.LENGTH_SHORT).show();
									}
								});
								
								tutorialBtn.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										try {
											startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/playlist?list=PL3fU1kworLKPIT97AfWDdqXX6Ni68HgyH&si=7PMRbc0mJTnhcUKX")));
										} catch (Exception e) {
											Toast.makeText(HeroskinActivity.this, "Gagal membuka tautan tutorial", Toast.LENGTH_SHORT).show();
										}
									}
								});
								
								laterBtn.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View v) {
										d2.dismiss();
									}
								});
							}
						});
						
					}
				})
				.start();
			}
		});
		
		perm = new PermissionManager(this);
		try {
			fyy = new ShizukuMaster(getApplicationContext());
		} catch (Exception e) {
			e.printStackTrace();
		}
		BroadcastReceiver onComplete = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				
				long id = intent.getLongExtra(
				DownloadManager.EXTRA_DOWNLOAD_ID,
				-1
				);
				
				if (id != downloadId) return;
				
				Toast.makeText(
				getApplicationContext(),
				"Download completed",
				Toast.LENGTH_SHORT
				).show();
			}
		};
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
			registerReceiver(onComplete,
			new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
			Context.RECEIVER_NOT_EXPORTED
			);
		} else {
			registerReceiver(onComplete,
			new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		if (perm != null) {
			perm.onActivityResult(
			_requestCode,
			_resultCode,
			_data
			);
		}
		
		// TRIK MUTLAK: Deteksi pembatalan folder SAF langsung di activity utama
		if (_requestCode == 1001) { // 1001 adalah NEW_FOLDER_REQUEST_CODE dari PermissionManager Anda
			if (_resultCode != Activity.RESULT_OK || _data == null || _data.getData() == null) {
				
				// Kosongkan DOWNLOAD_MODE di file sp utama Sketchware Anda secara paksa!
				sp.edit().putString("DOWNLOAD_MODE", "").apply();
				
				Toast.makeText(HeroskinActivity.this,
				"Izin dibatalkan, silakan pilih mode kembali",
				Toast.LENGTH_SHORT).show();
			}
		}
		
		// INTEGRASI SWITCH CASE UNTUK HANDLER BERBAGAI REQUEST CODE
		switch (_requestCode) {
			// Bagian iADB sengaja dikosongkan dari switch case ini karena
			// library iAdb Anda memproses callback via OnRequestPermissionResultListener internal.
			// Anda bisa menambahkan request code library lain di bawah sini jika dibutuhkan kelak.
			default:
			break;
		}
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	
	@Override
	public void onResume() {
		super.onResume();
		final SharedPreferences prefs =
		getSharedPreferences("app_prefs", MODE_PRIVATE);
		
		long now = System.currentTimeMillis();
		long lastShown = prefs.getLong("lastAlertTime", 0);
		
		// Cooldown 10 detik
		if (now - lastShown < 10_000) {
			return;
		}
		
		// Tunda lebih lama supaya iklan tidak terganggu
		new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
			@Override
			public void run() {
				
				if (isFinishing() || isDestroyed()) return;
				
				// 🔒 Cek ringan & aman (urutan penting)
				boolean blocked = false;
				
				if (_isBlockedDNS()) {
					blocked = true;
				} else if (_isVPNEnabled()) {
					blocked = true;
				}
				// ❌ _checkAdBlock() sengaja DIHILANGKAN
				// karena berat & sering bikin delay
				
				if (blocked) {
					// ✅ Dialog muncul saat UI sudah stabil
					_showBlockDialog();
					
					prefs.edit()
					.putLong("lastAlertTime", System.currentTimeMillis())
					.apply();
				}
			}
		}, 3000);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (fyy != null) {
			// Handler ini bertugas menghangatkan koneksi Binder sejak awal aplikasi dibuka
			final Handler handler = new Handler();
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					
					if (fyy.isShizukuAvailable()) {
						
						// Sinkronisasikan status izin asli secara otomatis ke SharedPreferences
						try {
							boolean allowed = fyy.hasPermission();
							sp.edit().putBoolean("SHIZUKU_ALLOWED", allowed).commit();
						} catch (Exception ignored) {}
						
						// Bagian pemulihan dokumen SAF Anda (hanya jalan jika shizuku_selected true)
						if (sp.getBoolean("shizuku_selected", false)) {
							String savedUri = sp.getString("FOLDER_URI", null);
							if (savedUri != null) {
								final Uri muri = Uri.parse(savedUri);
								final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
								| Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
								try {
									getContentResolver().takePersistableUriPermission(muri, takeFlags);
									sp.edit().putBoolean("shizuku_selected", false).commit();
									SketchwareUtil.showMessage(getApplicationContext(), "Shizuku permission restored✅");
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}
						
					} else {
						// Jika Binder belum terikat sempurna di latar belakang, lakukan retry setiap 500ms
						handler.postDelayed(this, 500);
					}
				}
			}, 500); // Delay pertama 500ms
		}
		
	}
	public void _setCornerRadius(final View _view, final double _value, final String _color) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_value);
		_view.setBackground(gd);
		_view.setElevation(5);
	}
	
	
	public void _Anehgaminginejvtor(final ImageView _img, final String _file, final String _url) {
		Glide.with(getContext(this)).load(_url).thumbnail(Glide.with(getContext(this)).load(getContext(this).getResources().getIdentifier(_file, "drawable", getContext(this).getPackageName()))).fitCenter().into(_img);
	}
	public Context getContext(Context c) {
		return c;
	}
	public Context getContext(Fragment f) {
		return f.getActivity();
	}
	public Context getContext(DialogFragment df) {
		return df.getActivity();
	}
	{
	}
	
	
	public void _AnehGamingOfficial(final ArrayList<HashMap<String, Object>> _listmap, final String _aneh) {
		Comparator list_sorter = new Comparator<HashMap<String, Object>>(){
			@Override
			public int compare(HashMap<String, Object> map2, HashMap<String, Object> map1){
				
				try {
					Double num1 = Double.parseDouble(map1.get(_aneh).toString());
					Double num2 = Double.parseDouble(map2.get(_aneh).toString());
					return Double.compare(num2, num1);
				} catch (NumberFormatException e){
					return map2.get(_aneh).toString().compareTo(map1.get(_aneh).toString());
				}
				
			}
		};
		
		Collections.sort(_listmap, list_sorter);
	}
	
	
	public void _setProperties(final View _view, final double _radius, final double _stroke, final String _strokeColor, final String _bgColor) {
		_view.setBackground(new android.graphics.drawable.GradientDrawable() {
			
			public android.graphics.drawable.GradientDrawable getIns(int a, int b, int c, int d) {
				
				this.setCornerRadius(a);
				this.setStroke(b, c);
				this.setColor(d);
				return this;
			}
		}
		.getIns((int)_radius, (int)_stroke, Color.parseColor(_strokeColor), Color.parseColor(_bgColor)));
	}
	
	
	public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9e9e9e")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		} else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			_view.setBackground(gd);
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
		}
		if (_clickAnim) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
		_view.setClipToOutline(true);
	}
	
	
	public boolean _checkAdBlock() {
		if (_isVPNEnabled() || _isBlockedDNS()) {
			return true; // hanya kembalikan nilai
		}
		return false;
	}
	
	
	public boolean _isVPNEnabled() {
		try {
			// ================================
			// 1) VPN RESMI (PALING AMAN)
			// ================================
			ConnectivityManager cm =
			(ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
			
			if (cm != null) {
				Network network = cm.getActiveNetwork();
				NetworkCapabilities caps = cm.getNetworkCapabilities(network);
				
				if (caps != null &&
				caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
					return true;
				}
			}
			
			// ================================
			// 2) INTERFACE CHECK (BACKUP)
			// ================================
			for (NetworkInterface ni :
			java.util.Collections.list(NetworkInterface.getNetworkInterfaces())) {
				
				if (!ni.isUp() || ni.isLoopback()) continue;
				
				String name = ni.getName().toLowerCase(); // pakai getName(), lebih aman
				
				if (name.contains("tun")
				|| name.contains("wg")
				|| name.contains("ppp")) {
					
					return true;
				}
			}
			
			return false;
			
		} catch (Exception e) {
			return false;
		}
		
	}
	
	
	public boolean _isBlockedDNS() {
		try {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
				String mode = Settings.Global.getString(
				getContentResolver(),
				"private_dns_mode"
				);
				
				String host = Settings.Global.getString(
				getContentResolver(),
				"private_dns_specifier"
				);
				
				if ("hostname".equals(mode) && host != null) {
					host = host.toLowerCase();
					return host.contains("adguard")
					|| host.contains("nextdns")
					|| host.contains("blokada");
				}
			}
		} catch (Throwable ignored) {}
		return false;
	}
	
	
	public void _showBlockDialog() {
		if (isFinishing() || isDestroyed()) return;
		
		androidx.appcompat.app.AlertDialog.Builder builder =
		new androidx.appcompat.app.AlertDialog.Builder(this);
		
		builder.setTitle("Koneksi Tidak Stabil • Unstable Connection");
		
		builder.setMessage(
		"Beberapa pengaturan jaringan atau DNS dapat memengaruhi " +
		"kestabilan koneksi aplikasi.\n\n" +
		"Jika Anda mengalami kendala, silakan nonaktifkan sementara " +
		"pengaturan tersebut lalu coba kembali.\n\n" +
		"Some network or DNS configurations may affect the app’s " +
		"connection stability.\n\n" +
		"If you experience issues, please temporarily disable such " +
		"settings and try again."
		);
		
		// ✅ Biarkan user bisa dismiss
		builder.setCancelable(true);
		
		// 🔁 COBA LAGI / RETRY
		builder.setPositiveButton("Coba Lagi / Retry",
		new android.content.DialogInterface.OnClickListener() {
			@Override
			public void onClick(android.content.DialogInterface dialog, int which) {
				
				dialog.dismiss();
				
				// Cek ulang DNS secara ringan
				if (!_isBlockedDNS()) {
					// lanjutkan aplikasi
					// contoh: loadData(); atau refresh halaman
				}
			}
		});
		
		// ⬅️ KEMBALI / BACK (lebih aman daripada force close)
		builder.setNegativeButton("Kembali / Back",
		new android.content.DialogInterface.OnClickListener() {
			@Override
			public void onClick(android.content.DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		
		builder.show();
		
	}
	
	
	public void _initShizukuOnCreate() {
		try {
			fyy = new ShizukuMaster(getApplicationContext());
		} catch (Exception e) {
		}
	}
	
	
	public void _CheckShizukuOnStart() {
		if (fyy == null) return;
		
		try {
			
			boolean installed = fyy.isShizukuInstalled();
			boolean available = fyy.isShizukuAvailable();
			boolean allowed = false;
			
			if (installed && available) {
				allowed = fyy.hasPermission();
			}
			
			sp.edit()
			.putBoolean("SHIZUKU_ALLOWED", allowed)
			.apply();
			
		} catch (Exception e) {
			
			sp.edit()
			.putBoolean("SHIZUKU_ALLOWED", false)
			.apply();
			
		}
	}
	
	
	public void _showModeDialog() {
		AlertDialog.Builder dialog = new AlertDialog.Builder(HeroskinActivity.this);
		
		LinearLayout root = new LinearLayout(HeroskinActivity.this);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setPadding(50, 50, 50, 50);
		root.setGravity(Gravity.CENTER_HORIZONTAL);
		
		// ================= MEMBUAT BACKGROUND DIALOG HITAM DENGAN SUDUT MELENGKUNG =================
		GradientDrawable rootBg = new GradientDrawable();
		rootBg.setColor(0xFF000000); // Warna Hitam Pekat
		rootBg.setCornerRadius(30);
		rootBg.setStroke(3, Color.WHITE);  // Membuat sudut dialog melengkung halus
		root.setBackground(rootBg);
		
		// ================= 1. JUDUL DIALOG =================
		TextView title = new TextView(HeroskinActivity.this);
		title.setText("Permission Required");
		title.setTextSize(20);
		title.setTypeface(Typeface.DEFAULT_BOLD);
		title.setTextColor(Color.WHITE); // Dipastikan Putih
		title.setPadding(30, 20, 30, 20);
		title.setGravity(Gravity.CENTER);
		
		GradientDrawable titleBg = new GradientDrawable();
		titleBg.setColor(0xFF4A148C);
		titleBg.setStroke(3, Color.WHITE);
		titleBg.setCornerRadius(20);
		title.setBackground(titleBg);
		
		// ================= 2. PENGECEKAN OTOMATIS SDK ANDROID =================
		String osVersion = android.os.Build.VERSION.RELEASE;
		int sdkVersion = android.os.Build.VERSION.SDK_INT;
		
		TextView deviceCheck = new TextView(HeroskinActivity.this);
		deviceCheck.setText("Android " + osVersion + " (SDK " + sdkVersion + ")");
		deviceCheck.setTextSize(14);
		deviceCheck.setTypeface(Typeface.DEFAULT_BOLD);
		deviceCheck.setTextColor(Color.YELLOW); // Warna kuning agar kontras di atas background hitam
		deviceCheck.setGravity(Gravity.CENTER);
		deviceCheck.setPadding(0, 20, 0, 5);
		
		// ================= 3. PESAN & PETUNJUK UTAMA =================
		TextView msg = new TextView(HeroskinActivity.this);
		msg.setText("Izin hanya diperlukan sekali saja\n\nAplikasi ini mungkin tidak berfungsi dengan baik tanpa izin yang diminta. Silakan pilih salah satu dari opsi di bawah ini untuk memberikan izin");
		msg.setTextColor(Color.WHITE); // Dipastikan Putih
		msg.setTextSize(14);
		msg.setGravity(Gravity.CENTER);
		msg.setPadding(20, 10, 20, 20);
		
		// ================= 4. TOMBOL-TOMBOL OPSI =================
		Button def = new Button(HeroskinActivity.this);
		Button shizuku = new Button(HeroskinActivity.this);
		Button iadb = new Button(HeroskinActivity.this); 
		Button tutorial = new Button(HeroskinActivity.this);
		Button later = new Button(HeroskinActivity.this);
		
		def.setText("Default");
		shizuku.setText("Shizuku");
		iadb.setText("iAdb (Coming Soon)"); 
		tutorial.setText("Tutorial");
		later.setText("Later");
		
		Button[] btns = {def, shizuku, iadb, tutorial, later};
		
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
		LinearLayout.LayoutParams.MATCH_PARENT,
		LinearLayout.LayoutParams.WRAP_CONTENT
		);
		params.setMargins(0, 15, 0, 15);
		
		// PROSES STYLING & PENAMBAHAN ANIMASI GERAK OTOMATIS
		for (Button b : btns) {
			GradientDrawable bg = new GradientDrawable();
			bg.setColor(0xFF4A148C);
			bg.setStroke(3, Color.WHITE);
			bg.setCornerRadius(18);
			
			b.setLayoutParams(params);
			b.setBackground(bg);
			b.setBackgroundTintList(null);
			b.setStateListAnimator(null);
			b.setTextColor(Color.WHITE); // Text di dalam button tetap Putih
			b.setAllCaps(false);
			b.setTypeface(Typeface.DEFAULT_BOLD);
			b.setPadding(20, 20, 20, 20);
			
			b.setOnTouchListener((v, event) -> {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					v.animate().scaleX(0.90f).scaleY(0.90f).setDuration(100).start();
					break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					break;
				}
				return false;
			});
		}
		
		// Mengurangi kepekatan tombol iADB karena statusnya Coming Soon
		iadb.setAlpha(0.6f); 
		
		// ================= 5. FOOTER TEXTVIEW DENGAN LINK PRIVACY POLICY =================
		TextView privacyText = new TextView(HeroskinActivity.this);
		privacyText.setGravity(Gravity.CENTER);
		privacyText.setPadding(20, 30, 20, 10);
		privacyText.setTextSize(13);
		privacyText.setTextColor(Color.WHITE); // Teks utama diubah menjadi Putih
		
		String fullText = "Dengan memilih salah satu metode izin di atas, Anda menyetujui Kebijakan Privasi kami.";
		android.text.SpannableString ss = new android.text.SpannableString(fullText);
		
		android.text.style.ClickableSpan clickableSpan = new android.text.style.ClickableSpan() {
			@Override
			public void onClick(View textView) {
				try {
					Intent intentPrivacy = new Intent(Intent.ACTION_VIEW, Uri.parse("https://blogspot.com"));
					startActivity(intentPrivacy);
				} catch (Exception e) {
					Toast.makeText(HeroskinActivity.this, "Gagal membuka Kebijakan Privasi", Toast.LENGTH_SHORT).show();
				}
			}
			
			@Override
			public void updateDrawState(android.text.TextPaint ds) {
				ds.setColor(Color.CYAN);
				ds.setUnderlineText(true);
				ds.setFakeBoldText(false);
			}
		};
		
		// Target kata "Kebijakan Privasi" (indeks 41 sampai 58)
		String keyword = "Kebijakan Privasi";
		
		int start = fullText.indexOf(keyword);
		int end = start + keyword.length();
		
		ss.setSpan(
		clickableSpan,
		start,
		end,
		Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
		);
		
		privacyText.setText(ss);
		privacyText.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());
		
		
		// ================= LAYOUT SUSUNAN DIALOG =================
		LinearLayout content = new LinearLayout(HeroskinActivity.this);
		content.setOrientation(LinearLayout.VERTICAL);
		
		content.addView(title);
		content.addView(deviceCheck); 
		content.addView(msg);         
		content.addView(def);
		content.addView(shizuku);
		content.addView(iadb); 
		content.addView(tutorial);
		content.addView(later);
		content.addView(privacyText); 
		
		root.addView(content);
		dialog.setView(root);
		
		AlertDialog d = dialog.create();
		
		// 🔥 KUNCI UTAMA: Menghilangkan paksa background abu-abu/hitam bawaan Android AlertDialog
		if (d.getWindow() != null) {
			d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
		}
		
		def.setOnClickListener(v -> {
			sp.edit().putString("DOWNLOAD_MODE", "DEFAULT").apply();
			d.dismiss();
			PermissionManager pm = new PermissionManager(HeroskinActivity.this);
			if (!pm.IsPermissionGranted()) {
				pm.RequestDataPermission();
			}
		});
		
		shizuku.setOnClickListener(v -> {
			sp.edit().putString("DOWNLOAD_MODE", "SHIZUKU").apply();
			d.dismiss();
			
			if (fyy != null && fyy.isShizukuInstalled()) {
				boolean hasPerm = false;
				try { 
					hasPerm = fyy.hasPermission(); 
				} catch (Exception e) { 
					hasPerm = false; 
				}
				
				if (!hasPerm) {
					fyy.requestPermission();
					Toast.makeText(HeroskinActivity.this,
					"Klik 'Allow' lalu klik lagi untuk mendownload",
					Toast.LENGTH_SHORT).show();
				}
			} else {
				Toast.makeText(HeroskinActivity.this, 
				"Shizuku belum terinstall / belum siap", 
				Toast.LENGTH_SHORT).show();
			}
		});
		
		// ================= iADB =================
		iadb.setOnClickListener(v -> {
			// Reset mode agar user tidak terjebak di mode iADB yang belum siap
			sp.edit().putString("DOWNLOAD_MODE", "").apply();
			d.dismiss();
			
			// Toast pemberitahuan murni ke pengguna
			Toast.makeText(HeroskinActivity.this, "Fitur iAdb segera hadir di pembaruan mendatang! 🚀", Toast.LENGTH_LONG).show();
		});
		
		
		// ================= TUTORIAL =================
		tutorial.setOnClickListener(v -> {
			try {
				Intent intentUtube = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com"));
				startActivity(intentUtube);
			} catch (Exception e) {
				Toast.makeText(HeroskinActivity.this, "Gagal membuka tautan tutorial", Toast.LENGTH_SHORT).show();
			}
		});
		
		// ================= LATER =================
		later.setOnClickListener(v -> {
			sp.edit().putString("DOWNLOAD_MODE", "").apply();
			d.dismiss();
		});
		
		// ================= ANTISIPASI BACK / KLIK LUAR DIALOG =================
		d.setOnCancelListener(dialogInterface -> {
			sp.edit().putString("DOWNLOAD_MODE", "").apply();
		});
		
		d.show();
	}
	
	
	public void _prosesTampilanSkin() {
		try {
			Gson gson = new Gson();
			java.lang.reflect.Type type = new TypeToken<HashMap<String, HashMap<String, Object>>>() {}.getType();
			
			String heroTerpilih = sp.getString("her", "");
			if (heroTerpilih == null || heroTerpilih.isEmpty()) return; // FIX 1: Cegah NPE jika SharedPreferences null
			
			ArrayList<HashMap<String, Object>> just4 = new ArrayList<>();
			String[] semuaResponse = {response_server_1, response_server_2, response_server_3, response_server_4, response_server_5};
			java.util.HashSet<String> skinDuplicateCheck = new java.util.HashSet<>();
			
			// ========================================================
			// 🔎 SIKAT & FILTER DATA DARI 5 SERVER SEKALIGUS
			// ========================================================
			for (String resp : semuaResponse) {
				if (resp != null && !resp.trim().isEmpty()) {
					try {
						HashMap<String, HashMap<String, Object>> map = gson.fromJson(resp, type);
						if (map != null) {
							for (String key : map.keySet()) {
								HashMap<String, Object> heroData = map.get(key);
								
								if (heroData != null && heroData.get("hero") != null && heroData.get("hero").toString().equalsIgnoreCase(heroTerpilih)) { // OPTIMASI: Gunakan equalsIgnoreCase
									
									String skinName = String.valueOf(heroData.get("skin_name") != null ? heroData.get("skin_name") : "");
									
									if ("true".equals(String.valueOf(heroData.get("is_data_hantu")))) {
										continue;
									}
									
									if (!skinDuplicateCheck.contains(skinName)) {
										skinDuplicateCheck.add(skinName);
										
										HashMap<String, Object> m = new HashMap<>();
										m.put("skin_name", heroData.get("skin_name"));
										m.put("img", heroData.get("img"));
										m.put("img2", heroData.get("img2"));
										m.put("url", heroData.get("url"));
										m.put("sort", heroData.get("sort"));
										just4.add(m);
									}
								}
							}
						}
					} catch (Exception e) {
						// Lanjut ke server berikutnya jika ada JSON rusak
					}
				}
			}
			
			if (just4.isEmpty()) {
				return;
			}
			
			// ========================================================
			// 🔥 SORTING UTAMA BAWAAN
			// ========================================================
			_AnehGamingOfficial(just4, "sort");
			
			// ========================================================
			// 🔥 STRUKTUR URUTAN PREMIUM GABUNGAN
			// ========================================================
			if (just4.size() > 1) {
				ArrayList<HashMap<String, Object>> oriList = new ArrayList<>();
				ArrayList<HashMap<String, Object>> normalList = new ArrayList<>();
				ArrayList<HashMap<String, Object>> targetList = new ArrayList<>();
				
				// FIX 2: Kunci item indeks 0 HANYA JIKA data valid
				HashMap<String, Object> firstItem = just4.get(0);
				if (firstItem != null) {
					String firstSkinName = String.valueOf(firstItem.get("skin_name") != null ? firstItem.get("skin_name") : "");
					// Jika item pertama mengandung " to ", jangan dipaksa masuk OriList agar urutan tidak berantakan
					if (firstSkinName.toLowerCase().contains(" to ")) {
						targetList.add(firstItem);
					} else {
						oriList.add(firstItem);
					}
				}
				
				for (int i = 1; i < just4.size(); i++) {
					HashMap<String, Object> item = just4.get(i);
					if (item == null) continue;
					
					if (item.containsKey("skin_name") && item.get("skin_name") != null) {
						String skinName = String.valueOf(item.get("skin_name"));
						if (skinName.toLowerCase().contains(" to ")) {
							targetList.add(item);
						} else {
							normalList.add(item);
						}
					} else {
						normalList.add(item);
					}
				}
				
				// Urutkan Normal A-Z
				java.util.Collections.sort(normalList, (o1, o2) -> {
					String name1 = String.valueOf(o1.get("skin_name") != null ? o1.get("skin_name") : "");
					String name2 = String.valueOf(o2.get("skin_name") != null ? o2.get("skin_name") : "");
					return name1.compareToIgnoreCase(name2);
				});
				
				// Urutkan Transisi " to " A-Z
				java.util.Collections.sort(targetList, (o1, o2) -> {
					String name1 = String.valueOf(o1.get("skin_name") != null ? o1.get("skin_name") : "");
					String name2 = String.valueOf(o2.get("skin_name") != null ? o2.get("skin_name") : "");
					return name1.compareToIgnoreCase(name2);
				});
				
				just4.clear();
				just4.addAll(oriList);
				just4.addAll(normalList);
				just4.addAll(targetList);
			}
			
			// ========================================================
			// 👻 SISIPKAN SLOT DATA HANTU JIKA ONLINE DETAIL TERSEDIA
			// ========================================================
			boolean adaDetailHeroOnline = false;
			if (listDetailHero != null && !listDetailHero.isEmpty()) {
				for (int i = 0; i < listDetailHero.size(); i++) {
					java.util.HashMap<String, Object> tempHero = listDetailHero.get(i);
					if (tempHero != null && tempHero.containsKey("her") && String.valueOf(tempHero.get("her")).equalsIgnoreCase(heroTerpilih)) {
						adaDetailHeroOnline = true;
						break;
					}
				}
			}
			
			if (adaDetailHeroOnline) {
				java.util.HashMap<String, Object> dataHantuTiruan = new java.util.HashMap<>();
				dataHantuTiruan.put("is_data_hantu", "true");
				dataHantuTiruan.put("skin_name", "DataHantuPembukaSlot");
				just4.add(dataHantuTiruan);
			}
			
			// ========================================================
			// 💾 SIMPAN KE CACHE HERO SPESIFIK
			// ========================================================
			String jsonFinalHero = gson.toJson(just4);
			sp.edit().putString("cache_skin_" + heroTerpilih, jsonFinalHero).apply();
			
			// ========================================================
			// 📍 REKAM & LOCK KOORDINAT POSISI SCROLL (ANTI-LOMPAT)
			// ========================================================
			int posisiScrollTerakhir = 0;
			int topOffset = 0;
			androidx.recyclerview.widget.GridLayoutManager layoutManager_kustom = null;
			
			if (recyclerview1 != null && recyclerview1.getLayoutManager() instanceof androidx.recyclerview.widget.GridLayoutManager) {
				layoutManager_kustom = (androidx.recyclerview.widget.GridLayoutManager) recyclerview1.getLayoutManager();
				posisiScrollTerakhir = layoutManager_kustom.findFirstVisibleItemPosition();
				if (posisiScrollTerakhir != androidx.recyclerview.widget.RecyclerView.NO_POSITION) { // FIX 3: Validasi indeks posisi scroll
					View viewTeratas = layoutManager_kustom.findViewByPosition(posisiScrollTerakhir);
					topOffset = (viewTeratas == null) ? 0 : (viewTeratas.getTop() - recyclerview1.getPaddingTop());
				}
			}
			
			// ========================================================
			// 📱 SEGARKAN TAMPILAN LAYAR RECYCLERVIEW
			// ========================================================
			if (recyclerview1 != null) {
				recyclerview1.setAdapter(new Recyclerview1Adapter(just4));
				recyclerview1.setAlpha(1f);
				
				if (layoutManager_kustom != null && posisiScrollTerakhir >= 0) { // FIX 4: Ubah > 0 menjadi >= 0 agar posisi indeks ke-0 ikut terkunci
					layoutManager_kustom.scrollToPositionWithOffset(posisiScrollTerakhir, topOffset);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void _dekorasiDetailHero(final HashMap<String, Object> _data, final View _view) {
		if (_data == null || _view == null) return;
		
		final LinearLayout layoutHeroStats = _view.findViewById(R.id.layoutHeroStats);
		LinearLayout layoutSkillTitle = _view.findViewById(R.id.layoutSkillTitle);
		LinearLayout layoutSkillDesc = _view.findViewById(R.id.layoutSkillDesc);
		LinearLayout layoutBestBuild = _view.findViewById(R.id.layoutBestBuild);
		LinearLayout layoutSkillIconContainer = _view.findViewById(R.id.layoutSkillIcon);
		
		TextView heroRole = _view.findViewById(R.id.heroRole);
		TextView textSkillTitle = _view.findViewById(R.id.textSkillTitle);
		TextView textSkillDesc = _view.findViewById(R.id.textSkillDesc);
		TextView textBestBuild = _view.findViewById(R.id.textBestBuild);
		
		ImageView imageview2 = _view.findViewById(R.id.imageview2);
		ImageView imgPasif = _view.findViewById(R.id.imgSkillPasif); 
		ImageView imgSkill1 = _view.findViewById(R.id.imgSkill1);
		ImageView imgSkill2 = _view.findViewById(R.id.imgSkill2);
		ImageView imgSkillUlt = _view.findViewById(R.id.imgSkillUlt);
		
		ProgressBar pDur = _view.findViewById(R.id.progressDurability);
		ProgressBar pOff = _view.findViewById(R.id.progressOffense);
		ProgressBar pCon = _view.findViewById(R.id.progressControl);
		ProgressBar pDif = _view.findViewById(R.id.progressDifficulty);
		
		final float density = _view.getContext().getResources().getDisplayMetrics().density;
		
		// 🔳 KEMBALIKAN DEKORASI KOTAK CORNER & STROKE
		android.graphics.drawable.GradientDrawable styleBox = new android.graphics.drawable.GradientDrawable();
		styleBox.setColor(Color.parseColor("#BD000000"));
		styleBox.setStroke((int)(1 * density), Color.WHITE);
		styleBox.setCornerRadius(10 * density);
		
		LinearLayout.LayoutParams boksParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		boksParams.setMargins((int)(10 * density), (int)(6 * density), (int)(10 * density), (int)(6 * density));
		
		if (layoutSkillTitle != null) { layoutSkillTitle.setBackground(styleBox); layoutSkillTitle.setPadding((int)(16*density), (int)(12*density), (int)(16*density), (int)(12*density)); layoutSkillTitle.setLayoutParams(boksParams); }
		if (layoutSkillDesc != null) { layoutSkillDesc.setBackground(styleBox); layoutSkillDesc.setPadding((int)(16*density), (int)(12*density), (int)(16*density), (int)(12*density)); layoutSkillDesc.setLayoutParams(boksParams); }
		
		if (layoutBestBuild != null) {
			android.graphics.drawable.GradientDrawable sb = new android.graphics.drawable.GradientDrawable();
			sb.setColor(Color.parseColor("#BD000000")); sb.setStroke((int)(1.5f * density), Color.WHITE); sb.setCornerRadius(10 * density);
			layoutBestBuild.setBackground(sb); layoutBestBuild.setLayoutParams(boksParams);
		}
		if (layoutSkillIconContainer != null) {
			android.graphics.drawable.GradientDrawable sc = new android.graphics.drawable.GradientDrawable();
			sc.setColor(Color.parseColor("#BD000000")); sc.setStroke((int)(1.5f * density), Color.WHITE); sc.setCornerRadius(10 * density);
			layoutSkillIconContainer.setBackground(sc); layoutSkillIconContainer.setLayoutParams(boksParams);
		}
		
		if (heroRole != null && _data.containsKey("roll")) heroRole.setText(String.valueOf(_data.get("roll")));
		if (textSkillTitle != null && _data.containsKey("skill_title")) textSkillTitle.setText(String.valueOf(_data.get("skill_title")));
		if (textSkillDesc != null && _data.containsKey("skill_desc")) textSkillDesc.setText(String.valueOf(_data.get("skill_desc")));
		if (textBestBuild != null && _data.containsKey("best_build")) textBestBuild.setText("Rekomendasi Build : " + String.valueOf(_data.get("best_build")));
		
		try {
			final int durability = Math.max(0, Math.min(100, _data.get("stat_durability") != null ? Integer.parseInt(String.valueOf(_data.get("stat_durability"))) : 0));
			final int offense = Math.max(0, Math.min(100, _data.get("stat_offense") != null ? Integer.parseInt(String.valueOf(_data.get("stat_offense"))) : 0));
			final int control = Math.max(0, Math.min(100, _data.get("stat_control") != null ? Integer.parseInt(String.valueOf(_data.get("stat_control"))) : 0));
			final int difficulty = Math.max(0, Math.min(100, _data.get("stat_difficulty") != null ? Integer.parseInt(String.valueOf(_data.get("stat_difficulty"))) : 0));
			
			TextView tD = _view.findViewById(R.id.textDurabilityPercent);
			TextView tO = _view.findViewById(R.id.textOffensePercent);
			TextView tC = _view.findViewById(R.id.textControlPercent);
			TextView tF = _view.findViewById(R.id.textDifficultyPercent);
			
			if (tD != null) tD.setText("Ketahanan  " + durability + "%");
			if (tO != null) tO.setText("Serangan  " + offense + "%");
			if (tC != null) tC.setText("Efek Kontrol  " + control + "%");
			if (tF != null) tF.setText("Kesulitan  " + difficulty + "%");
			
			class ProgressLoader {
				void inject(ProgressBar pBar, int val, String color) {
					if (pBar == null) return;
					android.animation.ValueAnimator old = (android.animation.ValueAnimator) pBar.getTag(R.id.linear1);
					if (old != null) old.cancel();
					
					final com.zero.tools.skin.security.PremiumProgressDrawable d = new com.zero.tools.skin.security.PremiumProgressDrawable(android.graphics.Color.parseColor(color));
					pBar.setMax(100); pBar.setProgressDrawable(d); pBar.setProgress(0);
					
					final android.animation.ValueAnimator anim = android.animation.ValueAnimator.ofInt(0, val);
					anim.setDuration(800L);
					anim.addUpdateListener(animation -> {
						if (pBar.getProgressDrawable() != d) { animation.cancel(); return; }
						int curr = ((Integer) animation.getAnimatedValue()).intValue();
						d.setProgressValue((float) curr); pBar.setProgress(curr);
					});
					pBar.setTag(R.id.linear1, anim); anim.start();
				}
			}
			ProgressLoader pl = new ProgressLoader();
			pl.inject(pDur, durability, "#00E676"); pl.inject(pOff, offense, "#FF1744"); pl.inject(pCon, control, "#2979FF"); pl.inject(pDif, difficulty, "#D500F9");
		} catch (Exception e) {}
		String url = "";
		if (_data.containsKey("URL")) url = String.valueOf(_data.get("URL"));
		else if (_data.containsKey("img")) url = String.valueOf(_data.get("img"));
		
		if (imageview2 != null && !url.isEmpty()) {
			imageview2.setScaleType(ImageView.ScaleType.FIT_XY);
			android.graphics.drawable.GradientDrawable strokeAvatar = new android.graphics.drawable.GradientDrawable();
			strokeAvatar.setStroke((int)(1.5f * density), Color.WHITE); strokeAvatar.setCornerRadius(12 * density);
			imageview2.setBackground(strokeAvatar); imageview2.setClipToOutline(true);
			com.bumptech.glide.Glide.with(_view.getContext().getApplicationContext()).load(url).placeholder(R.drawable.herokosong).dontAnimate().into(imageview2);
		}
		
		if (layoutHeroStats != null && !url.isEmpty()) {
			com.bumptech.glide.Glide.with(_view.getContext().getApplicationContext()).asBitmap().load(url).into(new com.bumptech.glide.request.target.CustomTarget<android.graphics.Bitmap>() {
				@Override
				public void onResourceReady(android.graphics.Bitmap res, com.bumptech.glide.request.transition.Transition<? super android.graphics.Bitmap> transition) {
					if (layoutHeroStats != null && res != null && _view.getContext() != null) {
						android.graphics.drawable.BitmapDrawable bd = new android.graphics.drawable.BitmapDrawable(_view.getContext().getResources(), res);
						bd.setAlpha(95); bd.setGravity(android.view.Gravity.FILL); layoutHeroStats.setBackground(bd);
					}
				}
				@Override
				public void onLoadCleared(android.graphics.drawable.Drawable placeholder) { if (layoutHeroStats != null) layoutHeroStats.setBackground(null); }
			});
		}
		
		if (imgPasif != null && _data.containsKey("skill_pasif_URL")) com.bumptech.glide.Glide.with(_view.getContext().getApplicationContext()).load(String.valueOf(_data.get("skill_pasif_URL"))).transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()).into(imgPasif);
		if (imgSkill1 != null && _data.containsKey("skill1_URL")) com.bumptech.glide.Glide.with(_view.getContext().getApplicationContext()).load(String.valueOf(_data.get("skill1_URL"))).transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()).into(imgSkill1);
		if (imgSkill2 != null && _data.containsKey("skill2_URL")) com.bumptech.glide.Glide.with(_view.getContext().getApplicationContext()).load(String.valueOf(_data.get("skill2_URL"))).transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()).into(imgSkill2);
		if (imgSkillUlt != null && _data.containsKey("skill_ult_URL")) com.bumptech.glide.Glide.with(_view.getContext().getApplicationContext()).load(String.valueOf(_data.get("skill_ult_URL"))).transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()).into(imgSkillUlt);
		
		class SkillPopupHelper {
			void bind(View v, final int type) {
				if (v == null) return;
				v.setOnTouchListener(new View.OnTouchListener() {
					@Override
					public boolean onTouch(View viewV, android.view.MotionEvent ev) {
						if (ev.getAction() == android.view.MotionEvent.ACTION_DOWN) viewV.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).start();
						else if (ev.getAction() == android.view.MotionEvent.ACTION_UP) {
							viewV.animate().scaleX(1f).scaleY(1f).setDuration(80).start();
							String judul = "Skill", desc = "Deskripsi tidak tersedia.", key = "skill_pasif_URL";
							if (_data.containsKey("skill_desc")) {
								String fd = String.valueOf(_data.get("skill_desc"));
								try {
									if (type == 0) { 
										String[] bg = fd.split("🔵"); 
										if (bg.length > 0) { desc = bg[0].replace("🔴", "").trim(); String[] baris = desc.split("\n"); if (baris.length > 0) judul = baris[0].replace("PASIF - ", "").replace(":", "").trim(); }
										key = "skill_pasif_URL"; 
									} else if (type == 1) { 
										String[] bg1 = fd.split("🔵");
										if (bg1.length > 1) { String[] bg2 = bg1[1].split("🟡"); desc = bg2[0].trim(); String[] baris = desc.split("\n"); if (baris.length > 0) judul = baris[0].replace("SKILL 1 - ", "").replace(":", "").trim(); }
										key = "skill1_URL"; 
									} else if (type == 2) { 
										String[] bg1 = fd.split("🟡");
										if (bg1.length > 1) { String[] bg2 = bg1[1].split("💜"); desc = bg2[0].trim(); String[] baris = desc.split("\n"); if (baris.length > 0) judul = baris[0].replace("SKILL 2 - ", "").replace(":", "").trim(); }
										key = "skill2_URL"; 
									} else if (type == 3) { 
										String[] bg = fd.split("💜");
										if (bg.length > 1) { desc = bg[1].trim(); String[] baris = desc.split("\n"); if (baris.length > 0) judul = baris[0].replaceAll("ULTIMATE \\(SKILL \\d+\\) - ", "").replace(":", "").trim(); }
										key = "skill_ult_URL"; 
									}
								} catch (Exception e) { desc = fd; }
							}
							String linkIkon = _data.containsKey(key) ? String.valueOf(_data.get(key)) : "";
							com.zero.tools.skin.security.JsonManager.tampilkanSkillPopup(_view.getContext(), judul, desc, linkIkon);
						} else if (ev.getAction() == android.view.MotionEvent.ACTION_CANCEL) viewV.animate().scaleX(1f).scaleY(1f).setDuration(80).start();
						return true;
					}
				});
			}
		}
		SkillPopupHelper sph = new SkillPopupHelper();
		if (imgPasif != null && _data.containsKey("skill_pasif_URL")) sph.bind(imgPasif, 0);
		if (imgSkill1 != null && _data.containsKey("skill1_URL")) sph.bind(imgSkill1, 1);
		if (imgSkill2 != null && _data.containsKey("skill2_URL")) sph.bind(imgSkill2, 2);
		if (imgSkillUlt != null && _data.containsKey("skill_ult_URL")) sph.bind(imgSkillUlt, 3);
		
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.heroskinn, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			final int pos = (int)_position;
			if (pos >= 0 && linear1 != null && textview1 != null && imageview1 != null) {
				final View headerView_kustom = (View) recyclerview1.getTag(R.id.imageview2);
				final String namaHeroTerpilih_onBind = sp.getString("her", "");
				java.util.HashMap<String, Object> finalHeroData = null;
				boolean apakahHeroAdaDiGitHub = false;
				
				if (listDetailHero != null && !listDetailHero.isEmpty() && !namaHeroTerpilih_onBind.isEmpty()) {
					for (int i = 0; i < listDetailHero.size(); i++) {
						java.util.HashMap<String, Object> tempHero = listDetailHero.get(i);
						if (tempHero != null && tempHero.containsKey("her") && namaHeroTerpilih_onBind.equalsIgnoreCase(String.valueOf(tempHero.get("her")))) {
							finalHeroData = tempHero; apakahHeroAdaDiGitHub = true; break;
						}
					}
				}
				
				if (pos == 0 && apakahHeroAdaDiGitHub) {
					if (headerView_kustom != null) {
						headerView_kustom.setVisibility(View.VISIBLE);
						if (_view instanceof android.widget.LinearLayout) {
							android.widget.LinearLayout mainRowLayout = (android.widget.LinearLayout) _view;
							mainRowLayout.setOrientation(android.widget.LinearLayout.VERTICAL); linear1.setVisibility(View.GONE);
							if (headerView_kustom.getParent() != null && headerView_kustom.getParent() != mainRowLayout) {
								((android.view.ViewGroup)headerView_kustom.getParent()).removeView(headerView_kustom);
							}
							mainRowLayout.removeView(headerView_kustom); mainRowLayout.addView(headerView_kustom, 0);
						}
						_dekorasiDetailHero(finalHeroData, headerView_kustom);
					}
					return; 
				}
				if (com.zero.tools.skin.security.JsonManager.handleSkinVisibility(getApplicationContext(), _view, linear1)) return;
				linear1.setVisibility(View.VISIBLE);
				final int skinPos = apakahHeroAdaDiGitHub ? (pos - 1) : pos;
				
				if (_view instanceof android.widget.LinearLayout) {
					android.widget.LinearLayout mainRowLayout = (android.widget.LinearLayout) _view;
					mainRowLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
					if (headerView_kustom != null && headerView_kustom.getParent() == mainRowLayout) mainRowLayout.removeView(headerView_kustom);
				}
				
				android.graphics.drawable.GradientDrawable boxSkinDrawable = new android.graphics.drawable.GradientDrawable();
				boxSkinDrawable.setCornerRadius(20f); boxSkinDrawable.setStroke(2, 0xFFFFFFFF); boxSkinDrawable.setColor(0xFF000000);
				linear1.setBackground(boxSkinDrawable);
				
				if (skinPos >= 0 && skinPos < _data.size()) {
					if (imageview1 != null) imageview1.setScaleType(ImageView.ScaleType.CENTER_CROP); 
					if (_data.get(skinPos).containsKey("img2") && _data.get(skinPos).get("img2") != null) {
						com.bumptech.glide.Glide.with(getApplicationContext()).load(_data.get(skinPos).get("img2").toString()).placeholder(R.drawable.herokosong).dontAnimate().into(imageview1);
					}
					if (textview1 != null && _data.get(skinPos).containsKey("skin_name")) {
						textview1.setText(skinPos == 0 ? "Backup " + namaHeroTerpilih_onBind : String.valueOf(_data.get(skinPos).get("skin_name")));
					}
					
					// 🚀 FIX ERROR 2 & 3: Menggunakan if-else MotionEvent murni tanpa struktur switch-case ganda yang leak
					imageview1.setOnTouchListener(new View.OnTouchListener() {
						@Override
						public boolean onTouch(View v, MotionEvent ev) {
							if (ev.getAction() == MotionEvent.ACTION_DOWN) {
								v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(100).start();
							} else if (ev.getAction() == MotionEvent.ACTION_UP) {
								v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
								
								final android.app.Activity currentActivity = HeroskinActivity.this;
								if (skinPos < _data.size() && _data.get(skinPos).containsKey("url")) {
									PermissionManager perm = new PermissionManager(currentActivity);
									String mode = sp.getString("DOWNLOAD_MODE", "");
									final String url = String.valueOf(_data.get(skinPos).get("url"));
									final String fileName = String.valueOf(_data.get(skinPos).get("skin_name")) + ".zip";
									
									if (mode.isEmpty()) { _showModeDialog(); }
									else if ("DEFAULT".equals(mode) && !perm.IsPermissionGranted()) { perm.RequestDataPermission(); } 
									else if ("SHIZUKU".equals(mode) && (fyy == null || !fyy.hasPermission())) { fyy.requestPermission(); }
									else if ("IADB".equals(mode)) { Toast.makeText(currentActivity.getApplicationContext(), "Fitur iAdb segera hadir di pembaruan mendatang! 🚀", Toast.LENGTH_LONG).show(); }
									else {
										ZeroAdsManager.showAd(currentActivity, () -> {
											if ("DEFAULT".equals(mode)) new DefaultDownloader(currentActivity).startDownload(url, fileName);
											else if ("SHIZUKU".equals(mode)) new ShizukuDownloader(currentActivity, fyy).startDownload(url, fileName);
										});
									}
								}
							} else if (ev.getAction() == MotionEvent.ACTION_CANCEL) {
								v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
							}
							return true;
						}
					});
				}
			}
			
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}