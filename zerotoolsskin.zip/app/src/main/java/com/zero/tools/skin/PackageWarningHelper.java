package com.zero.tools.skin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class PackageWarningHelper {

    private final Context context;
    private final PackageManager pm;

    private ViewGroup parent;
    private LinearLayout card;
    private LinearLayout appList;
    private TextView statusText;
    private Button scanButton;

    private boolean scanning = false;

    private final String[] targetPackages = {
        "com.ML.ToolsGFX.MLSkinInjector",
        "com.BS.Toolskit",
        "com.ML.Toolshub.MLSkinInjector.GameToolsML",
        "com.ML.ToolsPro.MLSkinInjector.ModScriptSkin",
        "gG.Tools.MLInjector.SkinToolML",
        "com.Ryu.Tools.MLSkinInjector.ML.Toolkit",
        "com.MR.Tools.MLToolsSkin.ConfigScriptSkin",
        "bahran.the.meow",
        "com.aneh.gaming7",
        "com.aneh.gaming8",
        "com.Zonghub.Tools.Skin.ML.Injector.GFX.MLTOOLSHUB",
        "com.Kaizerus.GFX.Tools.Skin.ML.Injector.GsTools",
        "touch.the.grass",
        "com.Yin.Tools.MLConfigSkin.Injector",
        "com.Lumina.GFX.Tools.Skin.ML.Injector",
        "com.Remoba.Tools.MLSkinHub.Injector",
        "com.kaizokuo.gfx",
        "com.scripttools",
        "com.mobalauncher.io",
        "com.xeno.gfx",
        "com.introtools.ml",
        "com.ff.panel.caxto",
        "com.ML.SkinHub.ConfigSkin.InjectorML",
        "com.mltools.gfx", 
        "com.beasthub.ultra",
        "com.bisayatoolkit.ph",
        "com.draxyn.app",
        "com.oudias.robuxcoinwin",
        "com.zentools",
        "com.fortnitechapter7.battleroyale",
        "mlskintools.configrefinebangbang.modskininjector"
    };

    public PackageWarningHelper(Context context) {
        this.context = context;
        this.pm = context.getPackageManager();
    }

    private int dp(float value) {
        return (int) (value * context.getResources()
            .getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(
            int background, int strokeColor, int strokeWidth, int radius) {

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(background);
        drawable.setCornerRadius(dp(radius));

        if (strokeWidth > 0) {
            drawable.setStroke(dp(strokeWidth), strokeColor);
        }

        return drawable;
    }

    private TextView text(String value, int size, int color) {
        TextView tv = new TextView(context);
        tv.setText(value);
        tv.setTextSize(size);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        return tv;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    public void attachTo(ViewGroup container) {
        if (container == null) return;

        parent = container;

        if (card != null && card.getParent() instanceof ViewGroup) {
            ((ViewGroup) card.getParent()).removeView(card);
        }

        buildCard();

        // Kartu diletakkan di bagian atas container.
        parent.addView(card, 0);

        scanAgain();
    }

    private void buildCard() {
        card = vertical();
        card.setPadding(dp(14), dp(14), dp(14), dp(12));
        card.setBackground(shape(
            Color.rgb(12, 12, 12),
            Color.rgb(229, 57, 53),
            1, 18
        ));

        LinearLayout.LayoutParams cardParams =
            new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            );

        cardParams.setMargins(dp(10), dp(8), dp(10), dp(10));
        card.setLayoutParams(cardParams);

        // Header.
        LinearLayout header = horizontal();

        TextView warningIcon = text("!", 23, Color.WHITE);
        warningIcon.setGravity(Gravity.CENTER);
        warningIcon.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        warningIcon.setBackground(shape(
            Color.rgb(183, 28, 28),
            Color.rgb(255, 82, 82), 1, 50
        ));

        LinearLayout.LayoutParams iconParams =
            new LinearLayout.LayoutParams(dp(38), dp(38));
        iconParams.setMargins(0, 0, dp(10), 0);
        header.addView(warningIcon, iconParams);

        LinearLayout titleBox = vertical();

        TextView title = text(
            "Peringatan Keamanan", 16, Color.WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);

        TextView subtitle = text(
            "Ditemukan beberapa aplikasi pihak ketiga yang berjalan di latar belakang. Disarankan untuk meninjau kembali guna menjaga stabilitas sistem dan kenyamanan performa perangkat Anda.", 12,
            Color.rgb(185, 185, 185));

        titleBox.addView(title);
        titleBox.addView(subtitle);

        header.addView(titleBox, new LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1
        ));

        card.addView(header);

        // Status pemindaian.
        statusText = text(
            "Menyiapkan pemindaian...",
            12, Color.LTGRAY
        );
        statusText.setPadding(0, dp(12), 0, dp(8));
        card.addView(statusText);

        // Daftar aplikasi.
        ScrollView scroll = new ScrollView(context);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        
        scroll.setOnTouchListener(new View.OnTouchListener() {
    @Override
    public boolean onTouch(View v, android.view.MotionEvent event) {
        // Beritahu RecyclerView/parent untuk tidak merebut atau menginterupsi sentuhan saat ScrollView dijamah
        if (v.getParent() != null) {
            v.getParent().requestDisallowInterceptTouchEvent(true);
        }
        return false;
    }
});

        appList = vertical();

        scroll.addView(appList, new ScrollView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        LinearLayout.LayoutParams scrollParams =
            new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(220)
            );
        card.addView(scroll, scrollParams);

        // Tombol pindai ulang.
        scanButton = new Button(context);
        scanButton.setText("⟳  Pindai Ulang");
        scanButton.setTextColor(Color.WHITE);
        scanButton.setTextSize(13);
        scanButton.setAllCaps(false);
        scanButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        scanButton.setBackground(shape(
            Color.rgb(183, 28, 28),
            Color.rgb(255, 82, 82), 1, 12
        ));

        LinearLayout.LayoutParams buttonParams =
            new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)
            );
        buttonParams.setMargins(0, dp(12), 0, 0);

        card.addView(scanButton, buttonParams);

        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scanAgain();
            }
        });
    }

    public void scanAgain() {
        if (scanning || card == null) return;

        scanning = true;
        scanButton.setEnabled(false);
        scanButton.setText("Memindai...");
        statusText.setText("Memeriksa aplikasi yang terpasang...");
        appList.removeAllViews();

        // Pindai di thread latar agar UI tetap responsif.
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<ApplicationInfo> found =
                    new ArrayList<ApplicationInfo>();

                for (String packageName : targetPackages) {
                    try {
                        ApplicationInfo info =
                            pm.getApplicationInfo(packageName, 0);
                        found.add(info);
                    } catch (PackageManager.NameNotFoundException ignored) {
                        // Package target tidak ditemukan.
                    } catch (Exception ignored) {
                        // Abaikan package yang gagal diperiksa.
                    }
                }

                if (!(context instanceof Activity)) {
                    scanning = false;
                    return;
                }

                ((Activity) context).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            showResults(found);
                        } finally {
                            scanning = false;

                            if (scanButton != null) {
                                scanButton.setEnabled(true);
                                scanButton.setText("⟳  Pindai Ulang");
                            }
                        }
                    }
                });
            }
        }).start();
    }

    private void showResults(List<ApplicationInfo> found) {
    if (appList == null || statusText == null || card == null) return;

    appList.removeAllViews();

    // JIKALAU BERSIH (TIDAK ADA APK YG COCOK), SEMBUNYIKAN KARTU TOTAL
    if (found.isEmpty()) {
        card.setVisibility(View.GONE); 
        return;
    }

    // JIKALAU ADA YANG TERDETEKSI, PAKSA MUNCULKAN KARTU PERINGATAN
    card.setVisibility(View.VISIBLE);

    statusText.setText(
        "Ditemukan " + found.size() + " aplikasi yang memerlukan tinjauan performa."
    );

    for (final ApplicationInfo info : found) {
        addAppRow(info);
    }
}


    private void addAppRow(final ApplicationInfo info) {
        LinearLayout row = horizontal();
        row.setPadding(dp(8), dp(8), dp(6), dp(8));
        row.setBackground(shape(
            Color.rgb(25, 25, 25),
            Color.rgb(55, 55, 55), 1, 12
        ));

        LinearLayout.LayoutParams rowParams =
            new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            );
        rowParams.setMargins(0, 0, 0, dp(7));

        ImageView appIcon = new ImageView(context);

        try {
            appIcon.setImageDrawable(pm.getApplicationIcon(info));
        } catch (Exception ignored) {
            appIcon.setImageResource(
                android.R.drawable.sym_def_app_icon);
        }

        appIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);

        row.addView(appIcon, new LinearLayout.LayoutParams(
            dp(42), dp(42)
        ));

        LinearLayout nameBox = vertical();
        nameBox.setPadding(dp(10), 0, dp(4), 0);

        String appName;
        try {
            appName = pm.getApplicationLabel(info).toString();
        } catch (Exception ignored) {
            appName = info.packageName;
        }

        TextView name = text(appName, 13, Color.WHITE);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setMaxLines(2);

        TextView packageName = text(
            info.packageName, 9,
            Color.rgb(170, 170, 170)
        );
        packageName.setMaxLines(2);

        nameBox.addView(name);
        nameBox.addView(packageName);

        row.addView(nameBox, new LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1
        ));

        Button infoButton = new Button(context);
        infoButton.setText("Info & hapus instalasi");
        infoButton.setTextSize(11);
        infoButton.setAllCaps(false);
        infoButton.setTextColor(Color.WHITE);
        infoButton.setPadding(dp(8), 0, dp(8), 0);
        infoButton.setBackground(shape(
            Color.rgb(35, 35, 35),
            Color.rgb(255, 82, 82), 1, 10
        ));

        row.addView(infoButton, new LinearLayout.LayoutParams(
            dp(60), dp(38)
        ));

        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent intent = new Intent(
                        android.provider.Settings
                            .ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + info.packageName)
                    );
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                } catch (Exception e) {
                    android.widget.Toast.makeText(
                        context,
                        "Tidak bisa membuka info aplikasi",
                        android.widget.Toast.LENGTH_SHORT
                    ).show();
                }
            }
        });

        appList.addView(row, rowParams);
    }
}