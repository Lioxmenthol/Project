package com.zero.tools.skin;

import android.app.Application;
import android.content.Intent;
import android.util.Log;

public class AnehApplication extends Application {

    // ✅ AMAN API 36: Menggunakan instance murni tanpa kata kunci 'static' untuk mencegah kebocoran RAM
    private AppOpenManager appOpenManager;
    private Thread.UncaughtExceptionHandler defaultExceptionHandler;

    // 🌟 SAKLAR KONTROL IKLAN: Set true secara default agar saat pertama dibuka iklan langsung tertahan
    public static boolean isSplashActive = true;

    @Override
    public void onCreate() {
        super.onCreate();

        try {
            // ===== 👑 KEMBALI KE ALUR ASLIMU YANG SUKSES =====
            // Inisialisasi AdMob secara langsung di UI Thread agar sinkron dengan AppOpenManager Anda
            com.google.android.gms.ads.MobileAds.initialize(this, initializationStatus -> {});

            // Inisialisasi App Open Manager tepat setelah SDK siap
            appOpenManager = new AppOpenManager(this);
            
        } catch (Exception e) {
            Log.e("AnehApplication", "Gagal inisialisasi AdMob/AppOpen: " + e.getMessage());
        }

        // ===== 🛡️ SETUP CRASH HANDLER (SISTEM DEBUGACTIVITY ANDALANMU) =====
        defaultExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();

        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                // Mengamankan Intent DebugActivity menggunakan flag NEW_TASK yang sah
                Intent intent = new Intent(getApplicationContext(), DebugActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.putExtra("error", Log.getStackTraceString(throwable));
                startActivity(intent);
            } catch (Exception e) {
                Log.e("AnehApplication", "Gagal mengalihkan ke DebugActivity: " + e.getMessage());
            }

            if (defaultExceptionHandler != null) {
                defaultExceptionHandler.uncaughtException(thread, throwable);
            }
        });
    }

    // Mengembalikan objek manager pembuka iklan secara aman ke sistem Sketchware
    public AppOpenManager getAppOpenManager() {
        return appOpenManager;
    }
}
