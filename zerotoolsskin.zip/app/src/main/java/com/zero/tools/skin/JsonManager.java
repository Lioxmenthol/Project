package com.zero.tools.skin.security;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.View;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class JsonManager {

    private static final Map<String, String> JSON_MAP = new HashMap<>();

    static {
        JSON_MAP.put("menuzero",
                "https://lioxmenthol.github.io/blogger-json/menuzero.json");

        JSON_MAP.put("bannerzero",
                "https://lioxmenthol.github.io/blogger-json/zerobanner.json");
                
        JSON_MAP.put("equipment",
                "https://lioxmenthol.github.io/blogger-json/equipment.json");

        JSON_MAP.put("hero",
                "https://lioxmenthol.github.io/Auto/hero.json");

        JSON_MAP.put("ml",
                "https://lioxmenthol.github.io/Auto/ml.json");
                
        JSON_MAP.put("ml2",
                "https://lioxmenthol.github.io/Auto2/ml.json");
                
        JSON_MAP.put("ml3",
                "https://lioxmenthol.github.io/Auto3/ml.json");
                
        JSON_MAP.put("ml4",
                "https://lioxmenthol.github.io/Auto4/ml.json");
                
        JSON_MAP.put("ml5",
                "https://lioxmenthol.github.io/Auto5/ml.json");
    }

    public static String getJsonUrl(String key) {
        return JSON_MAP.get(key);
    }

    /**
     * 🛡️ REMOTE SWITCH MANAGER (PLAY STORE SAFE - SILENT VERSION)
     * Mengambil status saklar secara background tanpa membanjiri user dengan Toast berulang
     */
    public static void checkSkinSwitch(final Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

            if (isConnected) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        HttpURLConnection urlConnection = null;
                        try {
                            URL url = new URL("https://lioxmenthol.github.io/Auto/saklarskin.txt");
                            urlConnection = (HttpURLConnection) url.openConnection();
                            urlConnection.setRequestMethod("GET");
                            urlConnection.setConnectTimeout(5000);
                            urlConnection.setReadTimeout(5000);

                            int responseCode = urlConnection.getResponseCode();
                            if (responseCode == HttpURLConnection.HTTP_OK) {
                                BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                                StringBuilder response = new StringBuilder();
                                String inputLine;

                                while ((inputLine = in.readLine()) != null) {
                                    response.append(inputLine);
                                }
                                in.close();

                                final String statusSkin = response.toString().trim();

                                // Ambil status lama yang tersimpan di memori HP
                                SharedPreferences prefs = context.getSharedPreferences("sp", Context.MODE_PRIVATE);
                                String statusLama = prefs.getString("saklar_skin_inti", "open");

                                // Simpan status terbaru ke SharedPreferences boks "sp"
                                prefs.edit().putString("saklar_skin_inti", statusSkin).apply();

                                // Kembalikan aksi UI ke Main Thread Android
                                if (context instanceof android.app.Activity) {
                                    ((android.app.Activity) context).runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            // 🌟 TRIK PLAY STORE SAFE: Toast HANYA muncul jika status baru berubah dari OPEN ke CLOSE
                                            // Jika dari awal statusnya memang sudah CLOSE, dia akan senyap (Silent Mode)
                                            if (statusSkin.equalsIgnoreCase("close") && !statusLama.equalsIgnoreCase("close")) {
                                                Toast.makeText(context.getApplicationContext(), 
                                                    "Sistem sedang dalam pemeliharaan untuk meningkatkan layanan. Terima kasih atas kesabaran Anda.", 
                                                    Toast.LENGTH_LONG).show();
                                            }
                                            
                                            // Memicu refresh adapter secara otomatis agar tampilan langsung ter-update
                                            android.app.Activity act = (android.app.Activity) context;
                                            int resId = act.getResources().getIdentifier("recyclerview1", "id", act.getPackageName());
                                            if (resId != 0) {
                                                androidx.recyclerview.widget.RecyclerView rv = act.findViewById(resId);
                                                if (rv != null && rv.getAdapter() != null) {
                                                    rv.getAdapter().notifyDataSetChanged();
                                                }
                                            }
                                        }
                                    });
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            if (urlConnection != null) {
                                urlConnection.disconnect();
                            }
                        }
                    }
                }).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 🛡️ FUNGSI PEMBANTU UNTUK MENYEMBUNYIKAN SKIN (ONBIND HELPER)
     */
    public static boolean handleSkinVisibility(Context context, View itemView, View linearBox) {
        android.content.SharedPreferences sp = context.getSharedPreferences("sp", Context.MODE_PRIVATE);
        String cekSaklar = sp.getString("saklar_skin_inti", "open");

        if (cekSaklar.trim().equalsIgnoreCase("close")) {
            if (linearBox != null) linearBox.setVisibility(View.GONE);
            
            android.view.ViewGroup.LayoutParams itemParams = itemView.getLayoutParams();
            if (itemParams != null) {
                itemParams.height = 0;
                itemParams.width = 0;
                itemView.setLayoutParams(itemParams);
            }
            return true; 
        } else {
            if (linearBox != null) linearBox.setVisibility(View.VISIBLE);
            
            android.view.ViewGroup.LayoutParams itemParams = itemView.getLayoutParams();
            if (itemParams != null) {
                itemParams.height = android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
                itemParams.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT;
                itemView.setLayoutParams(itemParams);
            }
            return false; 
        }
    }
    
        /**
     * 🛡️ VOID GENERATOR DIALOG POP-UP PREMIUM (DARK MODE STROKE)
     */
    public static void tampilkanSkillPopup(final android.content.Context context, String judulSkill, String deskripsiSkill, String urlIkon) {
        try {
            if (!(context instanceof android.app.Activity)) return;
            final android.app.Activity act = (android.app.Activity) context;
            final float scale = act.getResources().getDisplayMetrics().density;
            
            android.graphics.drawable.GradientDrawable bgDialog = new android.graphics.drawable.GradientDrawable();
            bgDialog.setColor(android.graphics.Color.parseColor("#E6000000")); 
            bgDialog.setStroke((int)(1.5f * scale), android.graphics.Color.WHITE);
            bgDialog.setCornerRadius(15 * scale);
            
            android.widget.LinearLayout layoutInduk = new android.widget.LinearLayout(act);
            layoutInduk.setOrientation(android.widget.LinearLayout.VERTICAL);
            layoutInduk.setPadding((int)(20 * scale), (int)(20 * scale), (int)(20 * scale), (int)(20 * scale));
            layoutInduk.setBackground(bgDialog);
            layoutInduk.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
            
            android.widget.LinearLayout layoutHeader = new android.widget.LinearLayout(act);
            layoutHeader.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            layoutHeader.setGravity(android.view.Gravity.CENTER_VERTICAL);
            layoutHeader.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
                
            android.widget.ImageView gambarIkon = new android.widget.ImageView(act);
            android.widget.LinearLayout.LayoutParams imgParams = new android.widget.LinearLayout.LayoutParams((int)(45 * scale), (int)(45 * scale));
            imgParams.setMargins(0, 0, (int)(12 * scale), 0);
            gambarIkon.setLayoutParams(imgParams);
            com.bumptech.glide.Glide.with(act.getApplicationContext()).load(urlIkon).placeholder(act.getResources().getIdentifier("herokosong", "drawable", act.getPackageName())).transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()).into(gambarIkon);
            
            android.widget.TextView teksJudul = new android.widget.TextView(act);
            teksJudul.setText(judulSkill);
            teksJudul.setTextColor(android.graphics.Color.WHITE);
            teksJudul.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 16);
            teksJudul.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            teksJudul.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
                
            layoutHeader.addView(gambarIkon);
            layoutHeader.addView(teksJudul);
            
            android.view.View garisPemisah = new android.view.View(act);
            android.widget.LinearLayout.LayoutParams lineParams = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (int)(1 * scale));
            lineParams.setMargins(0, (int)(12 * scale), 0, (int)(12 * scale));
            garisPemisah.setLayoutParams(lineParams);
            garisPemisah.setBackgroundColor(android.graphics.Color.parseColor("#40FFFFFF")); 
            
            android.widget.TextView teksDeskripsi = new android.widget.TextView(act);
            teksDeskripsi.setText(deskripsiSkill);
            teksDeskripsi.setTextColor(android.graphics.Color.parseColor("#E0E0E0"));
            teksDeskripsi.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 13);
            teksDeskripsi.setLineSpacing(2f, 1.15f);
            teksDeskripsi.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
                
            layoutInduk.addView(layoutHeader);
            layoutInduk.addView(garisPemisah);
            layoutInduk.addView(teksDeskripsi);
            
            final android.app.AlertDialog dialogSakti = new android.app.AlertDialog.Builder(act).create();
            dialogSakti.setView(layoutInduk);
            dialogSakti.setCancelable(true);
            dialogSakti.show();
                       
            android.view.Window window = dialogSakti.getWindow();
            if (window != null) {
                window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)); 
                window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                android.view.WindowManager.LayoutParams windowParams = window.getAttributes();
                windowParams.dimAmount = 0.75f; 
                window.setAttributes(windowParams);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
