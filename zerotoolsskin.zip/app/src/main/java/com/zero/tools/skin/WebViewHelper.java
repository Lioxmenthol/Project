package com.zero.tools.skin;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

public class WebViewHelper {

    private static FrameLayout overlay;
    private static LinearLayout sheet;
    private static WebView webView;
    private static ProgressBar progress;
    private static boolean showing = false;

    // Offset sheet untuk swipe visual
    private static float sheetOffsetY = 0;

    public static void show(Activity act, String url) {
        // Reset state lama
        if (overlay != null && overlay.getParent() != null) {
            ((ViewGroup) overlay.getParent()).removeView(overlay);
        }
        overlay = null;
        sheet = null;
        webView = null;
        progress = null;
        showing = false;
        sheetOffsetY = 0;

        showing = true;

        // ===== Overlay intercept semua klik =====
        overlay = new FrameLayout(act);
        overlay.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        overlay.setBackgroundColor(0x99000000);
        overlay.setClickable(true); // intercept semua klik
        // jangan setOnClickListener → tidak menutup WebView

        // ===== Bottom Sheet =====
        sheet = new LinearLayout(act);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setClickable(true);

        int height = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.30f);
        FrameLayout.LayoutParams sheetLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, height
        );
        sheetLp.gravity = Gravity.BOTTOM;
        sheet.setLayoutParams(sheetLp);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#4A148C"));
        bg.setCornerRadii(new float[]{32,32,32,32,0,0,0,0});
        sheet.setBackground(bg);

        // ===== Drag handle panjang 400px =====
        View handle = new View(act);
        LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(400, 10);
        hLp.gravity = Gravity.CENTER;
        hLp.topMargin = 14;
        hLp.bottomMargin = 12;
        handle.setLayoutParams(hLp);
        handle.setBackgroundColor(0xFFFFFFFF);
        sheet.addView(handle);

        // ===== Tombol X pojok kanan atas =====
        Button btnClose = new Button(act);
btnClose.setText("X");
btnClose.setTextColor(Color.WHITE);
btnClose.setBackgroundColor(Color.TRANSPARENT);

// Perbesar font & bold
btnClose.setTextSize(24); // ukuran font lebih besar
btnClose.setAllCaps(false); // biar tetap huruf X besar
btnClose.setPadding(30,20,30,20); // padding lebih tebal

LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
);
bLp.gravity = Gravity.END;
btnClose.setLayoutParams(bLp);

sheet.addView(btnClose);
btnClose.setOnClickListener(v -> hide());

        // ===== ProgressBar kecil =====
        progress = new ProgressBar(act, null, android.R.attr.progressBarStyleLarge);
        progress.getIndeterminateDrawable().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
        LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(60, 60);
        pLp.gravity = Gravity.CENTER;
        progress.setLayoutParams(pLp);
        sheet.addView(progress);

        // ===== WebView =====
        webView = new WebView(act);
        LinearLayout.LayoutParams wLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
        webView.setLayoutParams(wLp);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (progress != null) progress.setVisibility(View.GONE);
            }
        });

        webView.loadUrl(url);
        sheet.addView(webView);

        // ===== Swipe visual tapi tidak menutup =====
        sheet.setOnTouchListener(new View.OnTouchListener() {
            float startY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startY = e.getRawY();
                        break;

                    case MotionEvent.ACTION_MOVE:
                        float dy = e.getRawY() - startY;
                        sheetOffsetY = Math.max(-200, Math.min(dy, 200)); // geser maksimal ±200px
                        sheet.setTranslationY(sheetOffsetY);
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        sheet.animate().translationY(0).setDuration(150).start();
                        break;
                }
                return true; // consume touch event, tetap tidak menutup
            }
        });

        overlay.addView(sheet);
        ((ViewGroup) act.getWindow().getDecorView()).addView(overlay);
    }

    public static void hide() {
        try {
            if (webView != null) {
                webView.stopLoading();
                webView.loadUrl("about:blank");
                webView.destroy();
            }
            if (overlay != null && overlay.getParent() != null) {
                ((ViewGroup) overlay.getParent()).removeView(overlay);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        webView = null;
        sheet = null;
        overlay = null;
        progress = null;
        showing = false;
        sheetOffsetY = 0;
    }

    public static boolean isShowing() { return showing; }
}
