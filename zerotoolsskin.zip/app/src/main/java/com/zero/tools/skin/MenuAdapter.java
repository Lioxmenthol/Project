package com.zero.tools.skin;

import android.net.Uri;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class MenuAdapter
        extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    // ========================================================
    // TYPE ITEM
    // ========================================================
    private static final int TYPE_HERO = 0;
    private static final int TYPE_MENU = 1;

    private final Context context;
    private final ArrayList<HashMap<String, Object>> breh;

    private String heroDetailJson;

    // ========================================================
    // HERO SELECTOR
    // Hero awal tetap RANDOM seperti sistem lama.
    // Setelah user memilih hero, index ini menjadi pilihan aktif.
    // ========================================================
    private int selectedHeroIndex = -1;

    // ========================================================
    // CONSTRUCTOR UTAMA
    // ========================================================
    public MenuAdapter(
            Context context,
            ArrayList<HashMap<String, Object>> dataList,
            String heroDetailJson) {

        this.context = context;
        this.breh = dataList;
        this.heroDetailJson = heroDetailJson;
    }

    // ========================================================
    // CONSTRUCTOR BACKUP
    // Supaya kode lama tidak langsung error
    // ========================================================
    public MenuAdapter(
            ArrayList<HashMap<String, Object>> dataList) {

        this.context = null;
        this.breh = dataList;
        this.heroDetailJson = "";
    }

    // ========================================================
    // UPDATE DATA HERO DETAIL
    // ========================================================
    public void setHeroDetailJson(String json) {

        this.heroDetailJson =
                json == null ? "" : json;

        notifyItemChanged(0);
    }

    // ========================================================
    // PILIH HERO DARI HERO SELECTOR
    // Callback ini berada di OUTER MenuAdapter.
    // Jadi klik selector benar-benar me-refresh Hero Detail.
    // ========================================================
    private void selectHeroFromSelector(int index) {

        if (!hasHeroDetail()) {
            return;
        }

        if (index < 0) {
            return;
        }

        try {

            ArrayList<HashMap<String, Object>> listHero =
                    new Gson().fromJson(
                            heroDetailJson,
                            new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
                    );

            if (listHero == null ||
                index >= listHero.size()) {
                return;
            }

            selectedHeroIndex = index;

            // Hero Detail adalah item 0 di RecyclerView utama.
            notifyItemChanged(0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ========================================================
    // CEK ADA HERO DETAIL
    // ========================================================
    private boolean hasHeroDetail() {

        return heroDetailJson != null &&
               !heroDetailJson.isEmpty();
    }

    // ========================================================
    // ITEM COUNT
    // HERO DETAIL SELALU ITEM PERTAMA
    // ========================================================
    @Override
    public int getItemCount() {

        int menuCount =
                breh != null ? breh.size() : 0;

        return menuCount +
                (hasHeroDetail() ? 1 : 0);
    }

    // ========================================================
    // ITEM TYPE
    // ========================================================
    @Override
    public int getItemViewType(int position) {

        if (hasHeroDetail() && position == 0) {
            return TYPE_HERO;
        }

        return TYPE_MENU;
    }

    // ========================================================
    // CREATE VIEW HOLDER
    // ========================================================
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {

        if (viewType == TYPE_HERO) {

            // Container khusus Hero Detail.
            // Tidak menggunakan layoutHeroStats MainActivity.
            FrameLayout container =
                    new FrameLayout(parent.getContext());

            container.setLayoutParams(
                    new RecyclerView.LayoutParams(
                            RecyclerView.LayoutParams.MATCH_PARENT,
                            RecyclerView.LayoutParams.WRAP_CONTENT
                    )
            );

            container.setBackgroundColor(
                    Color.TRANSPARENT
            );

            container.setPadding(0, 0, 0, 0);

            return new HeroViewHolder(container);
        }

        // ====================================================
        // MENU NORMAL
        // ====================================================
        View view =
                LayoutInflater.from(parent.getContext())
                        .inflate(
                                R.layout.menuzero,
                                parent,
                                false
                        );

        return new MenuViewHolder(view);
    }

    // ========================================================
    // BIND VIEW HOLDER
    // ========================================================
    @Override
    public void onBindViewHolder(
            @NonNull RecyclerView.ViewHolder holder,
            int position) {

        // ====================================================
        // HERO DETAIL
        // ====================================================
        if (getItemViewType(position) == TYPE_HERO) {

            bindHeroDetail(
                    (HeroViewHolder) holder
            );

            return;
        }

        // ====================================================
        // POSISI MENU
        //
        // Karena Hero berada di posisi 0,
        // menu pertama berada di posisi 1.
        // ====================================================
        int menuPosition =
                hasHeroDetail()
                ? position - 1
                : position;

        if (breh == null ||
            menuPosition < 0 ||
            menuPosition >= breh.size() ||
            breh.get(menuPosition) == null) {

            return;
        }

        bindMenu(
                (MenuViewHolder) holder,
                menuPosition
        );
    }

    // ========================================================
    // ========================================================
    // HERO DETAIL
    // ========================================================
    // ========================================================
    private void bindHeroDetail(
            HeroViewHolder holder) {

        try {

            holder.container.removeAllViews();

            holder.container.setBackgroundColor(
                    Color.TRANSPARENT
            );

            if (!hasHeroDetail()) {
                holder.container.setVisibility(View.GONE);
                return;
            }

            ArrayList<HashMap<String, Object>> listHero =
                    new Gson().fromJson(
                            heroDetailJson,
                            new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
                    );

            if (listHero == null ||
                listHero.size() == 0) {

                holder.container.setVisibility(View.GONE);
                return;
            }

            // ====================================================
            // PILIH HERO
            // ====================================================
            // Saat pertama kali tampil, tetap RANDOM seperti kode lama.
            // Setelah user memilih dari Hero Selector, gunakan pilihan user.
            if (selectedHeroIndex < 0 ||
                selectedHeroIndex >= listHero.size()) {

                selectedHeroIndex =
                        new Random().nextInt(
                                listHero.size()
                        );
            }

            HashMap<String, Object> heroData =
                    listHero.get(selectedHeroIndex);

            if (heroData == null) {
                holder.container.setVisibility(View.GONE);
                return;
            }

            // ====================================================
            // INFLATE HERO DETAIL
            // ====================================================
            View vKustom =
                    LayoutInflater.from(context)
                            .inflate(
                                    R.layout.herodetail,
                                    holder.container,
                                    false
                            );
                            
                            // 👇 SELIPKAN KODE BARU UNTUK KARTU PERINGATAN DI SINI
try {
    if (vKustom instanceof ViewGroup) {
        PackageWarningHelper warningHelper = new PackageWarningHelper(context);
        warningHelper.attachTo((ViewGroup) vKustom);
    }
} catch (Exception e) {
    e.printStackTrace();
}


            // ====================================================
            // VIEW HERO
            // ====================================================
            TextView txtHeroRole =
                    vKustom.findViewById(
                            R.id.heroRole
                    );

            TextView tDurP =
                    vKustom.findViewById(
                            R.id.textDurabilityPercent
                    );

            TextView tOffP =
                    vKustom.findViewById(
                            R.id.textOffensePercent
                    );

            TextView tCtrlP =
                    vKustom.findViewById(
                            R.id.textControlPercent
                    );

            TextView tDiffP =
                    vKustom.findViewById(
                            R.id.textDifficultyPercent
                    );

            ProgressBar pDur =
                    vKustom.findViewById(
                            R.id.progressDurability
                    );

            ProgressBar pOff =
                    vKustom.findViewById(
                            R.id.progressOffense
                    );

            ProgressBar pCtrl =
                    vKustom.findViewById(
                            R.id.progressControl
                    );

            ProgressBar pDiff =
                    vKustom.findViewById(
                            R.id.progressDifficulty
                    );

            ImageView imgHero =
                    vKustom.findViewById(
                            R.id.imageview2
                    );

            ImageView sPasif =
                    vKustom.findViewById(
                            R.id.imgSkillPasif
                    );

            ImageView s1 =
                    vKustom.findViewById(
                            R.id.imgSkill1
                    );

            ImageView s2 =
                    vKustom.findViewById(
                            R.id.imgSkill2
                    );

            ImageView sUlt =
                    vKustom.findViewById(
                            R.id.imgSkillUlt
                    );

            // ====================================================
            // PENTING:
            // layoutHeroStats TIDAK LAGI MENJADI CONTAINER.
            // TRANSPARAN SAJA.
            // ====================================================
            View stats =
                    vKustom.findViewById(
                            R.id.layoutHeroStats
                    );

            if (stats != null) {

                stats.setBackgroundColor(
                        Color.TRANSPARENT
                );
            }

            // ====================================================
            // SEMBUNYIKAN BAGIAN YANG MEMANG TIDAK DIPAKAI
            // ====================================================
            View skillTitle =
                    vKustom.findViewById(
                            R.id.layoutSkillTitle
                    );

            View skillDesc =
                    vKustom.findViewById(
                            R.id.layoutSkillDesc
                    );

            View bestBuild =
                    vKustom.findViewById(
                            R.id.layoutBestBuild
                    );

            if (skillTitle != null)
                skillTitle.setVisibility(View.GONE);

            if (skillDesc != null)
                skillDesc.setVisibility(View.GONE);

            if (bestBuild != null)
                bestBuild.setVisibility(View.GONE);

            // ====================================================
            // HILANGKAN TEXTVIEW DEFAULT "TextView"
            //
            // Ini untuk 3 TextView yang sebelumnya ikut muncul.
            // Tidak mengganggu TextView yang memang kita isi.
            // ====================================================
            hideDefaultTextViews(
                    vKustom,
                    txtHeroRole,
                    tDurP,
                    tOffP,
                    tCtrlP,
                    tDiffP
            );

            // ====================================================
            // NAMA HERO + ROLE
            // ====================================================
            if (txtHeroRole != null) {

                String namaHero =
                        heroData.containsKey("her")
                        ? String.valueOf(
                                heroData.get("her")
                        )
                        : "Hero";

                String roleHero =
                        heroData.containsKey("roll")
                        ? String.valueOf(
                                heroData.get("roll")
                        )
                        : "";

                txtHeroRole.setText(
                        namaHero +
                        "\n" +
                        roleHero
                );

                txtHeroRole.setTextColor(
                        Color.WHITE
                );
            }

            // ====================================================
            // STAT HERO
            // ====================================================
            int durability = 0;
            int offense = 0;
            int control = 0;
            int difficulty = 0;

            try {
                durability =
                        (int) Double.parseDouble(
                                String.valueOf(
                                        heroData.get(
                                                "stat_durability"
                                        )
                                ).trim()
                        );
            } catch (Exception e) {}

            try {
                offense =
                        (int) Double.parseDouble(
                                String.valueOf(
                                        heroData.get(
                                                "stat_offense"
                                        )
                                ).trim()
                        );
            } catch (Exception e) {}

            try {
                control =
                        (int) Double.parseDouble(
                                String.valueOf(
                                        heroData.get(
                                                "stat_control"
                                        )
                                ).trim()
                        );
            } catch (Exception e) {}

            try {
                difficulty =
                        (int) Double.parseDouble(
                                String.valueOf(
                                        heroData.get(
                                                "stat_difficulty"
                                        )
                                ).trim()
                        );
            } catch (Exception e) {}

            // ====================================================
            // TEXT STAT
            // ====================================================
            if (tDurP != null) {

                tDurP.setText(
                        "Ketahanan  " +
                        durability +
                        "%"
                );
            }

            if (tOffP != null) {

                tOffP.setText(
                        "Serangan  " +
                        offense +
                        "%"
                );
            }

            if (tCtrlP != null) {

                tCtrlP.setText(
                        "Efek Kontrol  " +
                        control +
                        "%"
                );
            }

            if (tDiffP != null) {

                tDiffP.setText(
                        "Kesulitan  " +
                        difficulty +
                        "%"
                );
            }

            // ====================================================
            // PREMIUM WARNA + ANIMASI PROGRESS
            // ====================================================
            // Setiap stat memiliki warna khas seperti desain referensi:
            // Ketahanan  = hijau
            // Serangan    = merah
            // Kontrol     = biru
            // Kesulitan   = ungu
            //
            // Tidak mengubah layout/XML atau kode stat lainnya.
            // ====================================================

            if (pDur != null) {

                pDur.setMax(100);

                pDur.setProgressDrawable(
                        new PremiumProgressDrawable(
                                context,
                                Color.parseColor("#00C853"),
                                Color.parseColor("#39FF14"),
                                Color.parseColor("#76FF03")
                        )
                );

                pDur.setProgress(0);

                android.animation.ObjectAnimator
                        durAnimator =
                        android.animation.ObjectAnimator.ofInt(
                                pDur,
                                "progress",
                                0,
                                durability
                        );

                durAnimator.setDuration(850);
                durAnimator.setInterpolator(
                        new android.view.animation.DecelerateInterpolator()
                );
                durAnimator.start();
            }

            if (pOff != null) {

                pOff.setMax(100);

                pOff.setProgressDrawable(
                        new PremiumProgressDrawable(
                                context,
                                Color.parseColor("#D50000"),
                                Color.parseColor("#FF1744"),
                                Color.parseColor("#FF5252")
                        )
                );

                pOff.setProgress(0);

                android.animation.ObjectAnimator
                        offAnimator =
                        android.animation.ObjectAnimator.ofInt(
                                pOff,
                                "progress",
                                0,
                                offense
                        );

                offAnimator.setDuration(850);
                offAnimator.setInterpolator(
                        new android.view.animation.DecelerateInterpolator()
                );
                offAnimator.start();
            }

            if (pCtrl != null) {

                pCtrl.setMax(100);

                pCtrl.setProgressDrawable(
                        new PremiumProgressDrawable(
                                context,
                                Color.parseColor("#0066CC"),
                                Color.parseColor("#2196F3"),
                                Color.parseColor("#40C4FF")
                        )
                );

                pCtrl.setProgress(0);

                android.animation.ObjectAnimator
                        ctrlAnimator =
                        android.animation.ObjectAnimator.ofInt(
                                pCtrl,
                                "progress",
                                0,
                                control
                        );

                ctrlAnimator.setDuration(850);
                ctrlAnimator.setInterpolator(
                        new android.view.animation.DecelerateInterpolator()
                );
                ctrlAnimator.start();
            }

            if (pDiff != null) {

                pDiff.setMax(100);

                pDiff.setProgressDrawable(
                        new PremiumProgressDrawable(
                                context,
                                Color.parseColor("#7B1FA2"),
                                Color.parseColor("#D500F9"),
                                Color.parseColor("#EA80FC")
                        )
                );

                pDiff.setProgress(0);

                android.animation.ObjectAnimator
                        diffAnimator =
                        android.animation.ObjectAnimator.ofInt(
                                pDiff,
                                "progress",
                                0,
                                difficulty
                        );

                diffAnimator.setDuration(850);
                diffAnimator.setInterpolator(
                        new android.view.animation.DecelerateInterpolator()
                );
                diffAnimator.start();
            }

            // ====================================================
            // GAMBAR HERO UTAMA
            // DIKEMBALIKAN KE TAMPILAN YANG SUDAH PAS SEBELUMNYA.
            // Jangan ubah bentuk ImageView utama.
            // ====================================================
            if (imgHero != null) {

                imgHero.setScaleType(
                        ImageView.ScaleType.FIT_XY
                );

                float density =
                        context.getResources()
                                .getDisplayMetrics()
                                .density;

                final int radius = (int)(12 * density);
                final int strokeWidth = (int)(2 * density);

                imgHero.setBackgroundColor(Color.TRANSPARENT);

                GradientDrawable heroStroke =
                        new GradientDrawable();

                heroStroke.setColor(Color.TRANSPARENT);
                heroStroke.setCornerRadius(radius);
                heroStroke.setStroke(
                        strokeWidth,
                        Color.WHITE
                );

                imgHero.setForeground(heroStroke);
                imgHero.setClipToOutline(true);

                String urlHero =
                        heroData.containsKey("URL")
                        ? String.valueOf(
                                heroData.get("URL")
                        )
                        : "";

                if (!urlHero.isEmpty()) {

                    Glide.with(context)
                            .load(urlHero)
                            .placeholder(
                                    R.drawable.herokosong
                            )
                            .error(
                                    R.drawable.herokosong
                            )
                            .transform(
                                    new com.bumptech.glide.load.resource.bitmap.RoundedCorners(
                                            radius
                                    )
                            )
                            .into(imgHero);
                } else {

                    imgHero.setImageResource(
                            R.drawable.herokosong
                    );
                }
            }

            // ====================================================
            // SKILL PASIF
            // ====================================================
            if (sPasif != null &&
                heroData.containsKey(
                        "skill_pasif_URL"
                )) {

                Glide.with(context)
                        .load(
                                String.valueOf(
                                        heroData.get(
                                                "skill_pasif_URL"
                                        )
                                )
                        )
                        .placeholder(
                                R.drawable.herokosong
                        )
                        .transform(
                                new com.bumptech.glide.load.resource.bitmap.CircleCrop()
                        )
                        .into(sPasif);
            }

            // ====================================================
            // SKILL 1
            // ====================================================
            if (s1 != null &&
                heroData.containsKey(
                        "skill1_URL"
                )) {

                Glide.with(context)
                        .load(
                                String.valueOf(
                                        heroData.get(
                                                "skill1_URL"
                                        )
                                )
                        )
                        .placeholder(
                                R.drawable.herokosong
                        )
                        .transform(
                                new com.bumptech.glide.load.resource.bitmap.CircleCrop()
                        )
                        .into(s1);
            }

            // ====================================================
            // SKILL 2
            // ====================================================
            if (s2 != null &&
                heroData.containsKey(
                        "skill2_URL"
                )) {

                Glide.with(context)
                        .load(
                                String.valueOf(
                                        heroData.get(
                                                "skill2_URL"
                                        )
                                )
                        )
                        .placeholder(
                                R.drawable.herokosong
                        )
                        .transform(
                                new com.bumptech.glide.load.resource.bitmap.CircleCrop()
                        )
                        .into(s2);
            }

            // ====================================================
            // ULTIMATE
            // ====================================================
            if (sUlt != null &&
                heroData.containsKey(
                        "skill_ult_URL"
                )) {

                Glide.with(context)
                        .load(
                                String.valueOf(
                                        heroData.get(
                                                "skill_ult_URL"
                                        )
                                )
                        )
                        .placeholder(
                                R.drawable.herokosong
                        )
                        .transform(
                                new com.bumptech.glide.load.resource.bitmap.CircleCrop()
                        )
                        .into(sUlt);
            }

            // ====================================================
            // TOUCH SKILL
            // ====================================================
            View.OnTouchListener skillTouch =
                    (v, e) -> {

                        if (e.getAction() ==
                                MotionEvent.ACTION_DOWN) {

                            v.animate()
                                    .scaleX(0.88f)
                                    .scaleY(0.88f)
                                    .setDuration(80)
                                    .start();
                        }

                        if (e.getAction() ==
                                MotionEvent.ACTION_CANCEL ||
                            e.getAction() ==
                                MotionEvent.ACTION_UP) {

                            v.animate()
                                    .scaleX(1f)
                                    .scaleY(1f)
                                    .setDuration(80)
                                    .start();

                            if (e.getAction() ==
                                    MotionEvent.ACTION_UP) {

                                tampilkanSkill(
                                        heroData,
                                        v.getId()
                                );
                            }
                        }

                        return true;
                    };

            if (sPasif != null)
                sPasif.setOnTouchListener(skillTouch);

            if (s1 != null)
                s1.setOnTouchListener(skillTouch);

            if (s2 != null)
                s2.setOnTouchListener(skillTouch);

            if (sUlt != null)
                sUlt.setOnTouchListener(skillTouch);

            // ====================================================
            // HORIZONTAL HERO SELECTOR
            // Ditempatkan di bawah area 4 icon skill.
            // Menggunakan listHero dari detail_hero.json yang sama.
            // Tidak ada request JSON tambahan.
            // ====================================================
            addHeroSelector(
                    vKustom,
                    sUlt,
                    listHero
            );

            // ====================================================
            // PAKSA FULL WIDTH
            // ====================================================
            FrameLayout.LayoutParams lp =
                    new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.WRAP_CONTENT
                    );

            vKustom.setLayoutParams(lp);

            // ====================================================
            // MASUKKAN HERO DETAIL KE ITEM RECYCLERVIEW
            // BUKAN KE layoutHeroStats MAINACTIVITY
            // ====================================================
            holder.container.addView(
                    vKustom
            );

            holder.container.setVisibility(
                    View.VISIBLE
            );

        } catch (Exception e) {

            e.printStackTrace();

            holder.container.removeAllViews();
        }
    }

    // ========================================================
    // TAMBAHKAN HORIZONTAL HERO SELECTOR
    // ========================================================
    private void addHeroSelector(
            View root,
            View skillAnchor,
            ArrayList<HashMap<String, Object>> listHero) {

        try {

            if (!(root instanceof ViewGroup) ||
                listHero == null ||
                listHero.size() == 0) {
                return;
            }

            final ViewGroup rootGroup =
                    (ViewGroup) root;

            float density =
                    context.getResources()
                            .getDisplayMetrics()
                            .density;

            // ----------------------------------------------------
            // Hapus selector lama saat ViewHolder di-bind ulang.
            // ----------------------------------------------------
            View oldSelector =
                    rootGroup.findViewWithTag("ZERO_HERO_SELECTOR");

            if (oldSelector != null) {
                ViewParent parent = oldSelector.getParent();

                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(oldSelector);
                }
            }

            // ----------------------------------------------------
            // RECYCLERVIEW HORIZONTAL LANGSUNG.
            // Tidak memakai container tambahan agar tidak ada
            // padding/margin kosong antara skill dan menu.
            // ----------------------------------------------------
            RecyclerView heroRecycler =
                    new RecyclerView(context);

            heroRecycler.setTag("ZERO_HERO_SELECTOR");

            heroRecycler.setLayoutManager(
                    new androidx.recyclerview.widget.LinearLayoutManager(
                            context,
                            androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL,
                            false
                    )
            );

            heroRecycler.setHasFixedSize(true);
            heroRecycler.setNestedScrollingEnabled(false);
            heroRecycler.setOverScrollMode(
                    View.OVER_SCROLL_NEVER
            );

            // Tinggi dibuat pas dengan icon + nama hero.
            // Tidak ada ruang kosong tambahan di bawah selector.
            LinearLayout.LayoutParams rvParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            (int)(98 * density)
                    );

            rvParams.topMargin = 0;
            // Kembalikan jarak HANYA di bawah Hero Selector,
            // supaya ada napas sebelum menu pertama.
            rvParams.bottomMargin = (int)(18 * density);
            heroRecycler.setLayoutParams(rvParams);

            HeroSelectorAdapter selectorAdapter =
                    new HeroSelectorAdapter(
                            context,
                            listHero
                    );

            heroRecycler.setAdapter(selectorAdapter);

            // ----------------------------------------------------
            // CARI CONTAINER VERTIKAL TERDEKAT DENGAN SKILL.
            // Selector ditempatkan tepat setelah baris skill.
            // ----------------------------------------------------
            ViewGroup targetParent = null;
            int targetIndex = -1;

            if (skillAnchor != null) {

                View current = skillAnchor;

                while (current.getParent() instanceof ViewGroup) {

                    ViewParent vp = current.getParent();
                    ViewGroup parent = (ViewGroup) vp;

                    if (parent instanceof LinearLayout &&
                        ((LinearLayout) parent).getOrientation() ==
                                LinearLayout.VERTICAL) {

                        targetParent = parent;
                        targetIndex = parent.indexOfChild(current) + 1;
                        break;
                    }

                    current = parent;
                }
            }

            if (targetParent == null) {
                targetParent = rootGroup;
                targetIndex = targetParent.getChildCount();
            }

            if (targetIndex < 0 ||
                targetIndex > targetParent.getChildCount()) {
                targetIndex = targetParent.getChildCount();
            }

            targetParent.addView(
                    heroRecycler,
                    targetIndex
            );

            // ----------------------------------------------------
            // OTOMATIS GESER KE HERO AKTIF.
            // ----------------------------------------------------
            final int activeIndex = selectedHeroIndex;

            if (activeIndex >= 0 &&
                activeIndex < listHero.size()) {

                heroRecycler.postDelayed(
                        new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    heroRecycler.smoothScrollToPosition(
                                            activeIndex
                                    );
                                } catch (Exception e) {
                                    heroRecycler.scrollToPosition(
                                            activeIndex
                                    );
                                }
                            }
                        },
                        80
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ========================================================
    // ADAPTER ICON HERO
    // ========================================================
    private class HeroSelectorAdapter
            extends RecyclerView.Adapter<HeroSelectorAdapter.HeroSelectorHolder> {

        private final Context ctx;
        private final ArrayList<HashMap<String, Object>> heroes;

        HeroSelectorAdapter(
                Context ctx,
                ArrayList<HashMap<String, Object>> heroes) {

            this.ctx = ctx;
            this.heroes = heroes;
        }

        @NonNull
        @Override
        public HeroSelectorHolder onCreateViewHolder(
                @NonNull ViewGroup parent,
                int viewType) {

            float density =
                    ctx.getResources()
                            .getDisplayMetrics()
                            .density;

            LinearLayout item =
                    new LinearLayout(ctx);

            item.setOrientation(
                    LinearLayout.VERTICAL
            );
            item.setGravity(
                    android.view.Gravity.CENTER
            );
            item.setPadding(
                    (int)(4 * density),
                    0,
                    (int)(4 * density),
                    0
            );

            RecyclerView.LayoutParams itemParams =
                    new RecyclerView.LayoutParams(
                            (int)(94 * density),
                            RecyclerView.LayoutParams.MATCH_PARENT
                    );

            item.setLayoutParams(itemParams);

            // Outer frame = tempat STROKE.
            // Inner ImageView = gambar yang benar-benar di-clip bulat.
            FrameLayout imageFrame =
                    new FrameLayout(ctx);

            LinearLayout.LayoutParams frameParams =
                    new LinearLayout.LayoutParams(
                            (int)(82 * density),
                            (int)(82 * density)
                    );

            imageFrame.setLayoutParams(frameParams);

            ImageView image =
                    new ImageView(ctx);

            image.setScaleType(
                    ImageView.ScaleType.CENTER_CROP
            );

            FrameLayout.LayoutParams imageParams =
                    new FrameLayout.LayoutParams(
                            (int)(74 * density),
                            (int)(74 * density),
                            android.view.Gravity.CENTER
                    );

            image.setLayoutParams(imageParams);

            // Rounded clip untuk BITMAP, tanpa stroke di ImageView.
            GradientDrawable imageClip =
                    new GradientDrawable();
            imageClip.setColor(Color.TRANSPARENT);
            imageClip.setCornerRadius((int)(17 * density));
            image.setBackground(imageClip);
            image.setClipToOutline(true);

            TextView name =
                    new TextView(ctx);

            name.setTextColor(Color.WHITE);
            name.setTextSize(
                    TypedValue.COMPLEX_UNIT_DIP,
                    10
            );
            name.setGravity(
                    android.view.Gravity.CENTER
            );
            name.setSingleLine(true);
            name.setEllipsize(
                    android.text.TextUtils.TruncateAt.END
            );

            LinearLayout.LayoutParams nameParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            nameParams.topMargin =
                    (int)(2 * density);

            item.addView(imageFrame, frameParams);
            imageFrame.addView(image, imageParams);
            item.addView(name, nameParams);

            return new HeroSelectorHolder(
                    item,
                    imageFrame,
                    image,
                    name
            );
        }

        @Override
        public void onBindViewHolder(
                @NonNull HeroSelectorHolder holder,
                int position) {

            if (position < 0 ||
                position >= heroes.size()) {
                return;
            }

            HashMap<String, Object> hero =
                    heroes.get(position);

            if (hero == null) {
                return;
            }

            String name =
                    hero.containsKey("her") &&
                    hero.get("her") != null
                    ? String.valueOf(hero.get("her"))
                    : "Hero";

            String url =
                    hero.containsKey("URL") &&
                    hero.get("URL") != null
                    ? String.valueOf(hero.get("URL"))
                    : "";

            holder.name.setText(name);

            // ----------------------------------------------------
            // SELECTED STATE + BORDER YANG BENAR-BENAR MEMBUNGKUS
            // ----------------------------------------------------
            boolean selected =
                    position == selectedHeroIndex;

            float density =
                    ctx.getResources()
                            .getDisplayMetrics()
                            .density;

            // Icon selector benar-benar BULAT karena frame dan image sama-sama
            // menggunakan radius setengah dari sisi kotaknya.
            final int imageRadius = (int)(37 * density);
            final int frameRadius = (int)(41 * density);
            final int strokeWidth =
                    selected
                    ? (int)(4 * density)
                    : (int)(2 * density);

            // ImageView hanya bertugas menampilkan gambar.
            // Stroke TIDAK ditempel ke ImageView supaya tidak tenggelam
            // atau melebar keluar dari sudut gambar.
            holder.image.setPadding(0, 0, 0, 0);

            GradientDrawable imageClip =
                    new GradientDrawable();
            imageClip.setColor(Color.TRANSPARENT);
            imageClip.setCornerRadius(imageRadius);
            holder.image.setBackground(imageClip);
            holder.image.setClipToOutline(true);
            holder.image.setForeground(null);

            // Stroke ditempel pada FRAME luar.
            // Hasilnya: gambar bulat sempurna + stroke membungkus dari luar.
            GradientDrawable border =
                    new GradientDrawable();
            border.setColor(Color.TRANSPARENT);
            border.setCornerRadius(frameRadius);
            border.setStroke(
    strokeWidth,
    selected
        ? Color.parseColor("#D500F9")
        : Color.WHITE
);

            holder.imageFrame.setBackgroundColor(Color.TRANSPARENT);
            holder.imageFrame.setForeground(border);

            if (!url.isEmpty()) {

                Glide.with(ctx)
                        .load(url)
                        .placeholder(
                                R.drawable.herokosong
                        )
                        .error(
                                R.drawable.herokosong
                        )
                        .transform(
                                new com.bumptech.glide.load.resource.bitmap.RoundedCorners(
                                        imageRadius
                                )
                        )
                        .into(holder.image);
            } else {

                holder.image.setImageResource(
                        R.drawable.herokosong
                );
            }

            holder.itemView.setOnTouchListener(
                    new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(
                                View v,
                                MotionEvent event) {

                            if (event.getAction() ==
                                    MotionEvent.ACTION_DOWN) {

                                v.animate()
                                        .scaleX(0.88f)
                                        .scaleY(0.88f)
                                        .setDuration(70)
                                        .start();

                            } else if (
                                    event.getAction() ==
                                            MotionEvent.ACTION_UP ||
                                    event.getAction() ==
                                            MotionEvent.ACTION_CANCEL) {

                                v.animate()
                                        .scaleX(1f)
                                        .scaleY(1f)
                                        .setDuration(100)
                                        .start();
                            }

                            return false;
                        }
                    }
            );

            holder.itemView.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            if (position < 0 ||
                                position >= heroes.size()) {
                                return;
                            }

                            // ----------------------------------------
                            // USER MEMILIH HERO
                            // ----------------------------------------
                            // Teruskan ke OUTER MenuAdapter.
                            // Jangan memanggil notifyItemChanged(0)
                            // pada HeroSelectorAdapter karena index 0
                            // milik selector, bukan Hero Detail utama.
                            MenuAdapter.this.selectHeroFromSelector(
                                    position
                            );

                        }
                    }
            );
        }

        @Override
        public int getItemCount() {
            return heroes != null ? heroes.size() : 0;
        }

        class HeroSelectorHolder
                extends RecyclerView.ViewHolder {

            FrameLayout imageFrame;
            ImageView image;
            TextView name;

            HeroSelectorHolder(
                    @NonNull View itemView,
                    FrameLayout imageFrame,
                    ImageView image,
                    TextView name) {

                super(itemView);
                this.imageFrame = imageFrame;
                this.image = image;
                this.name = name;
            }
        }
    }

    // ========================================================
    // SEMBUNYIKAN TEXTVIEW DEFAULT
    // ========================================================
    private void hideDefaultTextViews(
            View root,
            TextView heroRole,
            TextView durability,
            TextView offense,
            TextView control,
            TextView difficulty) {

        if (!(root instanceof ViewGroup))
            return;

        ViewGroup group =
                (ViewGroup) root;

        for (int i = 0;
             i < group.getChildCount();
             i++) {

            View child =
                    group.getChildAt(i);

            if (child instanceof TextView) {

                TextView tv =
                        (TextView) child;

                // Jangan sembunyikan TextView
                // yang memang dipakai Hero Detail.
                if (tv == heroRole ||
                    tv == durability ||
                    tv == offense ||
                    tv == control ||
                    tv == difficulty) {

                    continue;
                }

                String text =
                        tv.getText() == null
                        ? ""
                        : tv.getText()
                            .toString()
                            .trim();

                // Ini yang menghilangkan
                // TextView bawaan XML.
                if (text.equalsIgnoreCase(
                        "TextView"
                )) {

                    tv.setVisibility(
                            View.GONE
                    );
                }

            } else if (child instanceof ViewGroup) {

                hideDefaultTextViews(
                        child,
                        heroRole,
                        durability,
                        offense,
                        control,
                        difficulty
                );
            }
        }
    }

    // ========================================================
    // POPUP SKILL
    // ========================================================
    private void tampilkanSkill(
            HashMap<String, Object> heroData,
            int viewId) {

        try {

            String fd =
                    heroData.containsKey(
                            "skill_desc"
                    )
                    ? String.valueOf(
                            heroData.get(
                                    "skill_desc"
                            )
                    )
                    : "";

            String j = "Skill";
            String d =
                    "Deskripsi tidak tersedia.";

            if (viewId == R.id.imgSkillPasif) {

                String[] b =
                        fd.split("🔵");

                if (b.length > 0) {

                    d = b[0]
                            .replace(
                                    "🔴",
                                    ""
                            )
                            .trim();

                    String[] br =
                            d.split("\n");

                    if (br.length > 0) {

                        j = br[0]
                                .replace(
                                        "PASIF - ",
                                        ""
                                )
                                .replace(
                                        ":",
                                        ""
                                )
                                .trim();
                    }
                }

                com.zero.tools.skin.security
                        .JsonManager
                        .tampilkanSkillPopup(
                                (MainActivity) context,
                                j,
                                d,
                                String.valueOf(
                                        heroData.get(
                                                "skill_pasif_URL"
                                        )
                                )
                        );
            }

            if (viewId == R.id.imgSkill1) {

                String[] b1 =
                        fd.split("🔵");

                if (b1.length > 1) {

                    String[] b2 =
                            b1[1].split("🟡");

                    if (b2.length > 0) {

                        d = b2[0].trim();

                        String[] br =
                                d.split("\n");

                        if (br.length > 0) {

                            j = br[0]
                                    .replace(
                                            "SKILL 1 - ",
                                            ""
                                    )
                                    .replace(
                                            ":",
                                            ""
                                    )
                                    .trim();
                        }
                    }
                }

                com.zero.tools.skin.security
                        .JsonManager
                        .tampilkanSkillPopup(
                                (MainActivity) context,
                                j,
                                d,
                                String.valueOf(
                                        heroData.get(
                                                "skill1_URL"
                                        )
                                )
                        );
            }

            if (viewId == R.id.imgSkill2) {

                String[] b1 =
                        fd.split("🟡");

                if (b1.length > 1) {

                    String[] b2 =
                            b1[1].split("💜");

                    if (b2.length > 0) {

                        d = b2[0].trim();

                        String[] br =
                                d.split("\n");

                        if (br.length > 0) {

                            j = br[0]
                                    .replace(
                                            "SKILL 2 - ",
                                            ""
                                    )
                                    .replace(
                                            ":",
                                            ""
                                    )
                                    .trim();
                        }
                    }
                }

                com.zero.tools.skin.security
                        .JsonManager
                        .tampilkanSkillPopup(
                                (MainActivity) context,
                                j,
                                d,
                                String.valueOf(
                                        heroData.get(
                                                "skill2_URL"
                                        )
                                )
                        );
            }

            if (viewId == R.id.imgSkillUlt) {

                String[] b =
                        fd.split("💜");

                if (b.length > 1) {

                    d = b[1].trim();

                    String[] br =
                            d.split("\n");

                    if (br.length > 0) {

                        j = br[0]
                                .replaceAll(
                                        "ULTIMATE \\(SKILL \\d+\\) - ",
                                        ""
                                )
                                .replace(
                                        ":",
                                        ""
                                )
                                .trim();
                    }
                }

                com.zero.tools.skin.security
                        .JsonManager
                        .tampilkanSkillPopup(
                                (MainActivity) context,
                                j,
                                d,
                                String.valueOf(
                                        heroData.get(
                                                "skill_ult_URL"
                                        )
                                )
                        );
            }

        } catch (Exception e) {}
    }

    // ========================================================
    // ========================================================
    // MENU NORMAL
    // ========================================================
    // ========================================================
    private void bindMenu(
            MenuViewHolder holder,
            int currentPos) {

        if (breh == null ||
            currentPos < 0 ||
            currentPos >= breh.size()) {

            return;
        }

        final HashMap<String, Object> menuData =
                breh.get(currentPos);

        final Context ctx =
                holder.itemView.getContext();

        // ====================================================
        // FIX JARAK ITEM
        // ====================================================
        ViewGroup.LayoutParams layoutParams =
                holder.itemView.getLayoutParams();

        if (layoutParams instanceof RecyclerView.LayoutParams) {

            RecyclerView.LayoutParams params =
                    (RecyclerView.LayoutParams)
                            layoutParams;

            params.height =
                    RecyclerView.LayoutParams.WRAP_CONTENT;

            params.setMargins(
                    0,
                    0,
                    0,
                    9
            );

            holder.itemView.setLayoutParams(
                    params
            );
        }

        // ====================================================
        // ICON KIRI
        // ====================================================
        if (menuData.containsKey(
                "menu_icon_left"
        ) &&
            menuData.get(
                    "menu_icon_left"
            ) != null) {

            String url =
                    String.valueOf(
                            menuData.get(
                                    "menu_icon_left"
                            )
                    );

            Glide.with(
                    ctx.getApplicationContext()
            )
            .load(url)
            .placeholder(
                    R.drawable.herokosong
            )
            .transform(
                    new com.bumptech.glide.load.resource.bitmap.RoundedCorners(
                            25
                    )
            )
            .into(holder.imageview1);
        }

        // ====================================================
        // ICON KANAN
        // ====================================================
        if (menuData.containsKey(
                "menu_icon_right"
        ) &&
            menuData.get(
                    "menu_icon_right"
            ) != null) {

            String url =
                    String.valueOf(
                            menuData.get(
                                    "menu_icon_right"
                            )
                    );

            Glide.with(
                    ctx.getApplicationContext()
            )
            .load(url)
            .placeholder(
                    R.drawable.herokosong
            )
            .transform(
                    new com.bumptech.glide.load.resource.bitmap.RoundedCorners(
                            25
                    )
            )
            .into(holder.imageview2);
        }

        // ====================================================
        // MARQUEE
        // ====================================================
        holder.textview1.clearAnimation();
        holder.textview2.clearAnimation();

        holder.textview1.setSelected(true);
        holder.textview2.setSelected(true);

        if (menuData.containsKey(
                "menu_title"
        ) &&
            menuData.get(
                    "menu_title"
            ) != null) {

            holder.textview1.setText(
                    String.valueOf(
                            menuData.get(
                                    "menu_title"
                            )
                    )
            );

        } else {

            holder.textview1.setText("");
        }

        if (menuData.containsKey(
                "menu_sub"
        ) &&
            menuData.get(
                    "menu_sub"
            ) != null) {

            holder.textview2.setText(
                    String.valueOf(
                            menuData.get(
                                    "menu_sub"
                            )
                    )
            );

        } else {

            holder.textview2.setText("");
        }

        // ====================================================
        // BACKGROUND
        // ====================================================
        holder.linear1.setBackground(
                new GradientDrawable() {

                    public GradientDrawable getIns(
                            int a,
                            int b,
                            int c,
                            int d) {

                        this.setCornerRadius(a);
                        this.setStroke(b, c);
                        this.setColor(d);

                        return this;
                    }

                }.getIns(
                        30,
                        3,
                        0xFFFFFFFF,
                        0xFF000000
                )
        );

        // ====================================================
        // ANIMASI TEKAN
        // ====================================================
        holder.linear1.setOnTouchListener(
                new View.OnTouchListener() {

                    @Override
                    public boolean onTouch(
                            View v,
                            MotionEvent event) {

                        switch (
                                event.getAction()
                        ) {

                            case MotionEvent.ACTION_DOWN:

                                v.animate()
                                        .scaleX(0.92f)
                                        .scaleY(0.92f)
                                        .setDuration(80)
                                        .start();

                                break;

                            case MotionEvent.ACTION_UP:
                            case MotionEvent.ACTION_CANCEL:
                            case MotionEvent.ACTION_OUTSIDE:

                                v.animate()
                                        .scaleX(1f)
                                        .scaleY(1f)
                                        .setDuration(150)
                                        .start();

                                break;
                        }

                        return false;
                    }
                }
        );

        // ====================================================
        // CLICK MENU
        // ====================================================
        holder.linear1.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(
                            View _view) {

                        String target =
                                String.valueOf(
                                        menuData.get(
                                                "target_page"
                                        ) != null
                                        ? menuData.get(
                                                "target_page"
                                        )
                                        : ""
                                );

                        float density =
                                ctx.getResources()
                                        .getDisplayMetrics()
                                        .density;

                        View.OnTouchListener bT =
                                (b, e) -> {

                                    if (e.getAction() ==
                                            MotionEvent.ACTION_DOWN) {

                                        b.animate()
                                                .scaleX(0.9f)
                                                .scaleY(0.9f)
                                                .setDuration(100)
                                                .start();
                                    }

                                    if (e.getAction() ==
                                            MotionEvent.ACTION_UP ||
                                        e.getAction() ==
                                            MotionEvent.ACTION_CANCEL) {

                                        b.animate()
                                                .scaleX(1f)
                                                .scaleY(1f)
                                                .setDuration(100)
                                                .start();
                                    }

                                    return false;
                                };

SharedPreferences sp = ctx.getSharedPreferences("sp", Context.MODE_PRIVATE);

                        if (menuData.containsKey(
                                "menu_title"
                        ) &&
                            menuData.get(
                                "menu_title"
                        ) != null) {

                            sp.edit()
                                    .putString(
                                            "her",
                                            String.valueOf(
                                                    menuData.get(
                                                            "menu_title"
                                                    )
                                            )
                                    )
                                    .apply();
                        }

                        Intent intent =
                                new Intent();

                        intent.addFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK
                        );

                        // ====================================================
                        // ACTIVITY
                        // ====================================================
                        if (target.equals(
                                "AllskinActivity"
                        )) {

                            intent.setClass(
                                    ctx.getApplicationContext(),
                                    AllskinActivity.class
                            );

                            ctx.startActivity(
                                    intent
                            );

                        } else if (target.equals(
                                "EequipmentActivity"
                        )) {

                            intent.setClass(
                                    ctx.getApplicationContext(),
                                    EequipmentActivity.class
                            );

                            ctx.startActivity(
                                    intent
                            );

                        } else if (target.equals(
                                "CalculatorActivity"
                        )) {

                            intent.setClass(
                                    ctx.getApplicationContext(),
                                    CalculatorActivity.class
                            );

                            ctx.startActivity(
                                    intent
                            );

                        }

                        // ====================================================
                        // JOIN GROUP
                        // ====================================================
                        else if (target.equals(
                                "_group"
                        )) {

                            androidx.appcompat.app.AlertDialog.Builder builder =
                                    new androidx.appcompat.app.AlertDialog.Builder(
                                            ctx
                                    );

                            builder.setTitle(
                                    "Join Group"
                            );

                            android.widget.ScrollView scroll =
                                    new android.widget.ScrollView(
                                            ctx
                                    );

                            scroll.setFillViewport(
                                    true
                            );

                            LinearLayout layout =
                                    new LinearLayout(
                                            ctx
                                    );

                            layout.setOrientation(
                                    LinearLayout.VERTICAL
                            );

                            layout.setPadding(
                                    (int)(25 * density),
                                    (int)(20 * density),
                                    (int)(25 * density),
                                    (int)(20 * density)
                            );

                            layout.setGravity(
                                    android.view.Gravity.CENTER
                            );

                            LinearLayout.LayoutParams bP =
                                    new LinearLayout.LayoutParams(
                                            LinearLayout.LayoutParams.MATCH_PARENT,
                                            (int)(50 * density)
                                    );

                            bP.setMargins(
                                    0,
                                    (int)(10 * density),
                                    0,
                                    0
                            );

                            android.widget.Button btnJoin =
                                    new android.widget.Button(
                                            ctx
                                    );

                            btnJoin.setText(
                                    "Join"
                            );

                            btnJoin.setTextColor(
                                    Color.WHITE
                            );

                            btnJoin.setAllCaps(
                                    false
                            );

                            btnJoin.setTypeface(
                                    null,
                                    Typeface.BOLD
                            );

                            btnJoin.setTextSize(
                                    TypedValue.COMPLEX_UNIT_DIP,
                                    13
                            );

                            btnJoin.setLayoutParams(
                                    bP
                            );

                            android.widget.Button btnClose =
                                    new android.widget.Button(
                                            ctx
                                    );

                            btnClose.setText(
                                    "Close"
                            );

                            btnClose.setTextColor(
                                    Color.WHITE
                            );

                            btnClose.setAllCaps(
                                    false
                            );

                            btnClose.setTypeface(
                                    null,
                                    Typeface.BOLD
                            );

                            btnClose.setTextSize(
                                    TypedValue.COMPLEX_UNIT_DIP,
                                    13
                            );

                            btnClose.setLayoutParams(
                                    bP
                            );

                            btnJoin.setOnTouchListener(bT);
                            btnClose.setOnTouchListener(bT);

                            layout.addView(btnJoin);
                            layout.addView(btnClose);

                            scroll.addView(layout);

                            builder.setView(scroll);

                            final androidx.appcompat.app.AlertDialog dialog =
                                    builder.create();

                            dialog.show();

                            GradientDrawable bg =
                                    new GradientDrawable();

                            bg.setCornerRadius(
                                    20 * density
                            );

                            bg.setColor(
                                    Color.BLACK
                            );

                            bg.setStroke(
                                    4,
                                    Color.WHITE
                            );

                            if (dialog.getWindow() != null) {

                                dialog.getWindow()
                                        .setBackgroundDrawable(bg);

                                dialog.getWindow()
                                        .getAttributes()
                                        .windowAnimations =
                                        android.R.style.Animation_Dialog;
                            }

                            btnJoin.setBackground(
                                    new GradientDrawable() {{
                                        setCornerRadius(
                                                16 * density
                                        );

                                        setColor(
                                                Color.parseColor(
                                                        "#4A148C"
                                                )
                                        );

                                        setStroke(
                                                3,
                                                Color.WHITE
                                        );
                                    }}
                            );

                            btnJoin.setOnClickListener(
                                    v1 -> {

                                        Intent i =
                                                new Intent(
                                                        Intent.ACTION_VIEW,
                                                        Uri.parse(
                                                                "https://chat.whatsapp.com/LdFrdpAX4gP5xLjoGYzAsS"
                                                        )
                                                );

                                        i.addFlags(
                                                Intent.FLAG_ACTIVITY_NEW_TASK
                                        );

                                        ctx.startActivity(i);
                                    }
                            );

                            btnClose.setBackground(
                                    new GradientDrawable() {{
                                        setCornerRadius(
                                                16 * density
                                        );

                                        setColor(
                                                Color.parseColor(
                                                        "#D50000"
                                                )
                                        );

                                        setStroke(
                                                3,
                                                Color.WHITE
                                        );
                                    }}
                            );

                            btnClose.setOnClickListener(
                                    v2 -> dialog.dismiss()
                            );
                        }

                        // ====================================================
                        // CUSTOMER SERVICE
                        // ====================================================
                        else if (target.equals(
                                "_cs"
                        )) {

                            androidx.appcompat.app.AlertDialog.Builder builder =
                                    new androidx.appcompat.app.AlertDialog.Builder(
                                            ctx
                                    );

                            builder.setTitle(
                                    "Contact Admin"
                            );

                            android.widget.ScrollView scroll =
                                    new android.widget.ScrollView(
                                            ctx
                                    );

                            scroll.setFillViewport(
                                    true
                            );

                            LinearLayout layout =
                                    new LinearLayout(
                                            ctx
                                    );

                            layout.setOrientation(
                                    LinearLayout.VERTICAL
                            );

                            layout.setPadding(
                                    (int)(25 * density),
                                    (int)(20 * density),
                                    (int)(25 * density),
                                    (int)(20 * density)
                            );

                            layout.setGravity(
                                    android.view.Gravity.CENTER
                            );

                            LinearLayout.LayoutParams bP =
                                    new LinearLayout.LayoutParams(
                                            LinearLayout.LayoutParams.MATCH_PARENT,
                                            (int)(50 * density)
                                    );

                            bP.setMargins(
                                    0,
                                    (int)(10 * density),
                                    0,
                                    0
                            );

                            android.widget.Button btnAdmin1 =
                                    new android.widget.Button(
                                            ctx
                                    );

                            btnAdmin1.setText(
                                    "Admin Ganteng"
                            );

                            btnAdmin1.setTextColor(
                                    Color.WHITE
                            );

                            btnAdmin1.setAllCaps(
                                    false
                            );

                            btnAdmin1.setTypeface(
                                    null,
                                    Typeface.BOLD
                            );

                            btnAdmin1.setTextSize(
                                    TypedValue.COMPLEX_UNIT_DIP,
                                    13
                            );

                            btnAdmin1.setLayoutParams(
                                    bP
                            );

                            android.widget.Button btnClose =
                                    new android.widget.Button(
                                            ctx
                                    );

                            btnClose.setText(
                                    "Close"
                            );

                            btnClose.setTextColor(
                                    Color.WHITE
                            );

                            btnClose.setAllCaps(
                                    false
                            );

                            btnClose.setTypeface(
                                    null,
                                    Typeface.BOLD
                            );

                            btnClose.setTextSize(
                                    TypedValue.COMPLEX_UNIT_DIP,
                                    13
                            );

                            btnClose.setLayoutParams(
                                    bP
                            );

                            btnAdmin1.setOnTouchListener(bT);
                            btnClose.setOnTouchListener(bT);

                            layout.addView(btnAdmin1);
                            layout.addView(btnClose);

                            scroll.addView(layout);

                            builder.setView(scroll);

                            final androidx.appcompat.app.AlertDialog dialog =
                                    builder.create();

                            dialog.show();

                            GradientDrawable bg =
                                    new GradientDrawable();

                            bg.setCornerRadius(
                                    20 * density
                            );

                            bg.setColor(
                                    Color.BLACK
                            );

                            bg.setStroke(
                                    4,
                                    Color.WHITE
                            );

                            if (dialog.getWindow() != null) {

                                dialog.getWindow()
                                        .setBackgroundDrawable(bg);

                                dialog.getWindow()
                                        .getAttributes()
                                        .windowAnimations =
                                        android.R.style.Animation_Dialog;
                            }

                            btnAdmin1.setBackground(
                                    new GradientDrawable() {{
                                        setCornerRadius(
                                                16 * density
                                        );

                                        setColor(
                                                Color.parseColor(
                                                        "#4A148C"
                                                )
                                        );

                                        setStroke(
                                                3,
                                                Color.WHITE
                                        );
                                    }}
                            );

                            btnAdmin1.setOnClickListener(
                                    v1 -> {

                                        Intent i =
                                                new Intent(
                                                        Intent.ACTION_VIEW,
                                                        Uri.parse(
                                                                "https://wa.me/+6283842778395"
                                                        )
                                                );

                                        i.addFlags(
                                                Intent.FLAG_ACTIVITY_NEW_TASK
                                        );

                                        ctx.startActivity(i);
                                    }
                            );

                            btnClose.setBackground(
                                    new GradientDrawable() {{
                                        setCornerRadius(
                                                16 * density
                                        );

                                        setColor(
                                                Color.parseColor(
                                                        "#D50000"
                                                )
                                        );

                                        setStroke(
                                                3,
                                                Color.WHITE
                                        );
                                    }}
                            );

                            btnClose.setOnClickListener(
                                    v3 -> dialog.dismiss()
                            );
                        }

                        // ====================================================
                        // TUTORIAL
                        // ====================================================
                        else if (target.equals(
                                "_tutorial"
                        )) {

                            androidx.appcompat.app.AlertDialog.Builder builder =
                                    new androidx.appcompat.app.AlertDialog.Builder(
                                            ctx
                                    );

                            builder.setTitle(
                                    "TUTORIAL ZERO TOOLS SKIN"
                            );

                            android.widget.ScrollView scroll =
                                    new android.widget.ScrollView(
                                            ctx
                                    );

                            scroll.setFillViewport(
                                    true
                            );

                            LinearLayout layout =
                                    new LinearLayout(
                                            ctx
                                    );

                            layout.setOrientation(
                                    LinearLayout.VERTICAL
                            );

                            layout.setPadding(
                                    (int)(25 * density),
                                    (int)(20 * density),
                                    (int)(25 * density),
                                    (int)(20 * density)
                            );

                            layout.setGravity(
                                    android.view.Gravity.CENTER
                            );

                            LinearLayout.LayoutParams bP =
                                    new LinearLayout.LayoutParams(
                                            LinearLayout.LayoutParams.MATCH_PARENT,
                                            (int)(50 * density)
                                    );

                            bP.setMargins(
                                    0,
                                    (int)(10 * density),
                                    0,
                                    0
                            );

                            android.widget.Button btnAdmin1 =
                                    new android.widget.Button(
                                            ctx
                                    );

                            btnAdmin1.setText(
                                    "Tonton/Watch"
                            );

                            btnAdmin1.setTextColor(
                                    Color.WHITE
                            );

                            btnAdmin1.setAllCaps(
                                    false
                            );

                            btnAdmin1.setTypeface(
                                    null,
                                    Typeface.BOLD
                            );

                            btnAdmin1.setTextSize(
                                    TypedValue.COMPLEX_UNIT_DIP,
                                    13
                            );

                            btnAdmin1.setLayoutParams(
                                    bP
                            );

                            btnAdmin1.setOnTouchListener(
                                    bT
                            );

                            layout.addView(
                                    btnAdmin1
                            );

                            scroll.addView(
                                    layout
                            );

                            builder.setView(
                                    scroll
                            );

                            final androidx.appcompat.app.AlertDialog dialog =
                                    builder.create();

                            dialog.show();

                            GradientDrawable bg =
                                    new GradientDrawable();

                            bg.setCornerRadius(
                                    20 * density
                            );

                            bg.setColor(
                                    Color.BLACK
                            );

                            bg.setStroke(
                                    4,
                                    Color.WHITE
                            );

                            if (dialog.getWindow() != null) {

                                dialog.getWindow()
                                        .setBackgroundDrawable(bg);

                                dialog.getWindow()
                                        .getAttributes()
                                        .windowAnimations =
                                        android.R.style.Animation_Dialog;
                            }

                            btnAdmin1.setBackground(
                                    new GradientDrawable() {{
                                        setCornerRadius(
                                                16 * density
                                        );

                                        setColor(
                                                Color.parseColor(
                                                        "#4A148C"
                                                )
                                        );

                                        setStroke(
                                                3,
                                                Color.WHITE
                                        );
                                    }}
                            );

                            btnAdmin1.setOnClickListener(
                                    v1 -> {

                                        Intent i =
                                                new Intent(
                                                        Intent.ACTION_VIEW,
                                                        Uri.parse(
                                                                "https://youtube.com/playlist?list=PL3fU1kworLKPIT97AfWDdqXX6Ni68HgyH&si=7PMRbc0mJTnhcUKX"
                                                        )
                                                );

                                        i.addFlags(
                                                Intent.FLAG_ACTIVITY_NEW_TASK
                                        );

                                        ctx.startActivity(i);
                                    }
                            );
                        }
                    }
                }
        );
    }

    // ========================================================
    // PREMIUM PROGRESS BAR
    // Gradient + rounded end + moving shine/glow.
    // Tidak membutuhkan XML tambahan.
    // ========================================================
    private static class PremiumProgressDrawable extends android.graphics.drawable.Drawable {

        private final android.graphics.Paint backgroundPaint =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        private final android.graphics.Paint fillPaint =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        private final android.graphics.Paint shinePaint =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        private final android.graphics.Paint borderPaint =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        private final android.graphics.Paint glowPaint =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        private final android.graphics.RectF rect =
                new android.graphics.RectF();

        private final android.graphics.RectF fillRect =
                new android.graphics.RectF();

        private final android.content.Context ctx;

        private final int colorStart;
        private final int colorMain;
        private final int colorEnd;

        private android.animation.ValueAnimator shimmerAnimator;
        private float shimmerPosition = 0f;

        PremiumProgressDrawable(
                android.content.Context context,
                int startColor,
                int mainColor,
                int endColor) {

            this.ctx = context;
            this.colorStart = startColor;
            this.colorMain = mainColor;
            this.colorEnd = endColor;

            backgroundPaint.setStyle(
                    android.graphics.Paint.Style.FILL
            );

            fillPaint.setStyle(
                    android.graphics.Paint.Style.FILL
            );

            shinePaint.setStyle(
                    android.graphics.Paint.Style.FILL
            );

            borderPaint.setStyle(
                    android.graphics.Paint.Style.STROKE
            );

            borderPaint.setStrokeWidth(
                    dp(1)
            );

            borderPaint.setColor(
                    android.graphics.Color.argb(
                            170,
                            255,
                            255,
                            255
                    )
            );

            glowPaint.setStyle(
                    android.graphics.Paint.Style.FILL
            );

            // Shine bergerak terus seperti progress bar premium.
            shimmerAnimator =
                    android.animation.ValueAnimator.ofFloat(
                            -0.20f,
                            1.20f
                    );

            shimmerAnimator.setDuration(1450);
            shimmerAnimator.setRepeatCount(
                    android.animation.ValueAnimator.INFINITE
            );
            shimmerAnimator.setRepeatMode(
                    android.animation.ValueAnimator.RESTART
            );

            shimmerAnimator.addUpdateListener(
                    new android.animation.ValueAnimator.AnimatorUpdateListener() {
                        @Override
                        public void onAnimationUpdate(
                                android.animation.ValueAnimator animation) {

                            shimmerPosition =
                                    (Float) animation.getAnimatedValue();

                            invalidateSelf();
                        }
                    }
            );

            // Mulai animasi langsung.
            // setCallback() tidak dioverride karena pada API Android
            // tertentu method tersebut bersifat final.
            shimmerAnimator.start();
        }

        private float dp(float value) {

            if (ctx == null) {
                return value;
            }

            return value *
                    ctx.getResources()
                            .getDisplayMetrics()
                            .density;
        }

        @Override
        public void draw(
                android.graphics.Canvas canvas) {

            android.graphics.Rect bounds =
                    getBounds();

            if (bounds.width() <= 0 ||
                bounds.height() <= 0) {
                return;
            }

            float left = bounds.left;
            float top = bounds.top;
            float right = bounds.right;
            float bottom = bounds.bottom;

            float width = right - left;
            float height = bottom - top;

            float radius =
                    height / 2f;

            // ----------------------------------------------------
            // BACKGROUND TRACK
            // ----------------------------------------------------
            backgroundPaint.setColor(
                    android.graphics.Color.parseColor(
                            "#101923"
                    )
            );

            rect.set(
                    left,
                    top,
                    right,
                    bottom
            );

            canvas.drawRoundRect(
                    rect,
                    radius,
                    radius,
                    backgroundPaint
            );

            // ----------------------------------------------------
            // PROGRESS LEVEL 0..10000
            // ----------------------------------------------------
            float progress =
                    getLevel() / 10000f;

            if (progress > 0f) {

                float fillWidth =
                        width * progress;

                // Minimal width supaya ujung tetap terlihat halus.
                if (fillWidth < dp(2)) {
                    fillWidth = dp(2);
                }

                fillRect.set(
                        left,
                        top,
                        Math.min(
                                right,
                                left + fillWidth
                        ),
                        bottom
                );

                // ------------------------------------------------
                // PREMIUM GRADIENT
                // ------------------------------------------------
                android.graphics.LinearGradient gradient =
                        new android.graphics.LinearGradient(
                                left,
                                top,
                                right,
                                bottom,
                                new int[]{
                                        colorStart,
                                        colorMain,
                                        colorEnd
                                },
                                new float[]{
                                        0f,
                                        0.55f,
                                        1f
                                },
                                android.graphics.Shader.TileMode.CLAMP
                        );

                fillPaint.setShader(
                        gradient
                );

                canvas.save();

                // Supaya progress tetap berbentuk rounded.
                android.graphics.Path clipPath =
                        new android.graphics.Path();

                clipPath.addRoundRect(
                        fillRect,
                        radius,
                        radius,
                        android.graphics.Path.Direction.CW
                );

                canvas.clipPath(
                        clipPath
                );

                canvas.drawRect(
                        fillRect,
                        fillPaint
                );

                // ------------------------------------------------
                // MOVING SHINE
                // ------------------------------------------------
                float shineCenter =
                        left +
                        fillWidth *
                        shimmerPosition;

                float shineWidth =
                        Math.max(
                                dp(16),
                                Math.min(
                                        dp(34),
                                        fillWidth * 0.18f
                                )
                        );

                android.graphics.LinearGradient shineGradient =
                        new android.graphics.LinearGradient(
                                shineCenter - shineWidth,
                                top,
                                shineCenter + shineWidth,
                                bottom,
                                new int[]{
                                        android.graphics.Color.TRANSPARENT,
                                        android.graphics.Color.argb(
                                                235,
                                                255,
                                                255,
                                                255
                                        ),
                                        android.graphics.Color.TRANSPARENT
                                },
                                new float[]{
                                        0f,
                                        0.5f,
                                        1f
                                },
                                android.graphics.Shader.TileMode.CLAMP
                        );

                shinePaint.setShader(
                        shineGradient
                );

                canvas.drawRect(
                        left,
                        top,
                        right,
                        bottom,
                        shinePaint
                );

                canvas.restore();

                fillPaint.setShader(null);
                shinePaint.setShader(null);

                // ------------------------------------------------
                // GLOW DI UJUNG PROGRESS
                // ------------------------------------------------
                float endX =
                        left + fillWidth;

                float glowRadius =
                        Math.max(
                                dp(5),
                                height * 0.42f
                        );

                glowPaint.setColor(
                        android.graphics.Color.argb(
                                95,
                                255,
                                255,
                                255
                        )
                );

                canvas.drawCircle(
                        endX,
                        top + height / 2f,
                        glowRadius,
                        glowPaint
                );

                // Titik putih terang kecil di ujung.
                glowPaint.setColor(
                        android.graphics.Color.WHITE
                );

                canvas.drawCircle(
                        endX,
                        top + height / 2f,
                        Math.max(
                                dp(1.5f),
                                height * 0.075f
                        ),
                        glowPaint
                );
            }

            // ----------------------------------------------------
            // BORDER HALUS
            // ----------------------------------------------------
            canvas.drawRoundRect(
                    rect,
                    radius,
                    radius,
                    borderPaint
            );
        }

        @Override
        protected boolean onLevelChange(
                int level) {

            invalidateSelf();
            return true;
        }

        @Override
        public void setAlpha(
                int alpha) {
            backgroundPaint.setAlpha(alpha);
            fillPaint.setAlpha(alpha);
            shinePaint.setAlpha(alpha);
            borderPaint.setAlpha(alpha);
            glowPaint.setAlpha(alpha);
            invalidateSelf();
        }

        @Override
        public void setColorFilter(
                android.graphics.ColorFilter colorFilter) {

            backgroundPaint.setColorFilter(colorFilter);
            fillPaint.setColorFilter(colorFilter);
            shinePaint.setColorFilter(colorFilter);
            borderPaint.setColorFilter(colorFilter);
            glowPaint.setColorFilter(colorFilter);
            invalidateSelf();
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }

    }

    // ========================================================
    // HOLDER HERO
    // ========================================================
    public static class HeroViewHolder
            extends RecyclerView.ViewHolder {

        FrameLayout container;

        public HeroViewHolder(
                @NonNull View itemView) {

            super(itemView);

            container =
                    (FrameLayout) itemView;
        }
    }

    // ========================================================
    // HOLDER MENU
    // ========================================================
    public static class MenuViewHolder
            extends RecyclerView.ViewHolder {

        LinearLayout linear1;

        ImageView imageview1;
        ImageView imageview2;

        TextView textview1;
        TextView textview2;

        public MenuViewHolder(
                @NonNull View itemView) {

            super(itemView);

            linear1 =
                    itemView.findViewById(
                            R.id.linear1
                    );

            imageview1 =
                    itemView.findViewById(
                            R.id.imageview1
                    );

            imageview2 =
                    itemView.findViewById(
                            R.id.imageview2
                    );

            textview1 =
                    itemView.findViewById(
                            R.id.textview1
                    );

            textview2 =
                    itemView.findViewById(
                            R.id.textview2
                    );

            textview1.setSingleLine(true);
            textview1.setHorizontallyScrolling(true);

            textview2.setSingleLine(true);
            textview2.setHorizontallyScrolling(true);

            textview1.setTextSize(
                    TypedValue.COMPLEX_UNIT_DIP,
                    20
            );

            textview2.setTextSize(
                    TypedValue.COMPLEX_UNIT_DIP,
                    12
            );

            textview1.setTextColor(
                    Color.WHITE
            );

            textview2.setTextColor(
                    Color.WHITE
            );

            try {

                Typeface customFont =
                        Typeface.createFromAsset(
                                itemView.getContext()
                                        .getAssets(),
                                "fonts/quick.ttf"
                        );

                textview1.setTypeface(
                        customFont,
                        Typeface.BOLD
                );

                textview2.setTypeface(
                        customFont,
                        Typeface.BOLD
                );

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}