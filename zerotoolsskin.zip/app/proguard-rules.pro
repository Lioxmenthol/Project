# =========================================================
# KONFIGURASI PROGUARD / R8 UNTUK 12 LIBRARY (ZERO TOOLS)
# =========================================================

# 1. ATURAN PENGAMAN GLOBAL & DEPENDENSI BAWAAN (libs/*.jar & AndroidX)
-ignorewarnings
-dontwarn **
-dontnote **
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# 2. PENGAMAN GLIDE (Pemuat Gambar)
-keep class com.bumptech.glide.** { *; }
-keep public class * extends com.bumptech.glide.module.AppGlideModule
-keep public class * extends com.bumptech.glide.module.LibraryGlideModule
-keep class * implements com.bumptech.glide.module.GlideModule
-dontwarn com.bumptech.glide.**

# 3. PENGAMAN GSON & SERIALISASI DATA (Mencegah data JSON rusak/kosong)
-keepattributes Signature,EnclosingMethod,InnerClasses,*Annotation*,SourceFile,LineNumberTable
-keep class com.google.gson.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# 4. PENGAMAN OKHTTP & NETWORKING (Koneksi Internet)
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**
-dontwarn okhttp3.internal.platform.**
-dontwarn org.codehaus.mojo.animal_sniffer.*

# 5. PENGAMAN APACHE HTTP LEGACY (Sesuai pengaturan build.gradle Anda)
-dontwarn org.apache.http.**
-dontwarn android.net.http.**

# 6. PENGAMAN GOOGLE PLAY SERVICES ADS & FIREBASE
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.firebase.** { *; }
-dontwarn com.google.android.gms.**
-dontwarn com.google.firebase.**

# 7. SINYAL UTAMA: Menjaga Komponen Dasar Aplikasi Agar Bisa Terbuka
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider
-keep public class * extends android.app.backup.BackupAgentHelper
-keep public class * extends android.preference.Preference
